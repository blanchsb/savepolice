# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "SavePolice",
    "author" : "blanchsb", 
    "description" : "Call upon the save police for auto-saving or creating customizable alerts",
    "blender" : (4, 0, 0),
    "version" : (1, 0, 30),
    "location" : "Tool Panel",
    "warning" : "",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "System" 
}


import bpy
import bpy.utils.previews
import gpu
import gpu_extras
import os
import math
import blf
import mathutils
from bpy_extras.io_utils import ImportHelper, ExportHelper
import atexit
from bpy.app.handlers import persistent
from datetime import datetime


addon_keymaps = {}
_icons = None
g_draw_alert_image_3d_view = {'sna_frame': 0, 'sna_stop': False, 'sna_custom_frame_length': 0, }
g_draw_alert_image_image_editor = {'sna_frame': 0, 'sna_custom_frame_length': 0, 'sna_stop': False, }
g_draw_alert_image_node_editor = {'sna_frame': 0, 'sna_custom_frame_length': 0, 'sna_stop': False, }
g_draw_alert_image_vse_editor = {'sna_frame': 0, 'sna_custom_frame_length': 0, 'sna_stop': False, }
g_save_police_collection = {'sna_file_exists': False, 'sna_check_for_folder': False, 'sna_prog': 0.0, 'sna_list_length': 0.0, }
graph_debug_testing = {'sna_debug_count': 0, 'sna_var_run_in_intervals': False, }
graph_scripts = {'sna_minutes': 0.0, 'sna_animation_minutes': 0, 'sna_timer_freq': 60.0, 'sna_timer_interval': 0.0, 'sna_timer_sec': 1, 'sna_time_remaining': 0.0, 'sna_time_message': '(Time)', }
handler_5FE5D = []
handler_D8705 = []
handler_AAAFB = []


def find_areas_of_type(screen, area_type):
    areas = []
    for area in screen.areas:
        if area.type == area_type:
            areas.append(area)
    return areas


def find_biggest_area_by_type(screen, area_type):
    areas = find_areas_of_type(screen, area_type)
    if not areas: return []
    max_area = (areas[0], areas[0].width * areas[0].height)
    for area in areas:
        if area.width * area.height > max_area[1]:
            max_area = (area, area.width * area.height)
    return max_area[0]


handler_CB41D = []
handler_EE591 = []
handler_A1E89 = []
handler_0A529 = []
handler_F57E6 = []
class SNA_UL_display_collection_list_0B171(bpy.types.UIList):

    def draw_item(self, context, layout, data, item_0B171, icon, active_data, active_propname, index_0B171):
        row = layout
        if (bpy.path.abspath(bpy.data.filepath) == item_0B171.save_police_file):
            op = layout.operator('sna.op_save_police_save_c2308', text='', icon_value=15, emboss=False, depress=False)
            layout.label(text=item_0B171.save_police_file_name, icon_value=0)
        else:
            op = layout.operator('sna.open_save_police_file_b25ee', text='', icon_value=695, emboss=False, depress=False)
            op.sna_save_file_filepath = item_0B171.save_police_file
            layout.label(text=item_0B171.save_police_file_name, icon_value=0)

    def filter_items(self, context, data, propname):
        flt_flags = []
        for item in getattr(data, propname):
            if not self.filter_name or self.filter_name.lower() in item.name.lower():
                if True:
                    flt_flags.append(self.bitflag_filter_item)
                else:
                    flt_flags.append(0)
            else:
                flt_flags.append(0)
        return flt_flags, []


def property_exists(prop_path, glob, loc):
    try:
        eval(prop_path, glob, loc)
        return True
    except:
        return False


class SNA_UL_display_collection_list_E485D(bpy.types.UIList):

    def draw_item(self, context, layout, data, item_E485D, icon, active_data, active_propname, index_E485D):
        row = layout
        op = layout.operator('sna.change_folder_81f37', text='', icon_value=108, emboss=False, depress=False)
        op.sna_selected_index = index_E485D
        layout.prop(item_E485D, 'project_name', text='', icon_value=0, emboss=False)

    def filter_items(self, context, data, propname):
        flt_flags = []
        for item in getattr(data, propname):
            if not self.filter_name or self.filter_name.lower() in item.name.lower():
                if True:
                    flt_flags.append(self.bitflag_filter_item)
                else:
                    flt_flags.append(0)
            else:
                flt_flags.append(0)
        return flt_flags, []


_item_map = dict()


def make_enum_item(_id, name, descr, preview_id, uid):
    lookup = str(_id)+"\0"+str(name)+"\0"+str(descr)+"\0"+str(preview_id)+"\0"+str(uid)
    if not lookup in _item_map:
        _item_map[lookup] = (_id, name, descr, preview_id, uid)
    return _item_map[lookup]


def sna_update_sna_call_the_save_police_8EE76(self, context):
    sna_updated_prop = self.sna_call_the_save_police
    bpy.context.scene.sna_save_police_interval = bpy.context.preferences.addons['savepolice'].preferences.sna_interval
    if sna_updated_prop:
        if (bpy.context.preferences.addons['savepolice'].preferences.sna_save_default_file and (not os.path.exists(bpy.data.filepath)) and os.path.exists(bpy.context.preferences.addons['savepolice'].preferences.sna_default_folder) and bpy.context.preferences.addons['savepolice'].preferences.sna_save_on_load):
            bpy.ops.sna.op_save_police_saving_148e8('INVOKE_DEFAULT', )
        sna_fn_start_stop_save_police_timer_34567(True)
        if bpy.context.scene.sna_save_police_countdown_active:
            pass
        else:
            bpy.ops.sna.save_police_draw_countdown_f091c('INVOKE_DEFAULT', )
        if bpy.context.preferences.addons['savepolice'].preferences.sna_update_screen_areas:

            def delayed_C2CC4():
                if bpy.context and bpy.context.screen:
                    for a in bpy.context.screen.areas:
                        a.tag_redraw()
                if (not bpy.context.preferences.addons['savepolice'].preferences.sna_update_screen_areas):
                    return None
                return 1.0
            bpy.app.timers.register(delayed_C2CC4, first_interval=0.0)
    else:
        bpy.context.scene.sna_save_police_reminder = False
        sna_fn_start_stop_save_police_timer_34567(False)
        bpy.ops.sna.save_police_end_alert_image_preview_7a41b('INVOKE_DEFAULT', )
        bpy.ops.sna.save_police_end_countdown_preview_8f673('INVOKE_DEFAULT', )


def sna_update_sna_alert_1467F(self, context):
    sna_updated_prop = self.sna_alert
    if sna_updated_prop:
        pass
    else:
        bpy.context.scene.sna_save_police_reminder = False
    if bpy.context.preferences.addons['savepolice'].preferences.sna_call_the_save_police:
        sna_fn_start_stop_save_police_timer_34567(True)


def sna_update_sna_save_default_file_FCB28(self, context):
    sna_updated_prop = self.sna_save_default_file


def sna_update_sna_interval_CA391(self, context):
    sna_updated_prop = self.sna_interval
    bpy.context.scene.sna_save_police_interval = sna_updated_prop


def sna_update_sna_use_countdown_255C0(self, context):
    sna_updated_prop = self.sna_use_countdown
    if sna_updated_prop:
        if bpy.context.preferences.addons['savepolice'].preferences.sna_call_the_save_police:
            bpy.context.preferences.addons['savepolice'].preferences.sna_call_the_save_police = False
            bpy.context.preferences.addons['savepolice'].preferences.sna_call_the_save_police = True


def sna_update_sna_view_single_or_multiple_projects_4BB3A(self, context):
    sna_updated_prop = self.sna_view_single_or_multiple_projects
    if sna_updated_prop:
        if bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_directory_collection:
            pass
        else:
            bpy.context.scene.sna_save_police_collection.clear()
        if bpy.context and bpy.context.screen:
            for a in bpy.context.screen.areas:
                a.tag_redraw()
    bpy.ops.sna.save_police_reload_save_collection_14f82('INVOKE_DEFAULT', )


def sna_update_directory_15C6C(self, context):
    sna_updated_prop = self.directory
    if bpy.context.preferences.addons['savepolice'].preferences.sna_view_single_or_multiple_projects:
        if os.path.isdir(bpy.path.abspath(sna_updated_prop)):
            for i_171D8 in range(len(bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_directory_collection)):
                bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_directory_collection_index = i_171D8
                if bpy.context and bpy.context.screen:
                    for a in bpy.context.screen.areas:
                        a.tag_redraw()


def sna_update_sna_save_police_directory_collection_index_D956E(self, context):
    sna_updated_prop = self.sna_save_police_directory_collection_index
    if bpy.context.preferences.addons['savepolice'].preferences.sna_view_single_or_multiple_projects:
        if bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_directory_collection:
            if os.path.isdir(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_directory_collection[sna_updated_prop].directory)):
                print('')
                bpy.ops.sna.save_police_reload_save_collection_14f82()
    else:
        bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_directory_collection.clear()
        if bool(bpy.data.filepath):
            if os.path.exists(bpy.data.filepath):
                item_10118 = bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_directory_collection.add()
                if os.path.isdir(bpy.path.abspath(bpy.data.filepath)):
                    item_10118.directory = bpy.path.abspath(bpy.data.filepath)
                else:
                    item_10118.directory = os.path.dirname(bpy.path.abspath(bpy.data.filepath))
            else:
                if bpy.context.preferences.addons['savepolice'].preferences.sna_save_default_file:
                    if bool(bpy.context.preferences.addons['savepolice'].preferences.sna_default_folder):
                        if os.path.exists(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_default_folder)):
                            item_869B3 = bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_directory_collection.add()
                            if os.path.isdir(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_default_folder)):
                                item_869B3.directory = bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_default_folder)
                            else:
                                item_869B3.directory = os.path.dirname(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_default_folder))


def sna_update_sna_save_police_reminder_9D6ED(self, context):
    sna_updated_prop = self.sna_save_police_reminder
    if sna_updated_prop:
        if bpy.context.preferences.addons['savepolice'].preferences.sna_alert:
            sna_fn_start_stop_save_police_timer_34567(False)
            if bpy.context.preferences.addons['savepolice'].preferences.sna_pack_resources:
                bpy.ops.file.pack_all('INVOKE_DEFAULT', )
            if bpy.context.scene.sna_save_police_animation_active:
                pass
            else:
                bpy.ops.sna.save_police_preview_alert_image_558a3('INVOKE_DEFAULT', )
            if bpy.context.scene.sna_save_police_countdown_active:
                bpy.ops.sna.save_police_end_countdown_preview_8f673('INVOKE_DEFAULT', )
        else:
            if (bpy.data.is_dirty and bpy.context.preferences.addons['savepolice'].preferences.sna_call_the_save_police):
                bpy.ops.sna.op_save_police_saving_148e8('INVOKE_DEFAULT', )
    else:
        if bpy.context.scene.sna_save_police_annoy_active:
            bpy.context.scene.sna_save_police_annoy_active = False


def sna_update_sna_save_police_interval_8D7BA(self, context):
    sna_updated_prop = self.sna_save_police_interval


def sna_update_sna_load_save_police_collection_69320(self, context):
    sna_updated_prop = self.sna_load_save_police_collection
    if sna_updated_prop:
        bpy.ops.sna.save_police_reload_save_collection_14f82('INVOKE_DEFAULT', )


def display_collection_id(uid, vars):
    id = f"coll_{uid}"
    for var in vars.keys():
        if var.startswith("i_"):
            id += f"_{var}_{vars[var]}"
    return id


class SNA_UL_display_collection_list_4517F(bpy.types.UIList):

    def draw_item(self, context, layout, data, item_4517F, icon, active_data, active_propname, index_4517F):
        row = layout
        row_4D339 = layout.row(heading='', align=False)
        row_4D339.alert = False
        row_4D339.enabled = True
        row_4D339.active = True
        row_4D339.use_property_split = False
        row_4D339.use_property_decorate = False
        row_4D339.scale_x = 1.0
        row_4D339.scale_y = 1.0
        row_4D339.alignment = 'Expand'.upper()
        row_4D339.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_4D339.label(text='', icon_value=(load_preview_icon(bpy.path.abspath(item_4517F.icon_path)) if os.path.exists(bpy.path.abspath(item_4517F.icon_path)) else 101))
        row_4D339.prop(item_4517F, 'icon_path', text='', icon_value=0, emboss=(not os.path.exists(bpy.path.abspath(item_4517F.icon_path))))

    def filter_items(self, context, data, propname):
        flt_flags = []
        for item in getattr(data, propname):
            if not self.filter_name or self.filter_name.lower() in item.name.lower():
                if True:
                    flt_flags.append(self.bitflag_filter_item)
                else:
                    flt_flags.append(0)
            else:
                flt_flags.append(0)
        return flt_flags, []


def load_preview_icon(path):
    global _icons
    if not path in _icons:
        if os.path.exists(path):
            _icons.load(path, path, "IMAGE")
        else:
            return 0
    return _icons[path].icon_id


def sna_fn_modal_drawing_2699F():
    if bool(find_areas_of_type(bpy.context.screen, 'VIEW_3D')):
        if bpy.context.preferences.addons['savepolice'].preferences.sna_alert_use_background:
            if (os.path.exists(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_alert_background)) and bpy.context.preferences.addons['savepolice'].preferences.sna_alert_custom_background):
                region = bpy.context.region
                norm_x = 2.0 / region.width
                norm_y = 2.0 / region.height
                bl_norm = ((1.0, 1.0)[0] * norm_x - 1, (1.0, 1.0)[1] * norm_y - 1)
                width_norm = find_biggest_area_by_type(bpy.context.screen, 'VIEW_3D').width * norm_x
                height_norm = find_biggest_area_by_type(bpy.context.screen, 'VIEW_3D').height * norm_y
                coords = (
                    (bl_norm[0],bl_norm[1]),
                    (bl_norm[0] + width_norm, bl_norm[1]),
                    (bl_norm[0] + width_norm, bl_norm[1] + height_norm),
                    (bl_norm[0], bl_norm[1] + height_norm)
                )
                bpy.data.images.load(filepath=bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_alert_background), check_existing=True, )

                def get_img_name():
                    this = os.path.basename(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_alert_background))
                    for i in range(len(bpy.data.images)):
                        if bpy.data.images[i].name == bpy.data.images[this].name:
                            return bpy.data.images[i]
                alpha = bpy.context.preferences.addons['savepolice'].preferences.sna_global_opacity
                image = get_img_name()
                texture = gpu.texture.from_image(image)
                vertex_shader = '''
                    in vec2 pos;
                    in vec2 texCoord;
                    out vec2 TexCoord;
                    void main()
                    {
                        TexCoord = texCoord;
                        gl_Position = vec4(pos, 0.0, 1.0);
                    }
                '''
                fragment_shader = '''
                    in vec2 TexCoord;
                    uniform sampler2D image;
                    uniform float alpha;
                    out vec4 FragColor;
                    void main()
                    {
                        vec4 textColor = texture(image, TexCoord);
                        FragColor = vec4(textColor.rgb, textColor.a * alpha);
                    }
                '''
                # Create shader program
                gpu.state.blend_set('ALPHA')
                shader = gpu.types.GPUShader(vertex_shader, fragment_shader)
                batch = gpu_extras.batch.batch_for_shader(
                    shader, 'TRI_FAN',
                    {
                        "pos": coords,
                        "texCoord": ((0, 0), (1, 0), (1, 1), (0, 1)),
                    },
                )
                # Use shader program
                shader.bind()
                # Set uniform values
                shader.uniform_float("alpha", alpha)
                shader.uniform_sampler("image", texture)
                # Draw call
                batch.draw(shader)
                bpy.context.area.tag_redraw()
            else:
                quads = [[tuple((1.0, 1.0)), tuple((find_biggest_area_by_type(bpy.context.screen, 'VIEW_3D').width, 1.0)), tuple((1.0, find_biggest_area_by_type(bpy.context.screen, 'VIEW_3D').height)), tuple((find_biggest_area_by_type(bpy.context.screen, 'VIEW_3D').width, find_biggest_area_by_type(bpy.context.screen, 'VIEW_3D').height))]]
                vertices = []
                indices = []
                for i_7A2A5, quad in enumerate(quads):
                    vertices.extend(quad)
                    indices.extend([(i_7A2A5 * 4, i_7A2A5 * 4 + 1, i_7A2A5 * 4 + 2), (i_7A2A5 * 4 + 2, i_7A2A5 * 4 + 1, i_7A2A5 * 4 + 3)])
                shader = gpu.shader.from_builtin('UNIFORM_COLOR')
                batch = gpu_extras.batch.batch_for_shader(shader, 'TRIS', {"pos": tuple(vertices)}, indices=tuple(indices))
                shader.bind()
                shader.uniform_float("color", (bpy.context.preferences.addons['savepolice'].preferences.sna_alert_background_color[0], bpy.context.preferences.addons['savepolice'].preferences.sna_alert_background_color[1], bpy.context.preferences.addons['savepolice'].preferences.sna_alert_background_color[2], eval("min(bpy.context.preferences.addons['savepolice'].preferences.sna_alert_background_color[3],bpy.context.preferences.addons['savepolice'].preferences.sna_global_opacity)")))
                gpu.state.blend_set('ALPHA')
                batch.draw(shader)
        if bpy.context.preferences.addons['savepolice'].preferences.sna_alert_use_image:
            if bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence:
                if bpy.context.preferences.addons['savepolice'].preferences.sna_siren_custom:
                    if os.path.isdir(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory)):
                        region = bpy.context.region
                        norm_x = 2.0 / region.width
                        norm_y = 2.0 / region.height
                        bl_norm = (bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[0] * norm_x - 1, bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[1] * norm_y - 1)
                        width_norm = bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[0] * norm_x
                        height_norm = bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[1] * norm_y
                        coords = (
                            (bl_norm[0],bl_norm[1]),
                            (bl_norm[0] + width_norm, bl_norm[1]),
                            (bl_norm[0] + width_norm, bl_norm[1] + height_norm),
                            (bl_norm[0], bl_norm[1] + height_norm)
                        )
                        alpha = bpy.context.preferences.addons['savepolice'].preferences.sna_global_opacity
                        directory = bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory)

                        def get_sequence_length(directory):
                            if not directory or not os.path.exists(directory):  # Check if the directory is empty or does not exist
                                return 0
                            try:
                                files = [f for f in os.listdir(directory) if f.endswith('.png')]
                                return min(len(files), 101)
                            except Exception as e:
                                print(f"An error occurred while getting the sequence length: {e}")
                                return 0
                        if directory:
                            sequence_length = get_sequence_length(directory)
                            start_frame_value = g_draw_alert_image_3d_view['sna_frame']
                            start_frame = max(0, min(100, start_frame_value))
                            end_frame_value = g_draw_alert_image_3d_view['sna_custom_frame_length']
                            end_frame = max(0, min(100, end_frame_value))
                            start_frame = min(start_frame, end_frame)
                            #Define Image Sequence Function

                            def get_image_from_directory(image_frame, directory):
                                files = [f for f in os.listdir(directory) if f.endswith('.png')]
                                files.sort()
                                sequence_length = min(get_sequence_length(directory), 101)
                                if 0 <= image_frame < sequence_length:
                                    image_path = os.path.join(directory, files[image_frame])
                                    bpy.data.images.load(filepath=image_path, check_existing=True)
                                    return bpy.data.images[os.path.basename(image_path)]
                                else:
                                    return None
                            image_frame = g_draw_alert_image_3d_view['sna_frame']
                            image = get_image_from_directory(image_frame, directory)
                            if image is not None:
                                texture = gpu.texture.from_image(image)
                                vertex_shader = '''
                                    in vec2 pos;
                                    in vec2 texCoord;
                                    out vec2 TexCoord;
                                    void main()
                                    {
                                        TexCoord = texCoord;
                                        gl_Position = vec4(pos, 0.0, 1.0);
                                    }
                                '''
                                fragment_shader = '''
                                    in vec2 TexCoord;
                                    uniform sampler2D image;
                                    uniform float alpha;
                                    out vec4 FragColor;
                                    void main()
                                    {
                                        vec4 textColor = texture(image, TexCoord);
                                        FragColor = vec4(textColor.rgb, textColor.a * alpha);
                                    }
                                '''
                                # Create shader program
                                gpu.state.blend_set('ALPHA')
                                shader = gpu.types.GPUShader(vertex_shader, fragment_shader)
                                batch = gpu_extras.batch.batch_for_shader(
                                    shader, 'TRI_FAN',
                                    {
                                        "pos": coords,
                                        "texCoord": ((0, 0), (1, 0), (1, 1), (0, 1)),
                                    },
                                )
                                # Use shader program
                                shader.bind()
                                # Set uniform values
                                shader.uniform_float("alpha", alpha)
                                shader.uniform_sampler("image", texture)
                                # Draw call
                                batch.draw(shader)
                                bpy.context.area.tag_redraw()
                else:
                    region = bpy.context.region
                    norm_x = 2.0 / region.width
                    norm_y = 2.0 / region.height
                    bl_norm = (bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[0] * norm_x - 1, bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[1] * norm_y - 1)
                    width_norm = bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[0] * norm_x
                    height_norm = bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[1] * norm_y
                    coords = (
                        (bl_norm[0],bl_norm[1]),
                        (bl_norm[0] + width_norm, bl_norm[1]),
                        (bl_norm[0] + width_norm, bl_norm[1] + height_norm),
                        (bl_norm[0], bl_norm[1] + height_norm)
                    )
                    alpha = bpy.context.preferences.addons['savepolice'].preferences.sna_global_opacity
                    directory = os.path.join(os.path.dirname(__file__), 'assets', 'Becon Composites 256 x 256')

                    def get_sequence_length(directory):
                        if not directory or not os.path.exists(directory):  # Check if the directory is empty or does not exist
                            return 0
                        try:
                            files = [f for f in os.listdir(directory) if f.endswith('.png')]
                            return min(len(files), 101)
                        except Exception as e:
                            print(f"An error occurred while getting the sequence length: {e}")
                            return 0
                    if directory:
                        sequence_length = get_sequence_length(directory)
                        start_frame_value = g_draw_alert_image_3d_view['sna_frame']
                        start_frame = max(0, min(100, start_frame_value))
                        end_frame_value = 22
                        end_frame = max(0, min(100, end_frame_value))
                        start_frame = min(start_frame, end_frame)
                        #Define Image Sequence Function

                        def get_image_from_directory(image_frame, directory):
                            files = [f for f in os.listdir(directory) if f.endswith('.png')]
                            files.sort()
                            sequence_length = min(get_sequence_length(directory), 101)
                            if 0 <= image_frame < sequence_length:
                                image_path = os.path.join(directory, files[image_frame])
                                bpy.data.images.load(filepath=image_path, check_existing=True)
                                return bpy.data.images[os.path.basename(image_path)]
                            else:
                                return None
                        image_frame = g_draw_alert_image_3d_view['sna_frame']
                        image = get_image_from_directory(image_frame, directory)
                        if image is not None:
                            texture = gpu.texture.from_image(image)
                            vertex_shader = '''
                                in vec2 pos;
                                in vec2 texCoord;
                                out vec2 TexCoord;
                                void main()
                                {
                                    TexCoord = texCoord;
                                    gl_Position = vec4(pos, 0.0, 1.0);
                                }
                            '''
                            fragment_shader = '''
                                in vec2 TexCoord;
                                uniform sampler2D image;
                                uniform float alpha;
                                out vec4 FragColor;
                                void main()
                                {
                                    vec4 textColor = texture(image, TexCoord);
                                    FragColor = vec4(textColor.rgb, textColor.a * alpha);
                                }
                            '''
                            # Create shader program
                            gpu.state.blend_set('ALPHA')
                            shader = gpu.types.GPUShader(vertex_shader, fragment_shader)
                            batch = gpu_extras.batch.batch_for_shader(
                                shader, 'TRI_FAN',
                                {
                                    "pos": coords,
                                    "texCoord": ((0, 0), (1, 0), (1, 1), (0, 1)),
                                },
                            )
                            # Use shader program
                            shader.bind()
                            # Set uniform values
                            shader.uniform_float("alpha", alpha)
                            shader.uniform_sampler("image", texture)
                            # Draw call
                            batch.draw(shader)
                            bpy.context.area.tag_redraw()
            else:
                if bpy.context.preferences.addons['savepolice'].preferences.sna_siren_custom:
                    if os.path.exists(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_path)):
                        region = bpy.context.region
                        norm_x = 2.0 / region.width
                        norm_y = 2.0 / region.height
                        bl_norm = (bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[0] * norm_x - 1, bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[1] * norm_y - 1)
                        width_norm = bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[0] * norm_x
                        height_norm = bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[1] * norm_y
                        coords = (
                            (bl_norm[0],bl_norm[1]),
                            (bl_norm[0] + width_norm, bl_norm[1]),
                            (bl_norm[0] + width_norm, bl_norm[1] + height_norm),
                            (bl_norm[0], bl_norm[1] + height_norm)
                        )
                        bpy.data.images.load(filepath=bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_path), check_existing=True, )

                        def get_img_name():
                            this = os.path.basename(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_path))
                            for i in range(len(bpy.data.images)):
                                if bpy.data.images[i].name == bpy.data.images[this].name:
                                    return bpy.data.images[i]
                        alpha = bpy.context.preferences.addons['savepolice'].preferences.sna_global_opacity
                        image = get_img_name()
                        texture = gpu.texture.from_image(image)
                        vertex_shader = '''
                            in vec2 pos;
                            in vec2 texCoord;
                            out vec2 TexCoord;
                            void main()
                            {
                                TexCoord = texCoord;
                                gl_Position = vec4(pos, 0.0, 1.0);
                            }
                        '''
                        fragment_shader = '''
                            in vec2 TexCoord;
                            uniform sampler2D image;
                            uniform float alpha;
                            out vec4 FragColor;
                            void main()
                            {
                                vec4 textColor = texture(image, TexCoord);
                                FragColor = vec4(textColor.rgb, textColor.a * alpha);
                            }
                        '''
                        # Create shader program
                        gpu.state.blend_set('ALPHA')
                        shader = gpu.types.GPUShader(vertex_shader, fragment_shader)
                        batch = gpu_extras.batch.batch_for_shader(
                            shader, 'TRI_FAN',
                            {
                                "pos": coords,
                                "texCoord": ((0, 0), (1, 0), (1, 1), (0, 1)),
                            },
                        )
                        # Use shader program
                        shader.bind()
                        # Set uniform values
                        shader.uniform_float("alpha", alpha)
                        shader.uniform_sampler("image", texture)
                        # Draw call
                        batch.draw(shader)
                        bpy.context.area.tag_redraw()
                else:
                    region = bpy.context.region
                    norm_x = 2.0 / region.width
                    norm_y = 2.0 / region.height
                    bl_norm = (bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[0] * norm_x - 1, bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[1] * norm_y - 1)
                    width_norm = bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[0] * norm_x
                    height_norm = bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[1] * norm_y
                    coords = (
                        (bl_norm[0],bl_norm[1]),
                        (bl_norm[0] + width_norm, bl_norm[1]),
                        (bl_norm[0] + width_norm, bl_norm[1] + height_norm),
                        (bl_norm[0], bl_norm[1] + height_norm)
                    )
                    bpy.data.images.load(filepath=os.path.join(os.path.dirname(__file__), 'assets', 'Siren_256x256_Render0013.png'), check_existing=True, )

                    def get_img_name():
                        this = os.path.basename(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_256x256_Render0013.png'))
                        for i in range(len(bpy.data.images)):
                            if bpy.data.images[i].name == bpy.data.images[this].name:
                                return bpy.data.images[i]
                    alpha = bpy.context.preferences.addons['savepolice'].preferences.sna_global_opacity
                    image = get_img_name()
                    texture = gpu.texture.from_image(image)
                    vertex_shader = '''
                        in vec2 pos;
                        in vec2 texCoord;
                        out vec2 TexCoord;
                        void main()
                        {
                            TexCoord = texCoord;
                            gl_Position = vec4(pos, 0.0, 1.0);
                        }
                    '''
                    fragment_shader = '''
                        in vec2 TexCoord;
                        uniform sampler2D image;
                        uniform float alpha;
                        out vec4 FragColor;
                        void main()
                        {
                            vec4 textColor = texture(image, TexCoord);
                            FragColor = vec4(textColor.rgb, textColor.a * alpha);
                        }
                    '''
                    # Create shader program
                    gpu.state.blend_set('ALPHA')
                    shader = gpu.types.GPUShader(vertex_shader, fragment_shader)
                    batch = gpu_extras.batch.batch_for_shader(
                        shader, 'TRI_FAN',
                        {
                            "pos": coords,
                            "texCoord": ((0, 0), (1, 0), (1, 1), (0, 1)),
                        },
                    )
                    # Use shader program
                    shader.bind()
                    # Set uniform values
                    shader.uniform_float("alpha", alpha)
                    shader.uniform_sampler("image", texture)
                    # Draw call
                    batch.draw(shader)
                    bpy.context.area.tag_redraw()
        if bpy.context.preferences.addons['savepolice'].preferences.sna_alert_use_message:
            font_id = 0
            if bpy.context.preferences.addons['savepolice'].preferences.sna_alert_font and os.path.exists(bpy.context.preferences.addons['savepolice'].preferences.sna_alert_font):
                font_id = blf.load(bpy.context.preferences.addons['savepolice'].preferences.sna_alert_font)
            if font_id == -1:
                print("Couldn't load font!")
            else:
                x_F0888, y_F0888 = bpy.context.preferences.addons['savepolice'].preferences.sna_alert_message_location
                blf.position(font_id, x_F0888, y_F0888, 0)
                if bpy.app.version >= (3, 4, 0):
                    blf.size(font_id, bpy.context.preferences.addons['savepolice'].preferences.sna_alert_message_size)
                else:
                    blf.size(font_id, bpy.context.preferences.addons['savepolice'].preferences.sna_alert_message_size, bpy.context.preferences.addons['savepolice'].preferences.sna_alert_message_dpi)
                clr = (bpy.context.preferences.addons['savepolice'].preferences.sna_alert_color[0], bpy.context.preferences.addons['savepolice'].preferences.sna_alert_color[1], bpy.context.preferences.addons['savepolice'].preferences.sna_alert_color[2], eval("min(bpy.context.preferences.addons['savepolice'].preferences.sna_alert_color[3],bpy.context.preferences.addons['savepolice'].preferences.sna_global_opacity)"))
                blf.color(font_id, clr[0], clr[1], clr[2], clr[3])
                if bpy.context.preferences.addons['savepolice'].preferences.sna_alert_message_wrap:
                    blf.enable(font_id, blf.WORD_WRAP)
                    blf.word_wrap(font_id, bpy.context.preferences.addons['savepolice'].preferences.sna_alert_message_wrap)
                if bpy.context.preferences.addons['savepolice'].preferences.sna_alert_message_rotation:
                    blf.enable(font_id, blf.ROTATION)
                    blf.rotation(font_id, bpy.context.preferences.addons['savepolice'].preferences.sna_alert_message_rotation)
                blf.enable(font_id, blf.WORD_WRAP)
                blf.draw(font_id, bpy.context.preferences.addons['savepolice'].preferences.sna_alert_message)
                blf.disable(font_id, blf.ROTATION)
                blf.disable(font_id, blf.WORD_WRAP)


def sna_fn_draw_siren_start_FE25B():
    g_draw_alert_image_3d_view['sna_frame'] = 0
    g_draw_alert_image_3d_view['sna_custom_frame_length'] = 0
    g_draw_alert_image_3d_view['sna_stop'] = False
    bpy.context.scene.sna_save_police_animation_active = True
    handler_5FE5D.append(bpy.types.SpaceView3D.draw_handler_add(sna_fn_modal_drawing_2699F, (), 'WINDOW', 'POST_PIXEL'))
    for a in bpy.context.screen.areas: a.tag_redraw()
    if bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence:

        def delayed_CF5D6():
            if bpy.context.preferences.addons['savepolice'].preferences.sna_siren_custom:
                if os.path.isdir(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory)):
                    if (len([os.path.join(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory), f) for f in os.listdir(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory)) if os.path.isfile(os.path.join(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory), f))]) > 0):
                        g_draw_alert_image_3d_view['sna_custom_frame_length'] = len([os.path.join(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory), f) for f in os.listdir(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory)) if os.path.isfile(os.path.join(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory), f))])
                    else:
                        g_draw_alert_image_3d_view['sna_custom_frame_length'] = 0
                else:
                    g_draw_alert_image_3d_view['sna_custom_frame_length'] = 0
            g_draw_alert_image_3d_view['sna_frame'] += 1
            if (g_draw_alert_image_3d_view['sna_frame'] >= (g_draw_alert_image_3d_view['sna_custom_frame_length'] if bpy.context.preferences.addons['savepolice'].preferences.sna_siren_custom else 22)):
                g_draw_alert_image_3d_view['sna_frame'] = 0
            if g_draw_alert_image_3d_view['sna_stop']:
                return None
            return bpy.context.preferences.addons['savepolice'].preferences.sna_siren_interval
        bpy.app.timers.register(delayed_CF5D6, first_interval=0.0)


def sna_fn_draw_siren_end_5EC29():
    bpy.context.scene.sna_save_police_animation_active = False
    g_draw_alert_image_3d_view['sna_stop'] = True
    if handler_5FE5D:
        bpy.types.SpaceView3D.draw_handler_remove(handler_5FE5D[0], 'WINDOW')
        handler_5FE5D.pop(0)
        for a in bpy.context.screen.areas: a.tag_redraw()


def sna_fn_modal_drawing_image_editor_B195C():
    if bool(find_areas_of_type(bpy.context.screen, 'IMAGE_EDITOR')):
        if bpy.context.preferences.addons['savepolice'].preferences.sna_alert_use_background:
            if (os.path.exists(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_alert_background)) and bpy.context.preferences.addons['savepolice'].preferences.sna_alert_custom_background):
                region = bpy.context.region
                norm_x = 2.0 / region.width
                norm_y = 2.0 / region.height
                bl_norm = ((1.0, 1.0)[0] * norm_x - 1, (1.0, 1.0)[1] * norm_y - 1)
                width_norm = find_biggest_area_by_type(bpy.context.screen, 'IMAGE_EDITOR').width * norm_x
                height_norm = find_biggest_area_by_type(bpy.context.screen, 'IMAGE_EDITOR').height * norm_y
                coords = (
                    (bl_norm[0],bl_norm[1]),
                    (bl_norm[0] + width_norm, bl_norm[1]),
                    (bl_norm[0] + width_norm, bl_norm[1] + height_norm),
                    (bl_norm[0], bl_norm[1] + height_norm)
                )
                bpy.data.images.load(filepath=bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_alert_background), check_existing=True, )

                def get_img_name():
                    this = os.path.basename(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_alert_background))
                    for i in range(len(bpy.data.images)):
                        if bpy.data.images[i].name == bpy.data.images[this].name:
                            return bpy.data.images[i]
                alpha = bpy.context.preferences.addons['savepolice'].preferences.sna_global_opacity
                image = get_img_name()
                texture = gpu.texture.from_image(image)
                vertex_shader = '''
                    in vec2 pos;
                    in vec2 texCoord;
                    out vec2 TexCoord;
                    void main()
                    {
                        TexCoord = texCoord;
                        gl_Position = vec4(pos, 0.0, 1.0);
                    }
                '''
                fragment_shader = '''
                    in vec2 TexCoord;
                    uniform sampler2D image;
                    uniform float alpha;
                    out vec4 FragColor;
                    void main()
                    {
                        vec4 textColor = texture(image, TexCoord);
                        FragColor = vec4(textColor.rgb, textColor.a * alpha);
                    }
                '''
                # Create shader program
                gpu.state.blend_set('ALPHA')
                shader = gpu.types.GPUShader(vertex_shader, fragment_shader)
                batch = gpu_extras.batch.batch_for_shader(
                    shader, 'TRI_FAN',
                    {
                        "pos": coords,
                        "texCoord": ((0, 0), (1, 0), (1, 1), (0, 1)),
                    },
                )
                # Use shader program
                shader.bind()
                # Set uniform values
                shader.uniform_float("alpha", alpha)
                shader.uniform_sampler("image", texture)
                # Draw call
                batch.draw(shader)
                bpy.context.area.tag_redraw()
            else:
                quads = [[tuple((1.0, 1.0)), tuple((find_biggest_area_by_type(bpy.context.screen, 'IMAGE_EDITOR').width, 1.0)), tuple((1.0, find_biggest_area_by_type(bpy.context.screen, 'IMAGE_EDITOR').height)), tuple((find_biggest_area_by_type(bpy.context.screen, 'IMAGE_EDITOR').width, find_biggest_area_by_type(bpy.context.screen, 'IMAGE_EDITOR').height))]]
                vertices = []
                indices = []
                for i_B5E84, quad in enumerate(quads):
                    vertices.extend(quad)
                    indices.extend([(i_B5E84 * 4, i_B5E84 * 4 + 1, i_B5E84 * 4 + 2), (i_B5E84 * 4 + 2, i_B5E84 * 4 + 1, i_B5E84 * 4 + 3)])
                shader = gpu.shader.from_builtin('UNIFORM_COLOR')
                batch = gpu_extras.batch.batch_for_shader(shader, 'TRIS', {"pos": tuple(vertices)}, indices=tuple(indices))
                shader.bind()
                shader.uniform_float("color", (bpy.context.preferences.addons['savepolice'].preferences.sna_alert_background_color[0], bpy.context.preferences.addons['savepolice'].preferences.sna_alert_background_color[1], bpy.context.preferences.addons['savepolice'].preferences.sna_alert_background_color[2], eval("min(bpy.context.preferences.addons['savepolice'].preferences.sna_alert_background_color[3],bpy.context.preferences.addons['savepolice'].preferences.sna_global_opacity)")))
                gpu.state.blend_set('ALPHA')
                batch.draw(shader)
        if bpy.context.preferences.addons['savepolice'].preferences.sna_alert_use_image:
            if bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence:
                if bpy.context.preferences.addons['savepolice'].preferences.sna_siren_custom:
                    if os.path.isdir(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory)):
                        region = bpy.context.region
                        norm_x = 2.0 / region.width
                        norm_y = 2.0 / region.height
                        bl_norm = (bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[0] * norm_x - 1, bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[1] * norm_y - 1)
                        width_norm = bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[0] * norm_x
                        height_norm = bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[1] * norm_y
                        coords = (
                            (bl_norm[0],bl_norm[1]),
                            (bl_norm[0] + width_norm, bl_norm[1]),
                            (bl_norm[0] + width_norm, bl_norm[1] + height_norm),
                            (bl_norm[0], bl_norm[1] + height_norm)
                        )
                        alpha = bpy.context.preferences.addons['savepolice'].preferences.sna_global_opacity
                        directory = bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory)

                        def get_sequence_length(directory):
                            if not directory or not os.path.exists(directory):  # Check if the directory is empty or does not exist
                                return 0
                            try:
                                files = [f for f in os.listdir(directory) if f.endswith('.png')]
                                return min(len(files), 101)
                            except Exception as e:
                                print(f"An error occurred while getting the sequence length: {e}")
                                return 0
                        if directory:
                            sequence_length = get_sequence_length(directory)
                            start_frame_value = g_draw_alert_image_3d_view['sna_frame']
                            start_frame = max(0, min(100, start_frame_value))
                            end_frame_value = g_draw_alert_image_3d_view['sna_custom_frame_length']
                            end_frame = max(0, min(100, end_frame_value))
                            start_frame = min(start_frame, end_frame)
                            #Define Image Sequence Function

                            def get_image_from_directory(image_frame, directory):
                                files = [f for f in os.listdir(directory) if f.endswith('.png')]
                                files.sort()
                                sequence_length = min(get_sequence_length(directory), 101)
                                if 0 <= image_frame < sequence_length:
                                    image_path = os.path.join(directory, files[image_frame])
                                    bpy.data.images.load(filepath=image_path, check_existing=True)
                                    return bpy.data.images[os.path.basename(image_path)]
                                else:
                                    return None
                            image_frame = g_draw_alert_image_3d_view['sna_frame']
                            image = get_image_from_directory(image_frame, directory)
                            if image is not None:
                                texture = gpu.texture.from_image(image)
                                vertex_shader = '''
                                    in vec2 pos;
                                    in vec2 texCoord;
                                    out vec2 TexCoord;
                                    void main()
                                    {
                                        TexCoord = texCoord;
                                        gl_Position = vec4(pos, 0.0, 1.0);
                                    }
                                '''
                                fragment_shader = '''
                                    in vec2 TexCoord;
                                    uniform sampler2D image;
                                    uniform float alpha;
                                    out vec4 FragColor;
                                    void main()
                                    {
                                        vec4 textColor = texture(image, TexCoord);
                                        FragColor = vec4(textColor.rgb, textColor.a * alpha);
                                    }
                                '''
                                # Create shader program
                                gpu.state.blend_set('ALPHA')
                                shader = gpu.types.GPUShader(vertex_shader, fragment_shader)
                                batch = gpu_extras.batch.batch_for_shader(
                                    shader, 'TRI_FAN',
                                    {
                                        "pos": coords,
                                        "texCoord": ((0, 0), (1, 0), (1, 1), (0, 1)),
                                    },
                                )
                                # Use shader program
                                shader.bind()
                                # Set uniform values
                                shader.uniform_float("alpha", alpha)
                                shader.uniform_sampler("image", texture)
                                # Draw call
                                batch.draw(shader)
                                bpy.context.area.tag_redraw()
                else:
                    region = bpy.context.region
                    norm_x = 2.0 / region.width
                    norm_y = 2.0 / region.height
                    bl_norm = (bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[0] * norm_x - 1, bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[1] * norm_y - 1)
                    width_norm = bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[0] * norm_x
                    height_norm = bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[1] * norm_y
                    coords = (
                        (bl_norm[0],bl_norm[1]),
                        (bl_norm[0] + width_norm, bl_norm[1]),
                        (bl_norm[0] + width_norm, bl_norm[1] + height_norm),
                        (bl_norm[0], bl_norm[1] + height_norm)
                    )
                    alpha = bpy.context.preferences.addons['savepolice'].preferences.sna_global_opacity
                    directory = os.path.join(os.path.dirname(__file__), 'assets', 'Becon Composites 256 x 256')

                    def get_sequence_length(directory):
                        if not directory or not os.path.exists(directory):  # Check if the directory is empty or does not exist
                            return 0
                        try:
                            files = [f for f in os.listdir(directory) if f.endswith('.png')]
                            return min(len(files), 101)
                        except Exception as e:
                            print(f"An error occurred while getting the sequence length: {e}")
                            return 0
                    if directory:
                        sequence_length = get_sequence_length(directory)
                        start_frame_value = g_draw_alert_image_3d_view['sna_frame']
                        start_frame = max(0, min(100, start_frame_value))
                        end_frame_value = 22
                        end_frame = max(0, min(100, end_frame_value))
                        start_frame = min(start_frame, end_frame)
                        #Define Image Sequence Function

                        def get_image_from_directory(image_frame, directory):
                            files = [f for f in os.listdir(directory) if f.endswith('.png')]
                            files.sort()
                            sequence_length = min(get_sequence_length(directory), 101)
                            if 0 <= image_frame < sequence_length:
                                image_path = os.path.join(directory, files[image_frame])
                                bpy.data.images.load(filepath=image_path, check_existing=True)
                                return bpy.data.images[os.path.basename(image_path)]
                            else:
                                return None
                        image_frame = g_draw_alert_image_3d_view['sna_frame']
                        image = get_image_from_directory(image_frame, directory)
                        if image is not None:
                            texture = gpu.texture.from_image(image)
                            vertex_shader = '''
                                in vec2 pos;
                                in vec2 texCoord;
                                out vec2 TexCoord;
                                void main()
                                {
                                    TexCoord = texCoord;
                                    gl_Position = vec4(pos, 0.0, 1.0);
                                }
                            '''
                            fragment_shader = '''
                                in vec2 TexCoord;
                                uniform sampler2D image;
                                uniform float alpha;
                                out vec4 FragColor;
                                void main()
                                {
                                    vec4 textColor = texture(image, TexCoord);
                                    FragColor = vec4(textColor.rgb, textColor.a * alpha);
                                }
                            '''
                            # Create shader program
                            gpu.state.blend_set('ALPHA')
                            shader = gpu.types.GPUShader(vertex_shader, fragment_shader)
                            batch = gpu_extras.batch.batch_for_shader(
                                shader, 'TRI_FAN',
                                {
                                    "pos": coords,
                                    "texCoord": ((0, 0), (1, 0), (1, 1), (0, 1)),
                                },
                            )
                            # Use shader program
                            shader.bind()
                            # Set uniform values
                            shader.uniform_float("alpha", alpha)
                            shader.uniform_sampler("image", texture)
                            # Draw call
                            batch.draw(shader)
                            bpy.context.area.tag_redraw()
            else:
                if bpy.context.preferences.addons['savepolice'].preferences.sna_siren_custom:
                    if os.path.exists(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_path)):
                        region = bpy.context.region
                        norm_x = 2.0 / region.width
                        norm_y = 2.0 / region.height
                        bl_norm = (bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[0] * norm_x - 1, bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[1] * norm_y - 1)
                        width_norm = bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[0] * norm_x
                        height_norm = bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[1] * norm_y
                        coords = (
                            (bl_norm[0],bl_norm[1]),
                            (bl_norm[0] + width_norm, bl_norm[1]),
                            (bl_norm[0] + width_norm, bl_norm[1] + height_norm),
                            (bl_norm[0], bl_norm[1] + height_norm)
                        )
                        bpy.data.images.load(filepath=bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_path), check_existing=True, )

                        def get_img_name():
                            this = os.path.basename(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_path))
                            for i in range(len(bpy.data.images)):
                                if bpy.data.images[i].name == bpy.data.images[this].name:
                                    return bpy.data.images[i]
                        alpha = bpy.context.preferences.addons['savepolice'].preferences.sna_global_opacity
                        image = get_img_name()
                        texture = gpu.texture.from_image(image)
                        vertex_shader = '''
                            in vec2 pos;
                            in vec2 texCoord;
                            out vec2 TexCoord;
                            void main()
                            {
                                TexCoord = texCoord;
                                gl_Position = vec4(pos, 0.0, 1.0);
                            }
                        '''
                        fragment_shader = '''
                            in vec2 TexCoord;
                            uniform sampler2D image;
                            uniform float alpha;
                            out vec4 FragColor;
                            void main()
                            {
                                vec4 textColor = texture(image, TexCoord);
                                FragColor = vec4(textColor.rgb, textColor.a * alpha);
                            }
                        '''
                        # Create shader program
                        gpu.state.blend_set('ALPHA')
                        shader = gpu.types.GPUShader(vertex_shader, fragment_shader)
                        batch = gpu_extras.batch.batch_for_shader(
                            shader, 'TRI_FAN',
                            {
                                "pos": coords,
                                "texCoord": ((0, 0), (1, 0), (1, 1), (0, 1)),
                            },
                        )
                        # Use shader program
                        shader.bind()
                        # Set uniform values
                        shader.uniform_float("alpha", alpha)
                        shader.uniform_sampler("image", texture)
                        # Draw call
                        batch.draw(shader)
                        bpy.context.area.tag_redraw()
                else:
                    region = bpy.context.region
                    norm_x = 2.0 / region.width
                    norm_y = 2.0 / region.height
                    bl_norm = (bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[0] * norm_x - 1, bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[1] * norm_y - 1)
                    width_norm = bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[0] * norm_x
                    height_norm = bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[1] * norm_y
                    coords = (
                        (bl_norm[0],bl_norm[1]),
                        (bl_norm[0] + width_norm, bl_norm[1]),
                        (bl_norm[0] + width_norm, bl_norm[1] + height_norm),
                        (bl_norm[0], bl_norm[1] + height_norm)
                    )
                    bpy.data.images.load(filepath=os.path.join(os.path.dirname(__file__), 'assets', 'Siren_256x256_Render0013.png'), check_existing=True, )

                    def get_img_name():
                        this = os.path.basename(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_256x256_Render0013.png'))
                        for i in range(len(bpy.data.images)):
                            if bpy.data.images[i].name == bpy.data.images[this].name:
                                return bpy.data.images[i]
                    alpha = bpy.context.preferences.addons['savepolice'].preferences.sna_global_opacity
                    image = get_img_name()
                    texture = gpu.texture.from_image(image)
                    vertex_shader = '''
                        in vec2 pos;
                        in vec2 texCoord;
                        out vec2 TexCoord;
                        void main()
                        {
                            TexCoord = texCoord;
                            gl_Position = vec4(pos, 0.0, 1.0);
                        }
                    '''
                    fragment_shader = '''
                        in vec2 TexCoord;
                        uniform sampler2D image;
                        uniform float alpha;
                        out vec4 FragColor;
                        void main()
                        {
                            vec4 textColor = texture(image, TexCoord);
                            FragColor = vec4(textColor.rgb, textColor.a * alpha);
                        }
                    '''
                    # Create shader program
                    gpu.state.blend_set('ALPHA')
                    shader = gpu.types.GPUShader(vertex_shader, fragment_shader)
                    batch = gpu_extras.batch.batch_for_shader(
                        shader, 'TRI_FAN',
                        {
                            "pos": coords,
                            "texCoord": ((0, 0), (1, 0), (1, 1), (0, 1)),
                        },
                    )
                    # Use shader program
                    shader.bind()
                    # Set uniform values
                    shader.uniform_float("alpha", alpha)
                    shader.uniform_sampler("image", texture)
                    # Draw call
                    batch.draw(shader)
                    bpy.context.area.tag_redraw()
        if bpy.context.preferences.addons['savepolice'].preferences.sna_alert_use_message:
            font_id = 0
            if bpy.context.preferences.addons['savepolice'].preferences.sna_alert_font and os.path.exists(bpy.context.preferences.addons['savepolice'].preferences.sna_alert_font):
                font_id = blf.load(bpy.context.preferences.addons['savepolice'].preferences.sna_alert_font)
            if font_id == -1:
                print("Couldn't load font!")
            else:
                x_4468C, y_4468C = bpy.context.preferences.addons['savepolice'].preferences.sna_alert_message_location
                blf.position(font_id, x_4468C, y_4468C, 0)
                if bpy.app.version >= (3, 4, 0):
                    blf.size(font_id, bpy.context.preferences.addons['savepolice'].preferences.sna_alert_message_size)
                else:
                    blf.size(font_id, bpy.context.preferences.addons['savepolice'].preferences.sna_alert_message_size, bpy.context.preferences.addons['savepolice'].preferences.sna_alert_message_dpi)
                clr = (bpy.context.preferences.addons['savepolice'].preferences.sna_alert_color[0], bpy.context.preferences.addons['savepolice'].preferences.sna_alert_color[1], bpy.context.preferences.addons['savepolice'].preferences.sna_alert_color[2], eval("min(bpy.context.preferences.addons['savepolice'].preferences.sna_alert_color[3],bpy.context.preferences.addons['savepolice'].preferences.sna_global_opacity)"))
                blf.color(font_id, clr[0], clr[1], clr[2], clr[3])
                if bpy.context.preferences.addons['savepolice'].preferences.sna_alert_message_wrap:
                    blf.enable(font_id, blf.WORD_WRAP)
                    blf.word_wrap(font_id, bpy.context.preferences.addons['savepolice'].preferences.sna_alert_message_wrap)
                if bpy.context.preferences.addons['savepolice'].preferences.sna_alert_message_rotation:
                    blf.enable(font_id, blf.ROTATION)
                    blf.rotation(font_id, bpy.context.preferences.addons['savepolice'].preferences.sna_alert_message_rotation)
                blf.enable(font_id, blf.WORD_WRAP)
                blf.draw(font_id, bpy.context.preferences.addons['savepolice'].preferences.sna_alert_message)
                blf.disable(font_id, blf.ROTATION)
                blf.disable(font_id, blf.WORD_WRAP)


def sna_fn_draw_siren_end_8EADA():
    bpy.context.scene.sna_save_police_animation_active = False
    g_draw_alert_image_image_editor['sna_stop'] = True
    if handler_D8705:
        bpy.types.SpaceImageEditor.draw_handler_remove(handler_D8705[0], 'WINDOW')
        handler_D8705.pop(0)
        for a in bpy.context.screen.areas: a.tag_redraw()


def sna_fn_draw_siren_start_68E9D():
    g_draw_alert_image_image_editor['sna_frame'] = 0
    g_draw_alert_image_image_editor['sna_custom_frame_length'] = 0
    g_draw_alert_image_image_editor['sna_stop'] = False
    bpy.context.scene.sna_save_police_animation_active = True
    handler_D8705.append(bpy.types.SpaceImageEditor.draw_handler_add(sna_fn_modal_drawing_image_editor_B195C, (), 'WINDOW', 'POST_PIXEL'))
    for a in bpy.context.screen.areas: a.tag_redraw()
    if bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence:

        def delayed_3E6B7():
            if bpy.context.preferences.addons['savepolice'].preferences.sna_siren_custom:
                if os.path.isdir(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory)):
                    if (len([os.path.join(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory), f) for f in os.listdir(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory)) if os.path.isfile(os.path.join(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory), f))]) > 0):
                        g_draw_alert_image_image_editor['sna_custom_frame_length'] = len([os.path.join(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory), f) for f in os.listdir(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory)) if os.path.isfile(os.path.join(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory), f))])
                    else:
                        g_draw_alert_image_image_editor['sna_custom_frame_length'] = 0
                else:
                    g_draw_alert_image_image_editor['sna_custom_frame_length'] = 0
            g_draw_alert_image_image_editor['sna_frame'] += 1
            if (g_draw_alert_image_image_editor['sna_frame'] >= (g_draw_alert_image_image_editor['sna_custom_frame_length'] if bpy.context.preferences.addons['savepolice'].preferences.sna_siren_custom else 22)):
                g_draw_alert_image_image_editor['sna_frame'] = 0
            if g_draw_alert_image_image_editor['sna_stop']:
                return None
            return bpy.context.preferences.addons['savepolice'].preferences.sna_siren_interval
        bpy.app.timers.register(delayed_3E6B7, first_interval=0.0)


def sna_fn_modal_drawing_node_editor_BA36C():
    if bool(find_areas_of_type(bpy.context.screen, 'NODE_EDITOR')):
        if bpy.context.preferences.addons['savepolice'].preferences.sna_alert_use_background:
            if (os.path.exists(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_alert_background)) and bpy.context.preferences.addons['savepolice'].preferences.sna_alert_custom_background):
                region = bpy.context.region
                norm_x = 2.0 / region.width
                norm_y = 2.0 / region.height
                bl_norm = ((1.0, 1.0)[0] * norm_x - 1, (1.0, 1.0)[1] * norm_y - 1)
                width_norm = find_biggest_area_by_type(bpy.context.screen, 'NODE_EDITOR').width * norm_x
                height_norm = find_biggest_area_by_type(bpy.context.screen, 'NODE_EDITOR').height * norm_y
                coords = (
                    (bl_norm[0],bl_norm[1]),
                    (bl_norm[0] + width_norm, bl_norm[1]),
                    (bl_norm[0] + width_norm, bl_norm[1] + height_norm),
                    (bl_norm[0], bl_norm[1] + height_norm)
                )
                bpy.data.images.load(filepath=bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_alert_background), check_existing=True, )

                def get_img_name():
                    this = os.path.basename(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_alert_background))
                    for i in range(len(bpy.data.images)):
                        if bpy.data.images[i].name == bpy.data.images[this].name:
                            return bpy.data.images[i]
                alpha = bpy.context.preferences.addons['savepolice'].preferences.sna_global_opacity
                image = get_img_name()
                texture = gpu.texture.from_image(image)
                vertex_shader = '''
                    in vec2 pos;
                    in vec2 texCoord;
                    out vec2 TexCoord;
                    void main()
                    {
                        TexCoord = texCoord;
                        gl_Position = vec4(pos, 0.0, 1.0);
                    }
                '''
                fragment_shader = '''
                    in vec2 TexCoord;
                    uniform sampler2D image;
                    uniform float alpha;
                    out vec4 FragColor;
                    void main()
                    {
                        vec4 textColor = texture(image, TexCoord);
                        FragColor = vec4(textColor.rgb, textColor.a * alpha);
                    }
                '''
                # Create shader program
                gpu.state.blend_set('ALPHA')
                shader = gpu.types.GPUShader(vertex_shader, fragment_shader)
                batch = gpu_extras.batch.batch_for_shader(
                    shader, 'TRI_FAN',
                    {
                        "pos": coords,
                        "texCoord": ((0, 0), (1, 0), (1, 1), (0, 1)),
                    },
                )
                # Use shader program
                shader.bind()
                # Set uniform values
                shader.uniform_float("alpha", alpha)
                shader.uniform_sampler("image", texture)
                # Draw call
                batch.draw(shader)
                bpy.context.area.tag_redraw()
            else:
                quads = [[tuple((1.0, 1.0)), tuple((find_biggest_area_by_type(bpy.context.screen, 'NODE_EDITOR').width, 1.0)), tuple((1.0, find_biggest_area_by_type(bpy.context.screen, 'NODE_EDITOR').height)), tuple((find_biggest_area_by_type(bpy.context.screen, 'NODE_EDITOR').width, find_biggest_area_by_type(bpy.context.screen, 'NODE_EDITOR').height))]]
                vertices = []
                indices = []
                for i_1A51A, quad in enumerate(quads):
                    vertices.extend(quad)
                    indices.extend([(i_1A51A * 4, i_1A51A * 4 + 1, i_1A51A * 4 + 2), (i_1A51A * 4 + 2, i_1A51A * 4 + 1, i_1A51A * 4 + 3)])
                shader = gpu.shader.from_builtin('UNIFORM_COLOR')
                batch = gpu_extras.batch.batch_for_shader(shader, 'TRIS', {"pos": tuple(vertices)}, indices=tuple(indices))
                shader.bind()
                shader.uniform_float("color", (bpy.context.preferences.addons['savepolice'].preferences.sna_alert_background_color[0], bpy.context.preferences.addons['savepolice'].preferences.sna_alert_background_color[1], bpy.context.preferences.addons['savepolice'].preferences.sna_alert_background_color[2], eval("min(bpy.context.preferences.addons['savepolice'].preferences.sna_alert_background_color[3],bpy.context.preferences.addons['savepolice'].preferences.sna_global_opacity)")))
                gpu.state.blend_set('ALPHA')
                batch.draw(shader)
        if bpy.context.preferences.addons['savepolice'].preferences.sna_alert_use_image:
            if bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence:
                if bpy.context.preferences.addons['savepolice'].preferences.sna_siren_custom:
                    if os.path.isdir(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory)):
                        region = bpy.context.region
                        norm_x = 2.0 / region.width
                        norm_y = 2.0 / region.height
                        bl_norm = (bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[0] * norm_x - 1, bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[1] * norm_y - 1)
                        width_norm = bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[0] * norm_x
                        height_norm = bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[1] * norm_y
                        coords = (
                            (bl_norm[0],bl_norm[1]),
                            (bl_norm[0] + width_norm, bl_norm[1]),
                            (bl_norm[0] + width_norm, bl_norm[1] + height_norm),
                            (bl_norm[0], bl_norm[1] + height_norm)
                        )
                        alpha = bpy.context.preferences.addons['savepolice'].preferences.sna_global_opacity
                        directory = bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory)

                        def get_sequence_length(directory):
                            if not directory or not os.path.exists(directory):  # Check if the directory is empty or does not exist
                                return 0
                            try:
                                files = [f for f in os.listdir(directory) if f.endswith('.png')]
                                return min(len(files), 101)
                            except Exception as e:
                                print(f"An error occurred while getting the sequence length: {e}")
                                return 0
                        if directory:
                            sequence_length = get_sequence_length(directory)
                            start_frame_value = g_draw_alert_image_3d_view['sna_frame']
                            start_frame = max(0, min(100, start_frame_value))
                            end_frame_value = g_draw_alert_image_3d_view['sna_custom_frame_length']
                            end_frame = max(0, min(100, end_frame_value))
                            start_frame = min(start_frame, end_frame)
                            #Define Image Sequence Function

                            def get_image_from_directory(image_frame, directory):
                                files = [f for f in os.listdir(directory) if f.endswith('.png')]
                                files.sort()
                                sequence_length = min(get_sequence_length(directory), 101)
                                if 0 <= image_frame < sequence_length:
                                    image_path = os.path.join(directory, files[image_frame])
                                    bpy.data.images.load(filepath=image_path, check_existing=True)
                                    return bpy.data.images[os.path.basename(image_path)]
                                else:
                                    return None
                            image_frame = g_draw_alert_image_3d_view['sna_frame']
                            image = get_image_from_directory(image_frame, directory)
                            if image is not None:
                                texture = gpu.texture.from_image(image)
                                vertex_shader = '''
                                    in vec2 pos;
                                    in vec2 texCoord;
                                    out vec2 TexCoord;
                                    void main()
                                    {
                                        TexCoord = texCoord;
                                        gl_Position = vec4(pos, 0.0, 1.0);
                                    }
                                '''
                                fragment_shader = '''
                                    in vec2 TexCoord;
                                    uniform sampler2D image;
                                    uniform float alpha;
                                    out vec4 FragColor;
                                    void main()
                                    {
                                        vec4 textColor = texture(image, TexCoord);
                                        FragColor = vec4(textColor.rgb, textColor.a * alpha);
                                    }
                                '''
                                # Create shader program
                                gpu.state.blend_set('ALPHA')
                                shader = gpu.types.GPUShader(vertex_shader, fragment_shader)
                                batch = gpu_extras.batch.batch_for_shader(
                                    shader, 'TRI_FAN',
                                    {
                                        "pos": coords,
                                        "texCoord": ((0, 0), (1, 0), (1, 1), (0, 1)),
                                    },
                                )
                                # Use shader program
                                shader.bind()
                                # Set uniform values
                                shader.uniform_float("alpha", alpha)
                                shader.uniform_sampler("image", texture)
                                # Draw call
                                batch.draw(shader)
                                bpy.context.area.tag_redraw()
                else:
                    region = bpy.context.region
                    norm_x = 2.0 / region.width
                    norm_y = 2.0 / region.height
                    bl_norm = (bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[0] * norm_x - 1, bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[1] * norm_y - 1)
                    width_norm = bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[0] * norm_x
                    height_norm = bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[1] * norm_y
                    coords = (
                        (bl_norm[0],bl_norm[1]),
                        (bl_norm[0] + width_norm, bl_norm[1]),
                        (bl_norm[0] + width_norm, bl_norm[1] + height_norm),
                        (bl_norm[0], bl_norm[1] + height_norm)
                    )
                    alpha = bpy.context.preferences.addons['savepolice'].preferences.sna_global_opacity
                    directory = os.path.join(os.path.dirname(__file__), 'assets', 'Becon Composites 256 x 256')

                    def get_sequence_length(directory):
                        if not directory or not os.path.exists(directory):  # Check if the directory is empty or does not exist
                            return 0
                        try:
                            files = [f for f in os.listdir(directory) if f.endswith('.png')]
                            return min(len(files), 101)
                        except Exception as e:
                            print(f"An error occurred while getting the sequence length: {e}")
                            return 0
                    if directory:
                        sequence_length = get_sequence_length(directory)
                        start_frame_value = g_draw_alert_image_3d_view['sna_frame']
                        start_frame = max(0, min(100, start_frame_value))
                        end_frame_value = 22
                        end_frame = max(0, min(100, end_frame_value))
                        start_frame = min(start_frame, end_frame)
                        #Define Image Sequence Function

                        def get_image_from_directory(image_frame, directory):
                            files = [f for f in os.listdir(directory) if f.endswith('.png')]
                            files.sort()
                            sequence_length = min(get_sequence_length(directory), 101)
                            if 0 <= image_frame < sequence_length:
                                image_path = os.path.join(directory, files[image_frame])
                                bpy.data.images.load(filepath=image_path, check_existing=True)
                                return bpy.data.images[os.path.basename(image_path)]
                            else:
                                return None
                        image_frame = g_draw_alert_image_3d_view['sna_frame']
                        image = get_image_from_directory(image_frame, directory)
                        if image is not None:
                            texture = gpu.texture.from_image(image)
                            vertex_shader = '''
                                in vec2 pos;
                                in vec2 texCoord;
                                out vec2 TexCoord;
                                void main()
                                {
                                    TexCoord = texCoord;
                                    gl_Position = vec4(pos, 0.0, 1.0);
                                }
                            '''
                            fragment_shader = '''
                                in vec2 TexCoord;
                                uniform sampler2D image;
                                uniform float alpha;
                                out vec4 FragColor;
                                void main()
                                {
                                    vec4 textColor = texture(image, TexCoord);
                                    FragColor = vec4(textColor.rgb, textColor.a * alpha);
                                }
                            '''
                            # Create shader program
                            gpu.state.blend_set('ALPHA')
                            shader = gpu.types.GPUShader(vertex_shader, fragment_shader)
                            batch = gpu_extras.batch.batch_for_shader(
                                shader, 'TRI_FAN',
                                {
                                    "pos": coords,
                                    "texCoord": ((0, 0), (1, 0), (1, 1), (0, 1)),
                                },
                            )
                            # Use shader program
                            shader.bind()
                            # Set uniform values
                            shader.uniform_float("alpha", alpha)
                            shader.uniform_sampler("image", texture)
                            # Draw call
                            batch.draw(shader)
                            bpy.context.area.tag_redraw()
            else:
                if bpy.context.preferences.addons['savepolice'].preferences.sna_siren_custom:
                    if os.path.exists(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_path)):
                        region = bpy.context.region
                        norm_x = 2.0 / region.width
                        norm_y = 2.0 / region.height
                        bl_norm = (bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[0] * norm_x - 1, bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[1] * norm_y - 1)
                        width_norm = bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[0] * norm_x
                        height_norm = bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[1] * norm_y
                        coords = (
                            (bl_norm[0],bl_norm[1]),
                            (bl_norm[0] + width_norm, bl_norm[1]),
                            (bl_norm[0] + width_norm, bl_norm[1] + height_norm),
                            (bl_norm[0], bl_norm[1] + height_norm)
                        )
                        bpy.data.images.load(filepath=bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_path), check_existing=True, )

                        def get_img_name():
                            this = os.path.basename(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_path))
                            for i in range(len(bpy.data.images)):
                                if bpy.data.images[i].name == bpy.data.images[this].name:
                                    return bpy.data.images[i]
                        alpha = bpy.context.preferences.addons['savepolice'].preferences.sna_global_opacity
                        image = get_img_name()
                        texture = gpu.texture.from_image(image)
                        vertex_shader = '''
                            in vec2 pos;
                            in vec2 texCoord;
                            out vec2 TexCoord;
                            void main()
                            {
                                TexCoord = texCoord;
                                gl_Position = vec4(pos, 0.0, 1.0);
                            }
                        '''
                        fragment_shader = '''
                            in vec2 TexCoord;
                            uniform sampler2D image;
                            uniform float alpha;
                            out vec4 FragColor;
                            void main()
                            {
                                vec4 textColor = texture(image, TexCoord);
                                FragColor = vec4(textColor.rgb, textColor.a * alpha);
                            }
                        '''
                        # Create shader program
                        gpu.state.blend_set('ALPHA')
                        shader = gpu.types.GPUShader(vertex_shader, fragment_shader)
                        batch = gpu_extras.batch.batch_for_shader(
                            shader, 'TRI_FAN',
                            {
                                "pos": coords,
                                "texCoord": ((0, 0), (1, 0), (1, 1), (0, 1)),
                            },
                        )
                        # Use shader program
                        shader.bind()
                        # Set uniform values
                        shader.uniform_float("alpha", alpha)
                        shader.uniform_sampler("image", texture)
                        # Draw call
                        batch.draw(shader)
                        bpy.context.area.tag_redraw()
                else:
                    region = bpy.context.region
                    norm_x = 2.0 / region.width
                    norm_y = 2.0 / region.height
                    bl_norm = (bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[0] * norm_x - 1, bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[1] * norm_y - 1)
                    width_norm = bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[0] * norm_x
                    height_norm = bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[1] * norm_y
                    coords = (
                        (bl_norm[0],bl_norm[1]),
                        (bl_norm[0] + width_norm, bl_norm[1]),
                        (bl_norm[0] + width_norm, bl_norm[1] + height_norm),
                        (bl_norm[0], bl_norm[1] + height_norm)
                    )
                    bpy.data.images.load(filepath=os.path.join(os.path.dirname(__file__), 'assets', 'Siren_256x256_Render0013.png'), check_existing=True, )

                    def get_img_name():
                        this = os.path.basename(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_256x256_Render0013.png'))
                        for i in range(len(bpy.data.images)):
                            if bpy.data.images[i].name == bpy.data.images[this].name:
                                return bpy.data.images[i]
                    alpha = bpy.context.preferences.addons['savepolice'].preferences.sna_global_opacity
                    image = get_img_name()
                    texture = gpu.texture.from_image(image)
                    vertex_shader = '''
                        in vec2 pos;
                        in vec2 texCoord;
                        out vec2 TexCoord;
                        void main()
                        {
                            TexCoord = texCoord;
                            gl_Position = vec4(pos, 0.0, 1.0);
                        }
                    '''
                    fragment_shader = '''
                        in vec2 TexCoord;
                        uniform sampler2D image;
                        uniform float alpha;
                        out vec4 FragColor;
                        void main()
                        {
                            vec4 textColor = texture(image, TexCoord);
                            FragColor = vec4(textColor.rgb, textColor.a * alpha);
                        }
                    '''
                    # Create shader program
                    gpu.state.blend_set('ALPHA')
                    shader = gpu.types.GPUShader(vertex_shader, fragment_shader)
                    batch = gpu_extras.batch.batch_for_shader(
                        shader, 'TRI_FAN',
                        {
                            "pos": coords,
                            "texCoord": ((0, 0), (1, 0), (1, 1), (0, 1)),
                        },
                    )
                    # Use shader program
                    shader.bind()
                    # Set uniform values
                    shader.uniform_float("alpha", alpha)
                    shader.uniform_sampler("image", texture)
                    # Draw call
                    batch.draw(shader)
                    bpy.context.area.tag_redraw()
        if bpy.context.preferences.addons['savepolice'].preferences.sna_alert_use_message:
            font_id = 0
            if bpy.context.preferences.addons['savepolice'].preferences.sna_alert_font and os.path.exists(bpy.context.preferences.addons['savepolice'].preferences.sna_alert_font):
                font_id = blf.load(bpy.context.preferences.addons['savepolice'].preferences.sna_alert_font)
            if font_id == -1:
                print("Couldn't load font!")
            else:
                x_8C5FD, y_8C5FD = bpy.context.preferences.addons['savepolice'].preferences.sna_alert_message_location
                blf.position(font_id, x_8C5FD, y_8C5FD, 0)
                if bpy.app.version >= (3, 4, 0):
                    blf.size(font_id, bpy.context.preferences.addons['savepolice'].preferences.sna_alert_message_size)
                else:
                    blf.size(font_id, bpy.context.preferences.addons['savepolice'].preferences.sna_alert_message_size, bpy.context.preferences.addons['savepolice'].preferences.sna_alert_message_dpi)
                clr = (bpy.context.preferences.addons['savepolice'].preferences.sna_alert_color[0], bpy.context.preferences.addons['savepolice'].preferences.sna_alert_color[1], bpy.context.preferences.addons['savepolice'].preferences.sna_alert_color[2], eval("min(bpy.context.preferences.addons['savepolice'].preferences.sna_alert_color[3],bpy.context.preferences.addons['savepolice'].preferences.sna_global_opacity)"))
                blf.color(font_id, clr[0], clr[1], clr[2], clr[3])
                if bpy.context.preferences.addons['savepolice'].preferences.sna_alert_message_wrap:
                    blf.enable(font_id, blf.WORD_WRAP)
                    blf.word_wrap(font_id, bpy.context.preferences.addons['savepolice'].preferences.sna_alert_message_wrap)
                if bpy.context.preferences.addons['savepolice'].preferences.sna_alert_message_rotation:
                    blf.enable(font_id, blf.ROTATION)
                    blf.rotation(font_id, bpy.context.preferences.addons['savepolice'].preferences.sna_alert_message_rotation)
                blf.enable(font_id, blf.WORD_WRAP)
                blf.draw(font_id, bpy.context.preferences.addons['savepolice'].preferences.sna_alert_message)
                blf.disable(font_id, blf.ROTATION)
                blf.disable(font_id, blf.WORD_WRAP)


def sna_fn_draw_siren_end_2CF21():
    bpy.context.scene.sna_save_police_animation_active = False
    g_draw_alert_image_node_editor['sna_stop'] = True
    if handler_AAAFB:
        bpy.types.SpaceNodeEditor.draw_handler_remove(handler_AAAFB[0], 'WINDOW')
        handler_AAAFB.pop(0)
        for a in bpy.context.screen.areas: a.tag_redraw()


def sna_fn_draw_siren_start_00FEB():
    g_draw_alert_image_node_editor['sna_frame'] = 0
    g_draw_alert_image_node_editor['sna_custom_frame_length'] = 0
    g_draw_alert_image_node_editor['sna_stop'] = False
    bpy.context.scene.sna_save_police_animation_active = True
    handler_AAAFB.append(bpy.types.SpaceNodeEditor.draw_handler_add(sna_fn_modal_drawing_node_editor_BA36C, (), 'WINDOW', 'POST_PIXEL'))
    for a in bpy.context.screen.areas: a.tag_redraw()
    if bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence:

        def delayed_EAB06():
            if bpy.context.preferences.addons['savepolice'].preferences.sna_siren_custom:
                if os.path.isdir(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory)):
                    if (len([os.path.join(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory), f) for f in os.listdir(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory)) if os.path.isfile(os.path.join(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory), f))]) > 0):
                        g_draw_alert_image_node_editor['sna_custom_frame_length'] = len([os.path.join(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory), f) for f in os.listdir(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory)) if os.path.isfile(os.path.join(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory), f))])
                    else:
                        g_draw_alert_image_node_editor['sna_custom_frame_length'] = 0
                else:
                    g_draw_alert_image_node_editor['sna_custom_frame_length'] = 0
            g_draw_alert_image_node_editor['sna_frame'] += 1
            if (g_draw_alert_image_node_editor['sna_frame'] >= (g_draw_alert_image_node_editor['sna_custom_frame_length'] if bpy.context.preferences.addons['savepolice'].preferences.sna_siren_custom else 22)):
                g_draw_alert_image_node_editor['sna_frame'] = 0
            if g_draw_alert_image_node_editor['sna_stop']:
                return None
            return bpy.context.preferences.addons['savepolice'].preferences.sna_siren_interval
        bpy.app.timers.register(delayed_EAB06, first_interval=0.0)


class SNA_OT_Save_Police_Preview_Alert_Image_558A3(bpy.types.Operator):
    bl_idname = "sna.save_police_preview_alert_image_558a3"
    bl_label = "Save Police Preview Alert Image"
    bl_description = "Preview the Alert Message"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('Image is active wait until it is inactive')
        return not bpy.context.scene.sna_save_police_animation_active

    def execute(self, context):
        if (not bpy.context.scene.sna_save_police_animation_active):
            if (bool(find_areas_of_type(bpy.context.screen, 'VIEW_3D')) and bpy.context.preferences.addons['savepolice'].preferences.sna_alert_3d_viewport):
                sna_fn_draw_siren_start_FE25B()
            if (bool(find_areas_of_type(bpy.context.screen, 'NODE_EDITOR')) and bpy.context.preferences.addons['savepolice'].preferences.sna_alert_node_editors):
                sna_fn_draw_siren_start_00FEB()
            if (bool(find_areas_of_type(bpy.context.screen, 'IMAGE_EDITOR')) and bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_editor):
                sna_fn_draw_siren_start_68E9D()
            if (bool(find_areas_of_type(bpy.context.screen, 'SEQUENCE_EDITOR')) and bpy.context.preferences.addons['savepolice'].preferences.sna_alert_video_sequencer):
                sna_fn_draw_siren_start_279D8()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Save_Police_End_Alert_Image_Preview_7A41B(bpy.types.Operator):
    bl_idname = "sna.save_police_end_alert_image_preview_7a41b"
    bl_label = "Save Police End Alert Image Preview"
    bl_description = "Preview the Alert Message"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_fn_draw_siren_end_5EC29()
        sna_fn_draw_siren_end_2CF21()
        sna_fn_draw_siren_end_8EADA()
        sna_fn_draw_siren_end_CC28D()
        sna_fn_removed_unused_images_A2907()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_fn_modal_drawing_vse_F7409():
    if bool(find_areas_of_type(bpy.context.screen, 'SEQUENCE_EDITOR')):
        if bpy.context.preferences.addons['savepolice'].preferences.sna_alert_use_background:
            if (os.path.exists(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_alert_background)) and bpy.context.preferences.addons['savepolice'].preferences.sna_alert_custom_background):
                region = bpy.context.region
                norm_x = 2.0 / region.width
                norm_y = 2.0 / region.height
                bl_norm = ((1.0, 1.0)[0] * norm_x - 1, (1.0, 1.0)[1] * norm_y - 1)
                width_norm = find_biggest_area_by_type(bpy.context.screen, 'SEQUENCE_EDITOR').width * norm_x
                height_norm = find_biggest_area_by_type(bpy.context.screen, 'SEQUENCE_EDITOR').height * norm_y
                coords = (
                    (bl_norm[0],bl_norm[1]),
                    (bl_norm[0] + width_norm, bl_norm[1]),
                    (bl_norm[0] + width_norm, bl_norm[1] + height_norm),
                    (bl_norm[0], bl_norm[1] + height_norm)
                )
                bpy.data.images.load(filepath=bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_alert_background), check_existing=True, )

                def get_img_name():
                    this = os.path.basename(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_alert_background))
                    for i in range(len(bpy.data.images)):
                        if bpy.data.images[i].name == bpy.data.images[this].name:
                            return bpy.data.images[i]
                alpha = bpy.context.preferences.addons['savepolice'].preferences.sna_global_opacity
                image = get_img_name()
                texture = gpu.texture.from_image(image)
                vertex_shader = '''
                    in vec2 pos;
                    in vec2 texCoord;
                    out vec2 TexCoord;
                    void main()
                    {
                        TexCoord = texCoord;
                        gl_Position = vec4(pos, 0.0, 1.0);
                    }
                '''
                fragment_shader = '''
                    in vec2 TexCoord;
                    uniform sampler2D image;
                    uniform float alpha;
                    out vec4 FragColor;
                    void main()
                    {
                        vec4 textColor = texture(image, TexCoord);
                        FragColor = vec4(textColor.rgb, textColor.a * alpha);
                    }
                '''
                # Create shader program
                gpu.state.blend_set('ALPHA')
                shader = gpu.types.GPUShader(vertex_shader, fragment_shader)
                batch = gpu_extras.batch.batch_for_shader(
                    shader, 'TRI_FAN',
                    {
                        "pos": coords,
                        "texCoord": ((0, 0), (1, 0), (1, 1), (0, 1)),
                    },
                )
                # Use shader program
                shader.bind()
                # Set uniform values
                shader.uniform_float("alpha", alpha)
                shader.uniform_sampler("image", texture)
                # Draw call
                batch.draw(shader)
                bpy.context.area.tag_redraw()
            else:
                quads = [[tuple((1.0, 1.0)), tuple((find_biggest_area_by_type(bpy.context.screen, 'SEQUENCE_EDITOR').width, 1.0)), tuple((1.0, find_biggest_area_by_type(bpy.context.screen, 'SEQUENCE_EDITOR').height)), tuple((find_biggest_area_by_type(bpy.context.screen, 'SEQUENCE_EDITOR').width, find_biggest_area_by_type(bpy.context.screen, 'SEQUENCE_EDITOR').height))]]
                vertices = []
                indices = []
                for i_91289, quad in enumerate(quads):
                    vertices.extend(quad)
                    indices.extend([(i_91289 * 4, i_91289 * 4 + 1, i_91289 * 4 + 2), (i_91289 * 4 + 2, i_91289 * 4 + 1, i_91289 * 4 + 3)])
                shader = gpu.shader.from_builtin('UNIFORM_COLOR')
                batch = gpu_extras.batch.batch_for_shader(shader, 'TRIS', {"pos": tuple(vertices)}, indices=tuple(indices))
                shader.bind()
                shader.uniform_float("color", (bpy.context.preferences.addons['savepolice'].preferences.sna_alert_background_color[0], bpy.context.preferences.addons['savepolice'].preferences.sna_alert_background_color[1], bpy.context.preferences.addons['savepolice'].preferences.sna_alert_background_color[2], eval("min(bpy.context.preferences.addons['savepolice'].preferences.sna_alert_background_color[3],bpy.context.preferences.addons['savepolice'].preferences.sna_global_opacity)")))
                gpu.state.blend_set('ALPHA')
                batch.draw(shader)
        if bpy.context.preferences.addons['savepolice'].preferences.sna_alert_use_image:
            if bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence:
                if bpy.context.preferences.addons['savepolice'].preferences.sna_siren_custom:
                    if os.path.isdir(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory)):
                        region = bpy.context.region
                        norm_x = 2.0 / region.width
                        norm_y = 2.0 / region.height
                        bl_norm = (bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[0] * norm_x - 1, bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[1] * norm_y - 1)
                        width_norm = bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[0] * norm_x
                        height_norm = bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[1] * norm_y
                        coords = (
                            (bl_norm[0],bl_norm[1]),
                            (bl_norm[0] + width_norm, bl_norm[1]),
                            (bl_norm[0] + width_norm, bl_norm[1] + height_norm),
                            (bl_norm[0], bl_norm[1] + height_norm)
                        )
                        alpha = bpy.context.preferences.addons['savepolice'].preferences.sna_global_opacity
                        directory = bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory)

                        def get_sequence_length(directory):
                            if not directory or not os.path.exists(directory):  # Check if the directory is empty or does not exist
                                return 0
                            try:
                                files = [f for f in os.listdir(directory) if f.endswith('.png')]
                                return min(len(files), 101)
                            except Exception as e:
                                print(f"An error occurred while getting the sequence length: {e}")
                                return 0
                        if directory:
                            sequence_length = get_sequence_length(directory)
                            start_frame_value = g_draw_alert_image_3d_view['sna_frame']
                            start_frame = max(0, min(100, start_frame_value))
                            end_frame_value = g_draw_alert_image_3d_view['sna_custom_frame_length']
                            end_frame = max(0, min(100, end_frame_value))
                            start_frame = min(start_frame, end_frame)
                            #Define Image Sequence Function

                            def get_image_from_directory(image_frame, directory):
                                files = [f for f in os.listdir(directory) if f.endswith('.png')]
                                files.sort()
                                sequence_length = min(get_sequence_length(directory), 101)
                                if 0 <= image_frame < sequence_length:
                                    image_path = os.path.join(directory, files[image_frame])
                                    bpy.data.images.load(filepath=image_path, check_existing=True)
                                    return bpy.data.images[os.path.basename(image_path)]
                                else:
                                    return None
                            image_frame = g_draw_alert_image_3d_view['sna_frame']
                            image = get_image_from_directory(image_frame, directory)
                            if image is not None:
                                texture = gpu.texture.from_image(image)
                                vertex_shader = '''
                                    in vec2 pos;
                                    in vec2 texCoord;
                                    out vec2 TexCoord;
                                    void main()
                                    {
                                        TexCoord = texCoord;
                                        gl_Position = vec4(pos, 0.0, 1.0);
                                    }
                                '''
                                fragment_shader = '''
                                    in vec2 TexCoord;
                                    uniform sampler2D image;
                                    uniform float alpha;
                                    out vec4 FragColor;
                                    void main()
                                    {
                                        vec4 textColor = texture(image, TexCoord);
                                        FragColor = vec4(textColor.rgb, textColor.a * alpha);
                                    }
                                '''
                                # Create shader program
                                gpu.state.blend_set('ALPHA')
                                shader = gpu.types.GPUShader(vertex_shader, fragment_shader)
                                batch = gpu_extras.batch.batch_for_shader(
                                    shader, 'TRI_FAN',
                                    {
                                        "pos": coords,
                                        "texCoord": ((0, 0), (1, 0), (1, 1), (0, 1)),
                                    },
                                )
                                # Use shader program
                                shader.bind()
                                # Set uniform values
                                shader.uniform_float("alpha", alpha)
                                shader.uniform_sampler("image", texture)
                                # Draw call
                                batch.draw(shader)
                                bpy.context.area.tag_redraw()
                else:
                    region = bpy.context.region
                    norm_x = 2.0 / region.width
                    norm_y = 2.0 / region.height
                    bl_norm = (bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[0] * norm_x - 1, bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[1] * norm_y - 1)
                    width_norm = bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[0] * norm_x
                    height_norm = bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[1] * norm_y
                    coords = (
                        (bl_norm[0],bl_norm[1]),
                        (bl_norm[0] + width_norm, bl_norm[1]),
                        (bl_norm[0] + width_norm, bl_norm[1] + height_norm),
                        (bl_norm[0], bl_norm[1] + height_norm)
                    )
                    alpha = bpy.context.preferences.addons['savepolice'].preferences.sna_global_opacity
                    directory = os.path.join(os.path.dirname(__file__), 'assets', 'Becon Composites 256 x 256')

                    def get_sequence_length(directory):
                        if not directory or not os.path.exists(directory):  # Check if the directory is empty or does not exist
                            return 0
                        try:
                            files = [f for f in os.listdir(directory) if f.endswith('.png')]
                            return min(len(files), 101)
                        except Exception as e:
                            print(f"An error occurred while getting the sequence length: {e}")
                            return 0
                    if directory:
                        sequence_length = get_sequence_length(directory)
                        start_frame_value = g_draw_alert_image_3d_view['sna_frame']
                        start_frame = max(0, min(100, start_frame_value))
                        end_frame_value = 22
                        end_frame = max(0, min(100, end_frame_value))
                        start_frame = min(start_frame, end_frame)
                        #Define Image Sequence Function

                        def get_image_from_directory(image_frame, directory):
                            files = [f for f in os.listdir(directory) if f.endswith('.png')]
                            files.sort()
                            sequence_length = min(get_sequence_length(directory), 101)
                            if 0 <= image_frame < sequence_length:
                                image_path = os.path.join(directory, files[image_frame])
                                bpy.data.images.load(filepath=image_path, check_existing=True)
                                return bpy.data.images[os.path.basename(image_path)]
                            else:
                                return None
                        image_frame = g_draw_alert_image_3d_view['sna_frame']
                        image = get_image_from_directory(image_frame, directory)
                        if image is not None:
                            texture = gpu.texture.from_image(image)
                            vertex_shader = '''
                                in vec2 pos;
                                in vec2 texCoord;
                                out vec2 TexCoord;
                                void main()
                                {
                                    TexCoord = texCoord;
                                    gl_Position = vec4(pos, 0.0, 1.0);
                                }
                            '''
                            fragment_shader = '''
                                in vec2 TexCoord;
                                uniform sampler2D image;
                                uniform float alpha;
                                out vec4 FragColor;
                                void main()
                                {
                                    vec4 textColor = texture(image, TexCoord);
                                    FragColor = vec4(textColor.rgb, textColor.a * alpha);
                                }
                            '''
                            # Create shader program
                            gpu.state.blend_set('ALPHA')
                            shader = gpu.types.GPUShader(vertex_shader, fragment_shader)
                            batch = gpu_extras.batch.batch_for_shader(
                                shader, 'TRI_FAN',
                                {
                                    "pos": coords,
                                    "texCoord": ((0, 0), (1, 0), (1, 1), (0, 1)),
                                },
                            )
                            # Use shader program
                            shader.bind()
                            # Set uniform values
                            shader.uniform_float("alpha", alpha)
                            shader.uniform_sampler("image", texture)
                            # Draw call
                            batch.draw(shader)
                            bpy.context.area.tag_redraw()
            else:
                if bpy.context.preferences.addons['savepolice'].preferences.sna_siren_custom:
                    if os.path.exists(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_path)):
                        region = bpy.context.region
                        norm_x = 2.0 / region.width
                        norm_y = 2.0 / region.height
                        bl_norm = (bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[0] * norm_x - 1, bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[1] * norm_y - 1)
                        width_norm = bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[0] * norm_x
                        height_norm = bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[1] * norm_y
                        coords = (
                            (bl_norm[0],bl_norm[1]),
                            (bl_norm[0] + width_norm, bl_norm[1]),
                            (bl_norm[0] + width_norm, bl_norm[1] + height_norm),
                            (bl_norm[0], bl_norm[1] + height_norm)
                        )
                        bpy.data.images.load(filepath=bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_path), check_existing=True, )

                        def get_img_name():
                            this = os.path.basename(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_path))
                            for i in range(len(bpy.data.images)):
                                if bpy.data.images[i].name == bpy.data.images[this].name:
                                    return bpy.data.images[i]
                        alpha = bpy.context.preferences.addons['savepolice'].preferences.sna_global_opacity
                        image = get_img_name()
                        texture = gpu.texture.from_image(image)
                        vertex_shader = '''
                            in vec2 pos;
                            in vec2 texCoord;
                            out vec2 TexCoord;
                            void main()
                            {
                                TexCoord = texCoord;
                                gl_Position = vec4(pos, 0.0, 1.0);
                            }
                        '''
                        fragment_shader = '''
                            in vec2 TexCoord;
                            uniform sampler2D image;
                            uniform float alpha;
                            out vec4 FragColor;
                            void main()
                            {
                                vec4 textColor = texture(image, TexCoord);
                                FragColor = vec4(textColor.rgb, textColor.a * alpha);
                            }
                        '''
                        # Create shader program
                        gpu.state.blend_set('ALPHA')
                        shader = gpu.types.GPUShader(vertex_shader, fragment_shader)
                        batch = gpu_extras.batch.batch_for_shader(
                            shader, 'TRI_FAN',
                            {
                                "pos": coords,
                                "texCoord": ((0, 0), (1, 0), (1, 1), (0, 1)),
                            },
                        )
                        # Use shader program
                        shader.bind()
                        # Set uniform values
                        shader.uniform_float("alpha", alpha)
                        shader.uniform_sampler("image", texture)
                        # Draw call
                        batch.draw(shader)
                        bpy.context.area.tag_redraw()
                else:
                    region = bpy.context.region
                    norm_x = 2.0 / region.width
                    norm_y = 2.0 / region.height
                    bl_norm = (bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[0] * norm_x - 1, bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[1] * norm_y - 1)
                    width_norm = bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[0] * norm_x
                    height_norm = bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[1] * norm_y
                    coords = (
                        (bl_norm[0],bl_norm[1]),
                        (bl_norm[0] + width_norm, bl_norm[1]),
                        (bl_norm[0] + width_norm, bl_norm[1] + height_norm),
                        (bl_norm[0], bl_norm[1] + height_norm)
                    )
                    bpy.data.images.load(filepath=os.path.join(os.path.dirname(__file__), 'assets', 'Siren_256x256_Render0013.png'), check_existing=True, )

                    def get_img_name():
                        this = os.path.basename(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_256x256_Render0013.png'))
                        for i in range(len(bpy.data.images)):
                            if bpy.data.images[i].name == bpy.data.images[this].name:
                                return bpy.data.images[i]
                    alpha = bpy.context.preferences.addons['savepolice'].preferences.sna_global_opacity
                    image = get_img_name()
                    texture = gpu.texture.from_image(image)
                    vertex_shader = '''
                        in vec2 pos;
                        in vec2 texCoord;
                        out vec2 TexCoord;
                        void main()
                        {
                            TexCoord = texCoord;
                            gl_Position = vec4(pos, 0.0, 1.0);
                        }
                    '''
                    fragment_shader = '''
                        in vec2 TexCoord;
                        uniform sampler2D image;
                        uniform float alpha;
                        out vec4 FragColor;
                        void main()
                        {
                            vec4 textColor = texture(image, TexCoord);
                            FragColor = vec4(textColor.rgb, textColor.a * alpha);
                        }
                    '''
                    # Create shader program
                    gpu.state.blend_set('ALPHA')
                    shader = gpu.types.GPUShader(vertex_shader, fragment_shader)
                    batch = gpu_extras.batch.batch_for_shader(
                        shader, 'TRI_FAN',
                        {
                            "pos": coords,
                            "texCoord": ((0, 0), (1, 0), (1, 1), (0, 1)),
                        },
                    )
                    # Use shader program
                    shader.bind()
                    # Set uniform values
                    shader.uniform_float("alpha", alpha)
                    shader.uniform_sampler("image", texture)
                    # Draw call
                    batch.draw(shader)
                    bpy.context.area.tag_redraw()
        if bpy.context.preferences.addons['savepolice'].preferences.sna_alert_use_message:
            font_id = 0
            if bpy.context.preferences.addons['savepolice'].preferences.sna_alert_font and os.path.exists(bpy.context.preferences.addons['savepolice'].preferences.sna_alert_font):
                font_id = blf.load(bpy.context.preferences.addons['savepolice'].preferences.sna_alert_font)
            if font_id == -1:
                print("Couldn't load font!")
            else:
                x_0081E, y_0081E = bpy.context.preferences.addons['savepolice'].preferences.sna_alert_message_location
                blf.position(font_id, x_0081E, y_0081E, 0)
                if bpy.app.version >= (3, 4, 0):
                    blf.size(font_id, bpy.context.preferences.addons['savepolice'].preferences.sna_alert_message_size)
                else:
                    blf.size(font_id, bpy.context.preferences.addons['savepolice'].preferences.sna_alert_message_size, bpy.context.preferences.addons['savepolice'].preferences.sna_alert_message_dpi)
                clr = (bpy.context.preferences.addons['savepolice'].preferences.sna_alert_color[0], bpy.context.preferences.addons['savepolice'].preferences.sna_alert_color[1], bpy.context.preferences.addons['savepolice'].preferences.sna_alert_color[2], eval("min(bpy.context.preferences.addons['savepolice'].preferences.sna_alert_color[3],bpy.context.preferences.addons['savepolice'].preferences.sna_global_opacity)"))
                blf.color(font_id, clr[0], clr[1], clr[2], clr[3])
                if bpy.context.preferences.addons['savepolice'].preferences.sna_alert_message_wrap:
                    blf.enable(font_id, blf.WORD_WRAP)
                    blf.word_wrap(font_id, bpy.context.preferences.addons['savepolice'].preferences.sna_alert_message_wrap)
                if bpy.context.preferences.addons['savepolice'].preferences.sna_alert_message_rotation:
                    blf.enable(font_id, blf.ROTATION)
                    blf.rotation(font_id, bpy.context.preferences.addons['savepolice'].preferences.sna_alert_message_rotation)
                blf.enable(font_id, blf.WORD_WRAP)
                blf.draw(font_id, bpy.context.preferences.addons['savepolice'].preferences.sna_alert_message)
                blf.disable(font_id, blf.ROTATION)
                blf.disable(font_id, blf.WORD_WRAP)


def sna_fn_draw_siren_end_CC28D():
    bpy.context.scene.sna_save_police_animation_active = False
    g_draw_alert_image_vse_editor['sna_stop'] = True
    if handler_CB41D:
        bpy.types.SpaceSequenceEditor.draw_handler_remove(handler_CB41D[0], 'WINDOW')
        handler_CB41D.pop(0)
        for a in bpy.context.screen.areas: a.tag_redraw()


def sna_fn_draw_siren_start_279D8():
    g_draw_alert_image_vse_editor['sna_frame'] = 0
    g_draw_alert_image_vse_editor['sna_custom_frame_length'] = 0
    g_draw_alert_image_vse_editor['sna_stop'] = False
    bpy.context.scene.sna_save_police_animation_active = True
    handler_CB41D.append(bpy.types.SpaceSequenceEditor.draw_handler_add(sna_fn_modal_drawing_vse_F7409, (), 'WINDOW', 'POST_PIXEL'))
    for a in bpy.context.screen.areas: a.tag_redraw()
    if bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence:

        def delayed_8C706():
            if bpy.context.preferences.addons['savepolice'].preferences.sna_siren_custom:
                if os.path.isdir(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory)):
                    if (len([os.path.join(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory), f) for f in os.listdir(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory)) if os.path.isfile(os.path.join(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory), f))]) > 0):
                        g_draw_alert_image_vse_editor['sna_custom_frame_length'] = len([os.path.join(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory), f) for f in os.listdir(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory)) if os.path.isfile(os.path.join(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory), f))])
                    else:
                        g_draw_alert_image_vse_editor['sna_custom_frame_length'] = 0
                else:
                    g_draw_alert_image_vse_editor['sna_custom_frame_length'] = 0
            g_draw_alert_image_vse_editor['sna_frame'] += 1
            if (g_draw_alert_image_vse_editor['sna_frame'] >= (g_draw_alert_image_vse_editor['sna_custom_frame_length'] if bpy.context.preferences.addons['savepolice'].preferences.sna_siren_custom else 22)):
                g_draw_alert_image_vse_editor['sna_frame'] = 0
            if g_draw_alert_image_vse_editor['sna_stop']:
                return None
            return bpy.context.preferences.addons['savepolice'].preferences.sna_siren_interval
        bpy.app.timers.register(delayed_8C706, first_interval=0.0)


def sna_fn_modal_drawing_D4923():
    if bpy.context.preferences.addons['savepolice'].preferences.sna_use_countdown:
        font_id = 0
        if bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_font and os.path.exists(bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_font):
            font_id = blf.load(bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_font)
        if font_id == -1:
            print("Couldn't load font!")
        else:
            x_ACAA8, y_ACAA8 = bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_location
            blf.position(font_id, x_ACAA8, y_ACAA8, 0)
            if bpy.app.version >= (3, 4, 0):
                blf.size(font_id, bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_size)
            else:
                blf.size(font_id, bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_size, bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_dpi)
            clr = (bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_color[0], bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_color[1], bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_color[2], eval("min(bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_color[3],bpy.context.preferences.addons['savepolice'].preferences.sna_global_opacity)"))
            blf.color(font_id, clr[0], clr[1], clr[2], clr[3])
            if bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_wrap:
                blf.enable(font_id, blf.WORD_WRAP)
                blf.word_wrap(font_id, bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_wrap)
            if bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_rotation:
                blf.enable(font_id, blf.ROTATION)
                blf.rotation(font_id, bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_rotation)
            blf.enable(font_id, blf.WORD_WRAP)
            blf.draw(font_id, (graph_scripts['sna_time_message'] + ' ' + bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_suffix_message if bpy.data.is_dirty else ''))
            blf.disable(font_id, blf.ROTATION)
            blf.disable(font_id, blf.WORD_WRAP)


def sna_fn_draw_siren_start_9B9BB():
    bpy.context.scene.sna_save_police_countdown_active = True
    handler_EE591.append(bpy.types.SpaceView3D.draw_handler_add(sna_fn_modal_drawing_D4923, (), 'WINDOW', 'POST_PIXEL'))
    for a in bpy.context.screen.areas: a.tag_redraw()


def sna_fn_draw_siren_end_4F626():
    bpy.context.scene.sna_save_police_countdown_active = False
    if handler_EE591:
        bpy.types.SpaceView3D.draw_handler_remove(handler_EE591[0], 'WINDOW')
        handler_EE591.pop(0)
        for a in bpy.context.screen.areas: a.tag_redraw()


def sna_fn_modal_drawing_7B865():
    if bpy.context.preferences.addons['savepolice'].preferences.sna_use_countdown:
        font_id = 0
        if bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_font and os.path.exists(bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_font):
            font_id = blf.load(bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_font)
        if font_id == -1:
            print("Couldn't load font!")
        else:
            x_9D87E, y_9D87E = bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_location
            blf.position(font_id, x_9D87E, y_9D87E, 0)
            if bpy.app.version >= (3, 4, 0):
                blf.size(font_id, bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_size)
            else:
                blf.size(font_id, bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_size, bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_dpi)
            clr = (bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_color[0], bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_color[1], bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_color[2], eval("min(bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_color[3],bpy.context.preferences.addons['savepolice'].preferences.sna_global_opacity)"))
            blf.color(font_id, clr[0], clr[1], clr[2], clr[3])
            if bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_wrap:
                blf.enable(font_id, blf.WORD_WRAP)
                blf.word_wrap(font_id, bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_wrap)
            if bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_rotation:
                blf.enable(font_id, blf.ROTATION)
                blf.rotation(font_id, bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_rotation)
            blf.enable(font_id, blf.WORD_WRAP)
            blf.draw(font_id, (graph_scripts['sna_time_message'] + ' ' + bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_suffix_message if bpy.data.is_dirty else ''))
            blf.disable(font_id, blf.ROTATION)
            blf.disable(font_id, blf.WORD_WRAP)


def sna_fn_draw_siren_start_D3208():
    bpy.context.scene.sna_save_police_countdown_active = True
    handler_A1E89.append(bpy.types.SpaceImageEditor.draw_handler_add(sna_fn_modal_drawing_7B865, (), 'WINDOW', 'POST_PIXEL'))
    for a in bpy.context.screen.areas: a.tag_redraw()


def sna_fn_draw_siren_end_B1BAE():
    bpy.context.scene.sna_save_police_countdown_active = False
    if handler_A1E89:
        bpy.types.SpaceImageEditor.draw_handler_remove(handler_A1E89[0], 'WINDOW')
        handler_A1E89.pop(0)
        for a in bpy.context.screen.areas: a.tag_redraw()


def sna_fn_modal_drawing_18530():
    if bpy.context.preferences.addons['savepolice'].preferences.sna_use_countdown:
        font_id = 0
        if bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_font and os.path.exists(bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_font):
            font_id = blf.load(bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_font)
        if font_id == -1:
            print("Couldn't load font!")
        else:
            x_9030D, y_9030D = bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_location
            blf.position(font_id, x_9030D, y_9030D, 0)
            if bpy.app.version >= (3, 4, 0):
                blf.size(font_id, bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_size)
            else:
                blf.size(font_id, bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_size, bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_dpi)
            clr = (bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_color[0], bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_color[1], bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_color[2], eval("min(bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_color[3],bpy.context.preferences.addons['savepolice'].preferences.sna_global_opacity)"))
            blf.color(font_id, clr[0], clr[1], clr[2], clr[3])
            if bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_wrap:
                blf.enable(font_id, blf.WORD_WRAP)
                blf.word_wrap(font_id, bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_wrap)
            if bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_rotation:
                blf.enable(font_id, blf.ROTATION)
                blf.rotation(font_id, bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_rotation)
            blf.enable(font_id, blf.WORD_WRAP)
            blf.draw(font_id, (graph_scripts['sna_time_message'] + ' ' + bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_suffix_message if bpy.data.is_dirty else ''))
            blf.disable(font_id, blf.ROTATION)
            blf.disable(font_id, blf.WORD_WRAP)


def sna_fn_draw_siren_start_99929():
    bpy.context.scene.sna_save_police_countdown_active = True
    handler_0A529.append(bpy.types.SpaceNodeEditor.draw_handler_add(sna_fn_modal_drawing_18530, (), 'WINDOW', 'POST_PIXEL'))
    for a in bpy.context.screen.areas: a.tag_redraw()


def sna_fn_draw_siren_end_05897():
    bpy.context.scene.sna_save_police_countdown_active = False
    if handler_0A529:
        bpy.types.SpaceNodeEditor.draw_handler_remove(handler_0A529[0], 'WINDOW')
        handler_0A529.pop(0)
        for a in bpy.context.screen.areas: a.tag_redraw()


class SNA_OT_Save_Police_End_Countdown_Preview_8F673(bpy.types.Operator):
    bl_idname = "sna.save_police_end_countdown_preview_8f673"
    bl_label = "Save Police End Countdown Preview"
    bl_description = "Stop drawing the countdown on screen"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_fn_draw_siren_end_4F626()
        sna_fn_draw_siren_end_05897()
        sna_fn_draw_siren_end_B1BAE()
        sna_fn_draw_siren_end_CFEC7()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Save_Police_Preview_Countdown_8B9F0(bpy.types.Operator):
    bl_idname = "sna.save_police_preview_countdown_8b9f0"
    bl_label = "Save Police Preview Countdown"
    bl_description = "Draw the countdown on screen"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('Must disable drawing first')
        return not bpy.context.scene.sna_save_police_countdown_active

    def execute(self, context):
        if (not bpy.context.scene.sna_save_police_countdown_active):
            if (bool(find_areas_of_type(bpy.context.screen, 'VIEW_3D')) and bpy.context.preferences.addons['savepolice'].preferences.sna_alert_3d_viewport):
                sna_fn_draw_siren_start_9B9BB()
            if (bool(find_areas_of_type(bpy.context.screen, 'NODE_EDITOR')) and bpy.context.preferences.addons['savepolice'].preferences.sna_alert_node_editors):
                sna_fn_draw_siren_start_99929()
            if (bool(find_areas_of_type(bpy.context.screen, 'IMAGE_EDITOR')) and bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_editor):
                sna_fn_draw_siren_start_D3208()
            if (bool(find_areas_of_type(bpy.context.screen, 'SEQUENCE_EDITOR')) and bpy.context.preferences.addons['savepolice'].preferences.sna_alert_video_sequencer):
                sna_fn_draw_siren_start_89390()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Save_Police_Draw_Countdown_F091C(bpy.types.Operator):
    bl_idname = "sna.save_police_draw_countdown_f091c"
    bl_label = "Save Police Draw Countdown"
    bl_description = "Draw the countdown on screen"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('Must disable drawing first')
        return not bpy.context.scene.sna_save_police_countdown_active

    def execute(self, context):
        if bpy.context.preferences.addons['savepolice'].preferences.sna_call_the_save_police:
            if (not bpy.context.scene.sna_save_police_reminder):
                if (not bpy.context.scene.sna_save_police_countdown_active):
                    if (bool(find_areas_of_type(bpy.context.screen, 'VIEW_3D')) and bpy.context.preferences.addons['savepolice'].preferences.sna_alert_3d_viewport):
                        sna_fn_draw_siren_start_9B9BB()
                    if (bool(find_areas_of_type(bpy.context.screen, 'NODE_EDITOR')) and bpy.context.preferences.addons['savepolice'].preferences.sna_alert_node_editors):
                        sna_fn_draw_siren_start_99929()
                    if (bool(find_areas_of_type(bpy.context.screen, 'IMAGE_EDITOR')) and bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_editor):
                        sna_fn_draw_siren_start_D3208()
                    if (bool(find_areas_of_type(bpy.context.screen, 'SEQUENCE_EDITOR')) and bpy.context.preferences.addons['savepolice'].preferences.sna_alert_video_sequencer):
                        sna_fn_draw_siren_start_89390()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_fn_modal_drawing_4D6EA():
    if bpy.context.preferences.addons['savepolice'].preferences.sna_use_countdown:
        font_id = 0
        if bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_font and os.path.exists(bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_font):
            font_id = blf.load(bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_font)
        if font_id == -1:
            print("Couldn't load font!")
        else:
            x_C929F, y_C929F = bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_location
            blf.position(font_id, x_C929F, y_C929F, 0)
            if bpy.app.version >= (3, 4, 0):
                blf.size(font_id, bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_size)
            else:
                blf.size(font_id, bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_size, bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_dpi)
            clr = (bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_color[0], bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_color[1], bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_color[2], eval("min(bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_color[3],bpy.context.preferences.addons['savepolice'].preferences.sna_global_opacity)"))
            blf.color(font_id, clr[0], clr[1], clr[2], clr[3])
            if bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_wrap:
                blf.enable(font_id, blf.WORD_WRAP)
                blf.word_wrap(font_id, bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_wrap)
            if bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_rotation:
                blf.enable(font_id, blf.ROTATION)
                blf.rotation(font_id, bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_rotation)
            blf.enable(font_id, blf.WORD_WRAP)
            blf.draw(font_id, (graph_scripts['sna_time_message'] + ' ' + bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_suffix_message if bpy.data.is_dirty else ''))
            blf.disable(font_id, blf.ROTATION)
            blf.disable(font_id, blf.WORD_WRAP)


def sna_fn_draw_siren_start_89390():
    bpy.context.scene.sna_save_police_countdown_active = True
    handler_F57E6.append(bpy.types.SpaceSequenceEditor.draw_handler_add(sna_fn_modal_drawing_4D6EA, (), 'WINDOW', 'POST_PIXEL'))
    for a in bpy.context.screen.areas: a.tag_redraw()


def sna_fn_draw_siren_end_CFEC7():
    bpy.context.scene.sna_save_police_countdown_active = False
    if handler_F57E6:
        bpy.types.SpaceSequenceEditor.draw_handler_remove(handler_F57E6[0], 'WINDOW')
        handler_F57E6.pop(0)
        for a in bpy.context.screen.areas: a.tag_redraw()


class SNA_OT_Add_Icon_70949(bpy.types.Operator):
    bl_idname = "sna.add_icon_70949"
    bl_label = "Add Icon"
    bl_description = "Add a Save Police Icon"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        item_FED82 = bpy.context.preferences.addons['savepolice'].preferences.sna_icons_collection.add()
        if bpy.context and bpy.context.screen:
            for a in bpy.context.screen.areas:
                a.tag_redraw()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Remove_Icon_C74E7(bpy.types.Operator):
    bl_idname = "sna.remove_icon_c74e7"
    bl_label = "Remove Icon"
    bl_description = "Remove the save police icon"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if (bpy.context.scene.sna_save_police_icons_index <= int(len(list(bpy.context.preferences.addons['savepolice'].preferences.sna_icons_collection)) - 1.0)):
            if (property_exists("bpy.context.preferences.addons['savepolice'].preferences.sna_icons_collection", globals(), locals()) and len(bpy.context.preferences.addons['savepolice'].preferences.sna_icons_collection) > bpy.context.scene.sna_save_police_icons_index):
                if len(bpy.context.preferences.addons['savepolice'].preferences.sna_icons_collection) > bpy.context.scene.sna_save_police_icons_index:
                    bpy.context.preferences.addons['savepolice'].preferences.sna_icons_collection.remove(bpy.context.scene.sna_save_police_icons_index)
        if bpy.context and bpy.context.screen:
            for a in bpy.context.screen.areas:
                a.tag_redraw()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Move_Icon_Up_Add44(bpy.types.Operator):
    bl_idname = "sna.move_icon_up_add44"
    bl_label = "Move Icon Up"
    bl_description = "Move Save Police Icon Up"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if (bpy.context.scene.sna_save_police_icons_index > 0):
            bpy.context.preferences.addons['savepolice'].preferences.sna_icons_collection.move(bpy.context.scene.sna_save_police_icons_index, int(bpy.context.scene.sna_save_police_icons_index - 1.0))
            item_B7492 = bpy.context.preferences.addons['savepolice'].preferences.sna_icons_collection[int(bpy.context.scene.sna_save_police_icons_index - 1.0)]
            bpy.context.scene.sna_save_police_icons_index = int(bpy.context.scene.sna_save_police_icons_index - 1.0)
        if bpy.context and bpy.context.screen:
            for a in bpy.context.screen.areas:
                a.tag_redraw()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Move_Icon_Down_Cffa5(bpy.types.Operator):
    bl_idname = "sna.move_icon_down_cffa5"
    bl_label = "Move Icon Down"
    bl_description = "Move Save Police Icon Down"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if (bpy.context.scene.sna_save_police_icons_index < int(len(list(bpy.context.preferences.addons['savepolice'].preferences.sna_icons_collection)) - 1.0)):
            bpy.context.preferences.addons['savepolice'].preferences.sna_icons_collection.move(bpy.context.scene.sna_save_police_icons_index, int(bpy.context.scene.sna_save_police_icons_index + 1.0))
            item_F38FA = bpy.context.preferences.addons['savepolice'].preferences.sna_icons_collection[int(bpy.context.scene.sna_save_police_icons_index + 1.0)]
            bpy.context.scene.sna_save_police_icons_index = int(bpy.context.scene.sna_save_police_icons_index + 1.0)
        if bpy.context and bpy.context.screen:
            for a in bpy.context.screen.areas:
                a.tag_redraw()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


_DA3AC_running = False
class SNA_OT_Save_Police_Move_Countdown_Da3Ac(bpy.types.Operator):
    bl_idname = "sna.save_police_move_countdown_da3ac"
    bl_label = "Save Police Move Countdown"
    bl_description = "Move the Countdown with the Cursor"
    bl_options = {"REGISTER", "UNDO"}
    sna_countdown_loc_initial: bpy.props.FloatVectorProperty(name='countdown_loc_initial', description='', size=2, default=(1.0, 1.0), subtype='NONE', unit='NONE', min=1.0, step=10, precision=1)
    sna_countdown_size_initial: bpy.props.FloatProperty(name='countdown_size_initial', description='', default=1.0, subtype='NONE', unit='NONE', min=1.0, step=5, precision=1)
    cursor = "CROSSHAIR"
    _handle = None
    _event = {}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        if not False or context.area.spaces[0].bl_rna.identifier == 'SpaceNodeEditor':
            return not False
        return False

    def save_event(self, event):
        event_options = ["type", "value", "alt", "shift", "ctrl", "oskey", "mouse_region_x", "mouse_region_y", "mouse_x", "mouse_y", "pressure", "tilt"]
        if bpy.app.version >= (3, 2, 1):
            event_options += ["type_prev", "value_prev"]
        for option in event_options: self._event[option] = getattr(event, option)

    def draw_callback_px(self, context):
        event = self._event
        if event.keys():
            event = dotdict(event)
            try:
                pass
            except Exception as error:
                print(error)

    def execute(self, context):
        global _DA3AC_running
        _DA3AC_running = False
        context.window.cursor_set("DEFAULT")
        for area in context.screen.areas:
            area.tag_redraw()
        return {"FINISHED"}

    def modal(self, context, event):
        global _DA3AC_running
        if not context.area or not _DA3AC_running:
            self.execute(context)
            return {'CANCELLED'}
        self.save_event(event)
        context.window.cursor_set('CROSSHAIR')
        try:
            if ((event.type == 'ESC') or (event.type == 'RIGHTMOUSE')):
                bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_location = self.sna_countdown_loc_initial
                bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_size = self.sna_countdown_size_initial
                if event.type in ['RIGHTMOUSE', 'ESC']:
                    self.execute(context)
                    return {'CANCELLED'}
                return {"CANCELLED"}
            else:
                if ((event.type == 'LEFTMOUSE') or (event.type == 'RET')):
                    if event.type in ['RIGHTMOUSE', 'ESC']:
                        self.execute(context)
                        return {'CANCELLED'}
                    self.execute(context)
                    return {"FINISHED"}
                else:
                    if (event.type == 'WHEELUPMOUSE'):
                        bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_size = float(bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_size + 10.0)
                        if bpy.context and bpy.context.screen:
                            for a in bpy.context.screen.areas:
                                a.tag_redraw()
                    else:
                        if (event.type == 'WHEELDOWNMOUSE'):
                            bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_size = float(bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_size - 10.0)
                            if bpy.context and bpy.context.screen:
                                for a in bpy.context.screen.areas:
                                    a.tag_redraw()
                        else:
                            bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_location = (event.mouse_x, event.mouse_y)
                            if bpy.context and bpy.context.screen:
                                for a in bpy.context.screen.areas:
                                    a.tag_redraw()
        except Exception as error:
            print(error)
        if event.type in ['RIGHTMOUSE', 'ESC']:
            self.execute(context)
            return {'CANCELLED'}
        return {'RUNNING_MODAL'}

    def invoke(self, context, event):
        global _DA3AC_running
        if _DA3AC_running:
            _DA3AC_running = False
            return {'FINISHED'}
        else:
            self.save_event(event)
            self.start_pos = (event.mouse_x, event.mouse_y)
            bpy.context.window.cursor_warp(x=int(tuple(map(lambda v: int(v), bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_location))[0]), y=int(tuple(map(lambda v: int(v), bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_location))[1]), )
            self.sna_countdown_loc_initial = bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_location
            self.sna_countdown_size_initial = bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_size
            context.window_manager.modal_handler_add(self)
            _DA3AC_running = True
            return {'RUNNING_MODAL'}


_F9F28_running = False
class SNA_OT_Save_Police_Move_Image_F9F28(bpy.types.Operator):
    bl_idname = "sna.save_police_move_image_f9f28"
    bl_label = "Save Police Move Image"
    bl_description = "Move the Image with the Cursor"
    bl_options = {"REGISTER", "UNDO"}
    sna_alert_loc_initial: bpy.props.FloatVectorProperty(name='alert_loc_initial', description='', size=2, default=(1.0, 1.0), subtype='NONE', unit='NONE', min=1.0, step=5, precision=1)
    sna_alert_size_initial: bpy.props.FloatVectorProperty(name='alert_size_initial', description='', size=2, default=(1.0, 1.0), subtype='NONE', unit='NONE', min=8.0, step=10, precision=1)
    cursor = "HAND"
    _handle = None
    _event = {}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        if not False or context.area.spaces[0].bl_rna.identifier == 'SpaceNodeEditor':
            return not False
        return False

    def save_event(self, event):
        event_options = ["type", "value", "alt", "shift", "ctrl", "oskey", "mouse_region_x", "mouse_region_y", "mouse_x", "mouse_y", "pressure", "tilt"]
        if bpy.app.version >= (3, 2, 1):
            event_options += ["type_prev", "value_prev"]
        for option in event_options: self._event[option] = getattr(event, option)

    def draw_callback_px(self, context):
        event = self._event
        if event.keys():
            event = dotdict(event)
            try:
                pass
            except Exception as error:
                print(error)

    def execute(self, context):
        global _F9F28_running
        _F9F28_running = False
        context.window.cursor_set("DEFAULT")
        for area in context.screen.areas:
            area.tag_redraw()
        return {"FINISHED"}

    def modal(self, context, event):
        global _F9F28_running
        if not context.area or not _F9F28_running:
            self.execute(context)
            return {'CANCELLED'}
        self.save_event(event)
        context.window.cursor_set('HAND')
        try:
            if ((event.type == 'ESC') or (event.type == 'RIGHTMOUSE')):
                bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location = self.sna_alert_loc_initial
                bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size = self.sna_alert_size_initial
                if event.type in ['RIGHTMOUSE', 'ESC']:
                    self.execute(context)
                    return {'CANCELLED'}
                return {"CANCELLED"}
            else:
                if ((event.type == 'LEFTMOUSE') or (event.type == 'RET')):
                    if event.type in ['RIGHTMOUSE', 'ESC']:
                        self.execute(context)
                        return {'CANCELLED'}
                    self.execute(context)
                    return {"FINISHED"}
                else:
                    if (event.type == 'WHEELUPMOUSE'):
                        bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size = tuple(mathutils.Vector(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size) + mathutils.Vector((40.0, 40.0)))
                        if bpy.context and bpy.context.screen:
                            for a in bpy.context.screen.areas:
                                a.tag_redraw()
                    else:
                        if (event.type == 'WHEELDOWNMOUSE'):
                            bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size = tuple(mathutils.Vector(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size) - mathutils.Vector((40.0, 40.0)))
                            if bpy.context and bpy.context.screen:
                                for a in bpy.context.screen.areas:
                                    a.tag_redraw()
                        else:
                            bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location = (event.mouse_x, event.mouse_y)
                            if bpy.context and bpy.context.screen:
                                for a in bpy.context.screen.areas:
                                    a.tag_redraw()
        except Exception as error:
            print(error)
        if event.type in ['RIGHTMOUSE', 'ESC']:
            self.execute(context)
            return {'CANCELLED'}
        return {'RUNNING_MODAL'}

    def invoke(self, context, event):
        global _F9F28_running
        if _F9F28_running:
            _F9F28_running = False
            return {'FINISHED'}
        else:
            self.save_event(event)
            self.start_pos = (event.mouse_x, event.mouse_y)
            bpy.context.window.cursor_warp(x=int(tuple(map(lambda v: int(v), bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location))[0]), y=int(tuple(map(lambda v: int(v), bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location))[1]), )
            self.sna_alert_loc_initial = bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location
            self.sna_alert_size_initial = bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size
            context.window_manager.modal_handler_add(self)
            _F9F28_running = True
            return {'RUNNING_MODAL'}


_582F8_running = False
class SNA_OT_Save_Police_Move_Message_582F8(bpy.types.Operator):
    bl_idname = "sna.save_police_move_message_582f8"
    bl_label = "Save Police Move Message"
    bl_description = "Move the Message with the Cursor"
    bl_options = {"REGISTER", "UNDO"}
    sna_alert_loc_initial: bpy.props.FloatVectorProperty(name='alert_loc_initial', description='initial location of alert image', size=2, default=(1.0, 1.0), subtype='NONE', unit='NONE', min=1.0, step=10, precision=1)
    sna_alert_size_initial: bpy.props.FloatProperty(name='alert_size_initial', description='', default=1.0, subtype='NONE', unit='NONE', min=1.0, step=5, precision=1)
    cursor = "HAND"
    _handle = None
    _event = {}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        if not False or context.area.spaces[0].bl_rna.identifier == 'SpaceNodeEditor':
            return not False
        return False

    def save_event(self, event):
        event_options = ["type", "value", "alt", "shift", "ctrl", "oskey", "mouse_region_x", "mouse_region_y", "mouse_x", "mouse_y", "pressure", "tilt"]
        if bpy.app.version >= (3, 2, 1):
            event_options += ["type_prev", "value_prev"]
        for option in event_options: self._event[option] = getattr(event, option)

    def draw_callback_px(self, context):
        event = self._event
        if event.keys():
            event = dotdict(event)
            try:
                pass
            except Exception as error:
                print(error)

    def execute(self, context):
        global _582F8_running
        _582F8_running = False
        context.window.cursor_set("DEFAULT")
        for area in context.screen.areas:
            area.tag_redraw()
        return {"FINISHED"}

    def modal(self, context, event):
        global _582F8_running
        if not context.area or not _582F8_running:
            self.execute(context)
            return {'CANCELLED'}
        self.save_event(event)
        context.window.cursor_set('HAND')
        try:
            if ((event.type == 'ESC') or (event.type == 'RIGHTMOUSE')):
                bpy.context.preferences.addons['savepolice'].preferences.sna_alert_message_location = self.sna_alert_loc_initial
                bpy.context.preferences.addons['savepolice'].preferences.sna_alert_message_size = self.sna_alert_size_initial
                if event.type in ['RIGHTMOUSE', 'ESC']:
                    self.execute(context)
                    return {'CANCELLED'}
                return {"CANCELLED"}
            else:
                if ((event.type == 'LEFTMOUSE') or (event.type == 'RET')):
                    if event.type in ['RIGHTMOUSE', 'ESC']:
                        self.execute(context)
                        return {'CANCELLED'}
                    self.execute(context)
                    return {"FINISHED"}
                else:
                    if (event.type == 'WHEELUPMOUSE'):
                        bpy.context.preferences.addons['savepolice'].preferences.sna_alert_message_size = float(bpy.context.preferences.addons['savepolice'].preferences.sna_alert_message_size + 10.0)
                        if bpy.context and bpy.context.screen:
                            for a in bpy.context.screen.areas:
                                a.tag_redraw()
                    else:
                        if (event.type == 'WHEELDOWNMOUSE'):
                            bpy.context.preferences.addons['savepolice'].preferences.sna_alert_message_size = float(bpy.context.preferences.addons['savepolice'].preferences.sna_alert_message_size - 10.0)
                            if bpy.context and bpy.context.screen:
                                for a in bpy.context.screen.areas:
                                    a.tag_redraw()
                        else:
                            bpy.context.preferences.addons['savepolice'].preferences.sna_alert_message_location = (event.mouse_x, event.mouse_y)
                            if bpy.context and bpy.context.screen:
                                for a in bpy.context.screen.areas:
                                    a.tag_redraw()
        except Exception as error:
            print(error)
        if event.type in ['RIGHTMOUSE', 'ESC']:
            self.execute(context)
            return {'CANCELLED'}
        return {'RUNNING_MODAL'}

    def invoke(self, context, event):
        global _582F8_running
        if _582F8_running:
            _582F8_running = False
            return {'FINISHED'}
        else:
            self.save_event(event)
            self.start_pos = (event.mouse_x, event.mouse_y)
            bpy.context.window.cursor_warp(x=int(tuple(map(lambda v: int(v), bpy.context.preferences.addons['savepolice'].preferences.sna_alert_message_location))[0]), y=int(tuple(map(lambda v: int(v), bpy.context.preferences.addons['savepolice'].preferences.sna_alert_message_location))[1]), )
            self.sna_alert_loc_initial = bpy.context.preferences.addons['savepolice'].preferences.sna_alert_message_location
            self.sna_alert_size_initial = bpy.context.preferences.addons['savepolice'].preferences.sna_alert_message_size
            context.window_manager.modal_handler_add(self)
            _582F8_running = True
            return {'RUNNING_MODAL'}


def sna_fn_removed_unused_images_A2907():
    if os.path.exists(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_path)):
        if (property_exists("bpy.data.images", globals(), locals()) and os.path.basename(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_path)) in bpy.data.images):
            if (0 == bpy.data.images[os.path.basename(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_path))].users):
                bpy.data.images.remove(image=bpy.data.images[os.path.basename(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_path))], do_unlink=True, do_id_user=True, do_ui_user=True, )
    if os.path.exists(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory)):
        if [os.path.join(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory), f) for f in os.listdir(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory)) if os.path.isfile(os.path.join(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory), f))]:
            for i_BCF06 in range(len([os.path.join(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory), f) for f in os.listdir(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory)) if os.path.isfile(os.path.join(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory), f))])):
                if os.path.exists([os.path.join(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory), f) for f in os.listdir(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory)) if os.path.isfile(os.path.join(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory), f))][i_BCF06]):
                    if (property_exists("bpy.data.images", globals(), locals()) and os.path.basename([os.path.join(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory), f) for f in os.listdir(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory)) if os.path.isfile(os.path.join(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory), f))][i_BCF06]) in bpy.data.images):
                        if (0 == bpy.data.images[os.path.basename([os.path.join(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory), f) for f in os.listdir(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory)) if os.path.isfile(os.path.join(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory), f))][i_BCF06])].users):
                            bpy.data.images.remove(image=bpy.data.images[os.path.basename([os.path.join(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory), f) for f in os.listdir(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory)) if os.path.isfile(os.path.join(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory), f))][i_BCF06])], do_unlink=True, do_id_user=True, do_ui_user=True, )
    if os.path.exists(bpy.path.abspath(os.path.join(os.path.dirname(__file__), 'assets', 'Becon Composites 256 x 256'))):
        if [os.path.join(bpy.path.abspath(os.path.join(os.path.dirname(__file__), 'assets', 'Becon Composites 256 x 256')), f) for f in os.listdir(bpy.path.abspath(os.path.join(os.path.dirname(__file__), 'assets', 'Becon Composites 256 x 256'))) if os.path.isfile(os.path.join(bpy.path.abspath(os.path.join(os.path.dirname(__file__), 'assets', 'Becon Composites 256 x 256')), f))]:
            for i_85208 in range(len([os.path.join(bpy.path.abspath(os.path.join(os.path.dirname(__file__), 'assets', 'Becon Composites 256 x 256')), f) for f in os.listdir(bpy.path.abspath(os.path.join(os.path.dirname(__file__), 'assets', 'Becon Composites 256 x 256'))) if os.path.isfile(os.path.join(bpy.path.abspath(os.path.join(os.path.dirname(__file__), 'assets', 'Becon Composites 256 x 256')), f))])):
                if os.path.exists([os.path.join(bpy.path.abspath(os.path.join(os.path.dirname(__file__), 'assets', 'Becon Composites 256 x 256')), f) for f in os.listdir(bpy.path.abspath(os.path.join(os.path.dirname(__file__), 'assets', 'Becon Composites 256 x 256'))) if os.path.isfile(os.path.join(bpy.path.abspath(os.path.join(os.path.dirname(__file__), 'assets', 'Becon Composites 256 x 256')), f))][i_85208]):
                    if (property_exists("bpy.data.images", globals(), locals()) and os.path.basename([os.path.join(bpy.path.abspath(os.path.join(os.path.dirname(__file__), 'assets', 'Becon Composites 256 x 256')), f) for f in os.listdir(bpy.path.abspath(os.path.join(os.path.dirname(__file__), 'assets', 'Becon Composites 256 x 256'))) if os.path.isfile(os.path.join(bpy.path.abspath(os.path.join(os.path.dirname(__file__), 'assets', 'Becon Composites 256 x 256')), f))][i_85208]) in bpy.data.images):
                        if (0 == bpy.data.images[os.path.basename([os.path.join(bpy.path.abspath(os.path.join(os.path.dirname(__file__), 'assets', 'Becon Composites 256 x 256')), f) for f in os.listdir(bpy.path.abspath(os.path.join(os.path.dirname(__file__), 'assets', 'Becon Composites 256 x 256'))) if os.path.isfile(os.path.join(bpy.path.abspath(os.path.join(os.path.dirname(__file__), 'assets', 'Becon Composites 256 x 256')), f))][i_85208])].users):
                            bpy.data.images.remove(image=bpy.data.images[os.path.basename([os.path.join(bpy.path.abspath(os.path.join(os.path.dirname(__file__), 'assets', 'Becon Composites 256 x 256')), f) for f in os.listdir(bpy.path.abspath(os.path.join(os.path.dirname(__file__), 'assets', 'Becon Composites 256 x 256'))) if os.path.isfile(os.path.join(bpy.path.abspath(os.path.join(os.path.dirname(__file__), 'assets', 'Becon Composites 256 x 256')), f))][i_85208])], do_unlink=True, do_id_user=True, do_ui_user=True, )
    if os.path.exists(bpy.path.abspath(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_256x256_Render0013.png'))):
        if (property_exists("bpy.data.images", globals(), locals()) and os.path.basename(bpy.path.abspath(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_256x256_Render0013.png'))) in bpy.data.images):
            if (0 == bpy.data.images[os.path.basename(bpy.path.abspath(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_256x256_Render0013.png')))].users):
                bpy.data.images.remove(image=bpy.data.images[os.path.basename(bpy.path.abspath(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_256x256_Render0013.png')))], do_unlink=True, do_id_user=True, do_ui_user=True, )
    if os.path.exists(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_alert_background)):
        if (property_exists("bpy.data.images", globals(), locals()) and os.path.basename(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_alert_background)) in bpy.data.images):
            if (0 == bpy.data.images[os.path.basename(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_alert_background))].users):
                bpy.data.images.remove(image=bpy.data.images[os.path.basename(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_alert_background))], do_unlink=True, do_id_user=True, do_ui_user=True, )


class SNA_OT_Save_Police_Reload_Save_Collection_14F82(bpy.types.Operator):
    bl_idname = "sna.save_police_reload_save_collection_14f82"
    bl_label = "Save Police Reload Save Collection"
    bl_description = "Reload the Collection list where the save file lives. If there is no save file yet but the default folder exists then load from there"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if bpy.context.preferences.addons['savepolice'].preferences.sna_view_single_or_multiple_projects:
            if bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_directory_collection:
                bpy.context.scene.sna_save_police_collection.clear()
                sna_fn_add_collection_from_folder_3ACEE(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_directory_collection[bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_directory_collection_index].directory))
        else:
            if sna_fn_check_for_folder_325DF(bpy.data.filepath):
                bpy.context.scene.sna_save_police_collection.clear()
                sna_fn_add_collection_from_folder_3ACEE(os.path.dirname(bpy.data.filepath))
            else:
                if sna_fn_check_for_folder_325DF(bpy.context.preferences.addons['savepolice'].preferences.sna_default_folder):
                    bpy.context.scene.sna_save_police_collection.clear()
                    sna_fn_add_collection_from_folder_3ACEE(bpy.context.preferences.addons['savepolice'].preferences.sna_default_folder)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_fn_check_for_folder_325DF(path_exists):
    g_save_police_collection['sna_check_for_folder'] = False
    if bool(path_exists):
        if os.path.exists(path_exists):
            g_save_police_collection['sna_check_for_folder'] = True
    return g_save_police_collection['sna_check_for_folder']


class SNA_OT_Save_Police_Add_To_Save_Collection_Fc42D(bpy.types.Operator):
    bl_idname = "sna.save_police_add_to_save_collection_fc42d"
    bl_label = "Save Police Add to Save Collection"
    bl_description = "If the file is not in the save collection then add it"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if sna_fn_check_for_folder_325DF(bpy.data.filepath):
            g_save_police_collection['sna_file_exists'] = False
            for i_A5A6E in range(len(bpy.context.scene.sna_save_police_collection)):
                if (bpy.context.scene.sna_save_police_collection[i_A5A6E].save_police_file_name == os.path.basename(bpy.data.filepath).replace('.blend', '')):
                    g_save_police_collection['sna_file_exists'] = True
                    break
            if g_save_police_collection['sna_file_exists']:
                pass
            else:
                item_F6153 = bpy.context.scene.sna_save_police_collection.add()
                item_F6153.save_police_file_name = os.path.basename(bpy.data.filepath).replace('.blend', '')
                item_F6153.save_police_file = bpy.path.abspath(bpy.data.filepath)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Open_Save_Police_File_B25Ee(bpy.types.Operator):
    bl_idname = "sna.open_save_police_file_b25ee"
    bl_label = "Open Save Police File"
    bl_description = "Open the saved blend file"
    bl_options = {"REGISTER", "UNDO"}
    sna_save_file_filepath: bpy.props.StringProperty(name='save_file_filepath', description='Save Police file filepath', default='', subtype='FILE_PATH', maxlen=0)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if sna_fn_check_for_folder_325DF(self.sna_save_file_filepath):
            bpy.ops.wm.open_mainfile(filepath=bpy.path.abspath(self.sna_save_file_filepath))
        return {"FINISHED"}

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)


def sna_fn_add_collection_from_folder_3ACEE(folder):
    g_save_police_collection['sna_prog'] = 0.0
    g_save_police_collection['sna_list_length'] = 0.0
    g_save_police_collection['sna_list_length'] = len([os.path.join(folder, f) for f in os.listdir(folder) if os.path.isfile(os.path.join(folder, f))])
    for i_F8138 in range(len([os.path.join(folder, f) for f in os.listdir(folder) if os.path.isfile(os.path.join(folder, f))])):
        g_save_police_collection['sna_prog'] = eval("(i_F8138+1) / (g_save_police_collection['sna_list_length'])")
        if (os.path.splitext([os.path.join(folder, f) for f in os.listdir(folder) if os.path.isfile(os.path.join(folder, f))][i_F8138])[1] == '.blend'):
            item_2BC29 = bpy.context.scene.sna_save_police_collection.add()
            item_2BC29.save_police_file_name = os.path.basename([os.path.join(folder, f) for f in os.listdir(folder) if os.path.isfile(os.path.join(folder, f))][i_F8138]).replace('.blend', '')
            item_2BC29.save_police_file = bpy.path.abspath([os.path.join(folder, f) for f in os.listdir(folder) if os.path.isfile(os.path.join(folder, f))][i_F8138])
    if bpy.context and bpy.context.screen:
        for a in bpy.context.screen.areas:
            a.tag_redraw()


class SNA_OT_Delete_File_Eea1A(bpy.types.Operator):
    bl_idname = "sna.delete_file_eea1a"
    bl_label = "Delete File"
    bl_description = "Delete the selected file"
    bl_options = {"REGISTER", "UNDO"}
    sna_file_path: bpy.props.StringProperty(name='file path', description='', default='', subtype='FILE_PATH', maxlen=0)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if os.path.exists(self.sna_file_path):
            if (bpy.path.abspath(self.sna_file_path) != bpy.path.abspath(bpy.data.filepath)):
                file_path = bpy.path.abspath(self.sna_file_path)
                # Check if the file exists
                if os.path.exists(file_path):
                    # Delete the file
                    os.remove(file_path)
                    print(f"🚨 Save Police has deleted {file_path}")
                else:
                    print(f"🚨 Save Police cannot delete {file_path}")
                bpy.ops.sna.save_police_reload_save_collection_14f82()
                if (bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_directory_collection_index > 0):
                    if (bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_directory_collection_index >= int(len(list(bpy.context.scene.sna_save_police_collection)) - 1.0)):
                        bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_directory_collection_index = int(len(list(bpy.context.scene.sna_save_police_collection)) - 1.0)
                self.report({'INFO'}, message='🚨 You have deleted ' + os.path.basename(self.sna_file_path))
            else:
                self.report({'WARNING'}, message='🚨 Cannot delete this file')
        return {"FINISHED"}

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)


class SNA_OT_Add_Save_Police_Directory_4283D(bpy.types.Operator):
    bl_idname = "sna.add_save_police_directory_4283d"
    bl_label = "Add Save Police Directory"
    bl_description = "Add a Save Police Collection Directory"
    bl_options = {"REGISTER", "UNDO"}
    sna_selected_directory: bpy.props.StringProperty(name='selected directory', description='', default='', subtype='DIR_PATH', maxlen=0)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        item_BB634 = bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_directory_collection.add()
        item_BB634.directory = os.path.join(os.path.dirname(bpy.path.abspath(self.sna_selected_directory)),os.path.basename(bpy.path.abspath(self.sna_selected_directory)))
        item_BB634.project_name = os.path.basename(os.path.dirname(os.path.join(os.path.dirname(bpy.path.abspath(self.sna_selected_directory)),os.path.basename(bpy.path.abspath(self.sna_selected_directory)))))
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Remove_A_Folder_48Bb9(bpy.types.Operator):
    bl_idname = "sna.remove_a_folder_48bb9"
    bl_label = "Remove a Folder"
    bl_description = "Remove the currently selected folder"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if len(bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_directory_collection) > bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_directory_collection_index:
            bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_directory_collection.remove(bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_directory_collection_index)
        if (bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_directory_collection_index <= 0):
            bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_directory_collection_index = 0
        else:
            bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_directory_collection_index = int(bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_directory_collection_index - 1.0)
        if bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_directory_collection:
            pass
        else:
            bpy.context.scene.sna_save_police_collection.clear()
        if bpy.context and bpy.context.screen:
            for a in bpy.context.screen.areas:
                a.tag_redraw()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Move_Save_Police_Directory_Item_Up_27Fc6(bpy.types.Operator):
    bl_idname = "sna.move_save_police_directory_item_up_27fc6"
    bl_label = "Move Save Police Directory Item Up"
    bl_description = "Move the selected item up"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if (bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_directory_collection_index > 0):
            bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_directory_collection.move(bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_directory_collection_index, int(bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_directory_collection_index - 1.0))
            item_665A7 = bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_directory_collection[int(bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_directory_collection_index - 1.0)]
            bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_directory_collection_index = int(bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_directory_collection_index - 1.0)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Move_Save_Police_Directory_Item_Down_4373D(bpy.types.Operator):
    bl_idname = "sna.move_save_police_directory_item_down_4373d"
    bl_label = "Move Save Police Directory Item Down"
    bl_description = "Move the selected item down"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_directory_collection:
            if (bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_directory_collection_index < int(len(list(bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_directory_collection)) - 1.0)):
                bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_directory_collection.move(bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_directory_collection_index, int(bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_directory_collection_index + 1.0))
                item_01EC4 = bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_directory_collection[int(bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_directory_collection_index + 1.0)]
                bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_directory_collection_index = int(bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_directory_collection_index + 1.0)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Add_A_Folder_0414E(bpy.types.Operator, ImportHelper):
    bl_idname = "sna.add_a_folder_0414e"
    bl_label = "Add a Folder"
    bl_description = "Add a new project folder"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if bool(self.filepath):
            print(' ')
            if os.path.exists(bpy.path.abspath(self.filepath)):
                if os.path.isdir(bpy.path.abspath(self.filepath)):
                    print(' ', bpy.path.abspath(self.filepath))
                    bpy.ops.sna.add_save_police_directory_4283d(sna_selected_directory=os.path.join(bpy.path.abspath(self.filepath),''))
                else:
                    print(' ', os.path.dirname(bpy.path.abspath(self.filepath)))
                    bpy.ops.sna.add_save_police_directory_4283d(sna_selected_directory=os.path.join(os.path.dirname(bpy.path.abspath(self.filepath)),''))
            else:
                print(bpy.path.abspath(self.filepath))
                if os.path.exists(os.path.dirname(bpy.path.abspath(self.filepath))):
                    if os.path.isdir(os.path.dirname(bpy.path.abspath(self.filepath))):
                        bpy.ops.sna.add_save_police_directory_4283d(sna_selected_directory=os.path.join(os.path.dirname(bpy.path.abspath(self.filepath)),''))
        return {"FINISHED"}


class SNA_OT_Save_To_Selected_Project_39F67(bpy.types.Operator):
    bl_idname = "sna.save_to_selected_project_39f67"
    bl_label = "Save to Selected Project"
    bl_description = "Save this file to the Selected Project"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if bpy.context.preferences.addons['savepolice'].preferences.sna_pack_resources:
            bpy.ops.file.pack_all('INVOKE_DEFAULT', )
        if bool(bpy.data.filepath):
            print('🚨 Save Police: Attempting a file save')
            if ((len(os.path.basename(bpy.data.filepath)) > 0) and (len(bpy.context.preferences.addons['savepolice'].preferences.sna_default_save_prefix) > 0) and bpy.context.preferences.addons['savepolice'].preferences.sna_default_save_prefix in bpy.data.filepath and bpy.context.preferences.addons['savepolice'].preferences.sna_save_default_file and bpy.context.preferences.addons['savepolice'].preferences.sna_incremental_saving):
                bpy.ops.wm.save_mainfile(filepath=bpy.path.abspath(os.path.join(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_directory_collection[bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_directory_collection_index].directory),bpy.context.preferences.addons['savepolice'].preferences.sna_default_save_prefix + '_' + str(datetime.now().date().year) + '-' + str(datetime.now().date().month) + '-' + str(datetime.now().date().day) + '_' + str(datetime.now().time().hour) + '-' + str(datetime.now().time().minute) + '-' + str(datetime.now().time().second) + '.blend')))
            else:
                bpy.ops.wm.save_mainfile(filepath=os.path.join(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_directory_collection[bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_directory_collection_index].directory),os.path.basename(bpy.path.abspath(bpy.data.filepath))), incremental=bpy.context.preferences.addons['savepolice'].preferences.sna_incremental_saving)
                self.report({'INFO'}, message='🚨 Saved: ' + bpy.data.filepath)
        else:
            if bpy.context.preferences.addons['savepolice'].preferences.sna_save_default_file:
                print('🚨 Save Police: Attempting a default file save')
                bpy.ops.wm.save_mainfile(filepath=bpy.path.abspath(os.path.join(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_directory_collection[bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_directory_collection_index].directory),bpy.context.preferences.addons['savepolice'].preferences.sna_default_save_prefix + '_' + str(datetime.now().date().year) + '-' + str(datetime.now().date().month) + '-' + str(datetime.now().date().day) + '_' + str(datetime.now().time().hour) + '-' + str(datetime.now().time().minute) + '-' + str(datetime.now().time().second) + '.blend')))
                self.report({'INFO'}, message='🚨 Saved: ' + bpy.data.filepath)
            else:
                bpy.ops.wm.save_mainfile('INVOKE_DEFAULT', filepath=bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_directory_collection[bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_directory_collection_index].directory))
        bpy.ops.sna.save_police_reload_save_collection_14f82()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Change_Folder_81F37(bpy.types.Operator, ImportHelper):
    bl_idname = "sna.change_folder_81f37"
    bl_label = "Change Folder"
    bl_description = "Change the Folder"
    bl_options = {"REGISTER", "UNDO"}
    sna_selected_index: bpy.props.IntProperty(name='selected_index', description='selected index', default=0, subtype='NONE')

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if bool(self.filepath):
            print('')
            if os.path.exists(bpy.path.abspath(self.filepath)):
                if os.path.isdir(bpy.path.abspath(self.filepath)):
                    bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_directory_collection[self.sna_selected_index].directory = os.path.join(bpy.path.abspath(self.filepath),'')
                else:
                    bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_directory_collection[self.sna_selected_index].directory = os.path.join(os.path.dirname(bpy.path.abspath(self.filepath)),'')
            else:
                print(' ', '')
                if os.path.exists(os.path.dirname(bpy.path.abspath(self.filepath))):
                    if os.path.isdir(os.path.dirname(bpy.path.abspath(self.filepath))):
                        bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_directory_collection[self.sna_selected_index].directory = os.path.join(os.path.dirname(bpy.path.abspath(self.filepath)),'')
        return {"FINISHED"}


class SNA_OT_Op_Save_Police_Save_C2308(bpy.types.Operator):
    bl_idname = "sna.op_save_police_save_c2308"
    bl_label = "Op Save Police Save"
    bl_description = "Save (Shift + Click = Default Save, Ctrl + Click = Save Incremental, Alt + Click = Save Copy)"
    bl_options = {"REGISTER", "UNDO"}
    sna_shift_op: bpy.props.BoolProperty(name='shift_op', description='Change how to save', options={'HIDDEN'}, default=False)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if self.sna_shift_op:
            pass
        else:
            bpy.ops.wm.save_mainfile('INVOKE_DEFAULT', )
        return {"FINISHED"}

    def invoke(self, context, event):
        self.sna_shift_op = False
        if ((event.alt and (not event.shift) and (not event.ctrl)) or ((not event.alt) and event.shift and (not event.ctrl)) or ((not event.alt) and (not event.shift) and event.ctrl)):
            self.sna_shift_op = True
            if ((not event.alt) and event.shift and (not event.ctrl)):
                if bpy.context.preferences.addons['savepolice'].preferences.sna_save_default_file:
                    print('🚨 Save Police: Attempting a default file save')
                    if os.path.exists(bpy.context.preferences.addons['savepolice'].preferences.sna_default_folder):
                        bpy.ops.wm.save_mainfile(filepath=bpy.path.abspath(os.path.join(bpy.context.preferences.addons['savepolice'].preferences.sna_default_folder,bpy.context.preferences.addons['savepolice'].preferences.sna_default_save_prefix + '_' + str(datetime.now().date().year) + '-' + str(datetime.now().date().month) + '-' + str(datetime.now().date().day) + '_' + str(datetime.now().time().hour) + '-' + str(datetime.now().time().minute) + '-' + str(datetime.now().time().second) + '.blend')))
                        self.report({'INFO'}, message='🚨 Saved: ' + bpy.data.filepath)
                else:
                    bpy.ops.wm.save_mainfile('INVOKE_DEFAULT', )
            if ((not event.alt) and (not event.shift) and event.ctrl):
                bpy.ops.wm.save_mainfile('INVOKE_DEFAULT', incremental=True)
            if (event.alt and (not event.shift) and (not event.ctrl)):
                bpy.ops.wm.save_as_mainfile('INVOKE_DEFAULT', copy=True)
        return self.execute(context)


def sna_ui_fn_save_police_collection_14313(layout_function, ):
    col_E9423 = layout_function.column(heading='', align=True)
    col_E9423.alert = False
    col_E9423.enabled = True
    col_E9423.active = True
    col_E9423.use_property_split = False
    col_E9423.use_property_decorate = False
    col_E9423.scale_x = 1.0
    col_E9423.scale_y = 1.0
    col_E9423.alignment = 'Expand'.upper()
    col_E9423.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
    if bpy.context.preferences.addons['savepolice'].preferences.sna_view_single_or_multiple_projects:
        col_FA442 = col_E9423.column(heading='', align=True)
        col_FA442.alert = False
        col_FA442.enabled = True
        col_FA442.active = True
        col_FA442.use_property_split = False
        col_FA442.use_property_decorate = False
        col_FA442.scale_x = 1.0
        col_FA442.scale_y = 1.0
        col_FA442.alignment = 'Expand'.upper()
        col_FA442.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_96662 = col_FA442.row(heading='', align=True)
        row_96662.alert = False
        row_96662.enabled = True
        row_96662.active = True
        row_96662.use_property_split = False
        row_96662.use_property_decorate = False
        row_96662.scale_x = 1.0
        row_96662.scale_y = 1.0
        row_96662.alignment = 'Expand'.upper()
        row_96662.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_96662.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_view_single_or_multiple_projects', text='Multi Project Mode', icon_value=124, emboss=False, toggle=True, invert_checkbox=True)
        layout_function = col_FA442
        sna_ui_fn_save_police_directory_collection_A89A1(layout_function, )
    else:
        col_E9423.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_view_single_or_multiple_projects', text='Single Project Mode', icon_value=124, emboss=False, toggle=True, invert_checkbox=False)
    col_1819A = layout_function.column(heading='', align=True)
    col_1819A.alert = False
    col_1819A.enabled = True
    col_1819A.active = True
    col_1819A.use_property_split = False
    col_1819A.use_property_decorate = False
    col_1819A.scale_x = 1.0
    col_1819A.scale_y = 1.0
    col_1819A.alignment = 'Expand'.upper()
    col_1819A.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
    col_1819A.separator(factor=2.0)
    col_1819A.label(text=(('Files inside ' + (bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_directory_collection[bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_directory_collection_index].directory) if os.path.isdir(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_directory_collection[bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_directory_collection_index].directory)) else os.path.dirname(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_directory_collection[bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_directory_collection_index].directory))) if bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_directory_collection else 'No directory yet') if bpy.context.preferences.addons['savepolice'].preferences.sna_view_single_or_multiple_projects else ('Files inside ' + os.path.basename(os.path.dirname(bpy.path.abspath(bpy.data.filepath))) if sna_fn_check_for_folder_325DF(bpy.data.filepath) else ('Files inside ' + os.path.basename(os.path.dirname(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_default_folder))) if sna_fn_check_for_folder_325DF(bpy.context.preferences.addons['savepolice'].preferences.sna_default_folder) else 'No directory yet'))), icon_value=108)
    row_2CEE6 = col_1819A.row(heading='', align=False)
    row_2CEE6.alert = False
    row_2CEE6.enabled = True
    row_2CEE6.active = True
    row_2CEE6.use_property_split = False
    row_2CEE6.use_property_decorate = False
    row_2CEE6.scale_x = 1.0
    row_2CEE6.scale_y = 1.0
    row_2CEE6.alignment = 'Expand'.upper()
    row_2CEE6.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
    coll_id = display_collection_id('0B171', locals())
    row_2CEE6.template_list('SNA_UL_display_collection_list_0B171', coll_id, bpy.context.scene, 'sna_save_police_collection', bpy.context.scene, 'sna_save_police_collection_index', rows=bpy.context.preferences.addons['savepolice'].preferences.sna_collection_size)
    col_F2A96 = row_2CEE6.column(heading='', align=False)
    col_F2A96.alert = False
    col_F2A96.enabled = True
    col_F2A96.active = True
    col_F2A96.use_property_split = False
    col_F2A96.use_property_decorate = False
    col_F2A96.scale_x = 1.0
    col_F2A96.scale_y = 1.0
    col_F2A96.alignment = 'Expand'.upper()
    col_F2A96.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
    op = col_F2A96.operator('sna.save_police_reload_save_collection_14f82', text='', icon_value=692, emboss=False, depress=False)
    col_F2A96.separator(factor=2.0)
    if (property_exists("bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_directory_collection", globals(), locals()) and len(bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_directory_collection) > bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_directory_collection_index):
        if os.path.exists(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_directory_collection[bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_directory_collection_index].directory)):
            op = col_F2A96.operator('sna.save_to_selected_project_39f67', text='', icon_value=726, emboss=False, depress=False)
        else:
            col_BE5A3 = col_F2A96.column(heading='', align=False)
            col_BE5A3.alert = False
            col_BE5A3.enabled = False
            col_BE5A3.active = True
            col_BE5A3.use_property_split = False
            col_BE5A3.use_property_decorate = False
            col_BE5A3.scale_x = 1.0
            col_BE5A3.scale_y = 1.0
            col_BE5A3.alignment = 'Expand'.upper()
            col_BE5A3.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            op = col_BE5A3.operator('sna.save_to_selected_project_39f67', text='', icon_value=726, emboss=False, depress=False)
    else:
        col_6F0A2 = col_F2A96.column(heading='', align=False)
        col_6F0A2.alert = False
        col_6F0A2.enabled = False
        col_6F0A2.active = True
        col_6F0A2.use_property_split = False
        col_6F0A2.use_property_decorate = False
        col_6F0A2.scale_x = 1.0
        col_6F0A2.scale_y = 1.0
        col_6F0A2.alignment = 'Expand'.upper()
        col_6F0A2.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = col_6F0A2.operator('sna.save_to_selected_project_39f67', text='', icon_value=726, emboss=False, depress=False)
    col_F2A96.separator(factor=2.0)
    if ((bpy.context.scene.sna_save_police_collection_index >= 0) and (int(bpy.context.scene.sna_save_police_collection_index + 1.0) <= len(list(bpy.context.scene.sna_save_police_collection)))):
        if os.path.exists(bpy.path.abspath(bpy.context.scene.sna_save_police_collection[bpy.context.scene.sna_save_police_collection_index].save_police_file)):
            if (bpy.path.abspath(bpy.context.scene.sna_save_police_collection[bpy.context.scene.sna_save_police_collection_index].save_police_file) != bpy.path.abspath(bpy.data.filepath)):
                col_702FD = col_F2A96.column(heading='', align=False)
                col_702FD.alert = False
                col_702FD.enabled = True
                col_702FD.active = True
                col_702FD.use_property_split = False
                col_702FD.use_property_decorate = False
                col_702FD.scale_x = 1.0
                col_702FD.scale_y = 1.0
                col_702FD.alignment = 'Expand'.upper()
                col_702FD.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                op = col_702FD.operator('sna.delete_file_eea1a', text='', icon_value=21, emboss=False, depress=False)
                op.sna_file_path = bpy.path.abspath(bpy.context.scene.sna_save_police_collection[bpy.context.scene.sna_save_police_collection_index].save_police_file)
            else:
                col_20050 = col_F2A96.column(heading='', align=False)
                col_20050.alert = False
                col_20050.enabled = False
                col_20050.active = True
                col_20050.use_property_split = False
                col_20050.use_property_decorate = False
                col_20050.scale_x = 1.0
                col_20050.scale_y = 1.0
                col_20050.alignment = 'Expand'.upper()
                col_20050.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                op = col_20050.operator('sna.delete_file_eea1a', text='', icon_value=21, emboss=False, depress=False)
                op.sna_file_path = ''
        else:
            col_548B1 = col_F2A96.column(heading='', align=False)
            col_548B1.alert = False
            col_548B1.enabled = False
            col_548B1.active = True
            col_548B1.use_property_split = False
            col_548B1.use_property_decorate = False
            col_548B1.scale_x = 1.0
            col_548B1.scale_y = 1.0
            col_548B1.alignment = 'Expand'.upper()
            col_548B1.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            op = col_548B1.operator('sna.delete_file_eea1a', text='', icon_value=21, emboss=False, depress=False)
    else:
        col_8091D = col_F2A96.column(heading='', align=False)
        col_8091D.alert = False
        col_8091D.enabled = False
        col_8091D.active = True
        col_8091D.use_property_split = False
        col_8091D.use_property_decorate = False
        col_8091D.scale_x = 1.0
        col_8091D.scale_y = 1.0
        col_8091D.alignment = 'Expand'.upper()
        col_8091D.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = col_8091D.operator('sna.delete_file_eea1a', text='', icon_value=21, emboss=False, depress=False)
        op.sna_file_path = ''
    if (g_save_police_collection['sna_prog'] < 1.0):
        col_F2A96.progress(text='', factor=g_save_police_collection['sna_prog'], type='RING' if True else 'BAR')


class SNA_MT_2F16D(bpy.types.Menu):
    bl_idname = "SNA_MT_2F16D"
    bl_label = ""

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw(self, context):
        layout = self.layout.column_flow(columns=1)
        layout.operator_context = "INVOKE_DEFAULT"


def sna_ui_fn_save_police_directory_collection_A89A1(layout_function, ):
    row_E78D2 = layout_function.row(heading='', align=True)
    row_E78D2.alert = False
    row_E78D2.enabled = True
    row_E78D2.active = True
    row_E78D2.use_property_split = False
    row_E78D2.use_property_decorate = False
    row_E78D2.scale_x = 1.0
    row_E78D2.scale_y = 1.0
    row_E78D2.alignment = 'Expand'.upper()
    row_E78D2.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
    coll_id = display_collection_id('E485D', locals())
    row_E78D2.template_list('SNA_UL_display_collection_list_E485D', coll_id, bpy.context.preferences.addons['savepolice'].preferences, 'sna_save_police_directory_collection', bpy.context.preferences.addons['savepolice'].preferences, 'sna_save_police_directory_collection_index', rows=0)
    col_C95CC = row_E78D2.column(heading='', align=True)
    col_C95CC.alert = False
    col_C95CC.enabled = True
    col_C95CC.active = True
    col_C95CC.use_property_split = False
    col_C95CC.use_property_decorate = False
    col_C95CC.scale_x = 1.0
    col_C95CC.scale_y = 1.0
    col_C95CC.alignment = 'Expand'.upper()
    col_C95CC.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
    op = col_C95CC.operator('sna.add_a_folder_0414e', text='', icon_value=31, emboss=False, depress=False)
    op = col_C95CC.operator('sna.remove_a_folder_48bb9', text='', icon_value=32, emboss=False, depress=False)
    col_C95CC.separator(factor=2.0)
    op = col_C95CC.operator('sna.move_save_police_directory_item_up_27fc6', text='', icon_value=7, emboss=False, depress=False)
    op = col_C95CC.operator('sna.move_save_police_directory_item_down_4373d', text='', icon_value=5, emboss=False, depress=False)


def sna_add_to_wm_mt_splash_F2C56(self, context):
    if not ((not bpy.context.preferences.addons['savepolice'].preferences.sna_use_splash_screen)):
        layout = self.layout
        if (not bpy.context.scene.sna_load_save_police_collection):
            layout.prop(bpy.context.scene, 'sna_load_save_police_collection', text='Load Save Police Collection', icon_value=((load_preview_icon(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_red)) if bpy.context.scene.sna_save_police_reminder else (((load_preview_icon(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_yellow)) if bpy.context.preferences.addons['savepolice'].preferences.sna_alert else load_preview_icon(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_blue))) if bpy.context.preferences.addons['savepolice'].preferences.sna_call_the_save_police else load_preview_icon(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_grey))) if bpy.data.is_dirty else load_preview_icon(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_green)))) if bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_icon else (load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_256x256_Render0013.png')) if bpy.context.scene.sna_save_police_reminder else (((load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_yellow_256x256.png')) if bpy.context.preferences.addons['savepolice'].preferences.sna_alert else load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_blue_256x256.png'))) if bpy.context.preferences.addons['savepolice'].preferences.sna_call_the_save_police else load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_grey_256x256.png'))) if bpy.data.is_dirty else load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_green_256x256.png'))))), emboss=False, toggle=True)
        else:
            layout.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_call_the_save_police', text='Save Police Collection', icon_value=((load_preview_icon(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_red)) if bpy.context.scene.sna_save_police_reminder else (((load_preview_icon(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_yellow)) if bpy.context.preferences.addons['savepolice'].preferences.sna_alert else load_preview_icon(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_blue))) if bpy.context.preferences.addons['savepolice'].preferences.sna_call_the_save_police else load_preview_icon(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_grey))) if bpy.data.is_dirty else load_preview_icon(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_green)))) if bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_icon else (load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_256x256_Render0013.png')) if bpy.context.scene.sna_save_police_reminder else (((load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_yellow_256x256.png')) if bpy.context.preferences.addons['savepolice'].preferences.sna_alert else load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_blue_256x256.png'))) if bpy.context.preferences.addons['savepolice'].preferences.sna_call_the_save_police else load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_grey_256x256.png'))) if bpy.data.is_dirty else load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_green_256x256.png'))))), emboss=False, toggle=True)
            layout_function = layout
            sna_ui_fn_save_police_collection_14313(layout_function, )


def sna_add_to_filebrowser_mt_editor_menus_457D3(self, context):
    if not ((not bpy.context.preferences.addons['savepolice'].preferences.sna_alert_file_browser)):
        layout = self.layout
        layout_function = layout
        sna_ui_fn_animate_icons_E6878(layout_function, )


def sna_add_to_assetbrowser_mt_editor_menus_E5265(self, context):
    if not ((not bpy.context.preferences.addons['savepolice'].preferences.sna_alert_asset_browser)):
        layout = self.layout
        layout_function = layout
        sna_ui_fn_animate_icons_E6878(layout_function, )


def sna_add_to_spreadsheet_ht_header_318BA(self, context):
    if not ((not bpy.context.preferences.addons['savepolice'].preferences.sna_alert_spreadhseet)):
        layout = self.layout
        layout_function = layout
        sna_ui_fn_animate_icons_E6878(layout_function, )


def sna_fn_start_stop_save_police_timer_34567(Start_Timer):
    if Start_Timer:
        graph_scripts['sna_minutes'] = 0.0
        graph_scripts['sna_animation_minutes'] = 0
    graph_scripts['sna_timer_freq'] = float(bpy.context.preferences.addons['savepolice'].preferences.sna_interval * (60.0 if (bpy.context.preferences.addons['savepolice'].preferences.sna_unit_of_time == 'Minutes') else (1.0 if (bpy.context.preferences.addons['savepolice'].preferences.sna_unit_of_time == 'Seconds') else (3600.0 if (bpy.context.preferences.addons['savepolice'].preferences.sna_unit_of_time == 'Hours') else 60.0))))
    graph_scripts['sna_timer_interval'] = bpy.context.preferences.addons['savepolice'].preferences.sna_interval
    graph_scripts['sna_timer_interval'] = 1.0
    start = Start_Timer
    timer_interval = bpy.context.preferences.addons['savepolice'].preferences.sna_interval
    timer_sec = 1
    timer_freq = float(bpy.context.preferences.addons['savepolice'].preferences.sna_interval * (60.0 if (bpy.context.preferences.addons['savepolice'].preferences.sna_unit_of_time == 'Minutes') else (1.0 if (bpy.context.preferences.addons['savepolice'].preferences.sna_unit_of_time == 'Seconds') else (3600.0 if (bpy.context.preferences.addons['savepolice'].preferences.sna_unit_of_time == 'Hours') else 60.0))))
    if not start:
        if bpy.app.timers.is_registered(fn_save_police_timer_2):
            bpy.app.timers.unregister(fn_save_police_timer_2)
    else:
        if not bpy.app.timers.is_registered(fn_save_police_timer_2):
            bpy.app.timers.register(fn_save_police_timer_2)


def before_exit_handler_8A0D1():
    bpy.ops.sna.save_police_end_alert_image_preview_7a41b('INVOKE_DEFAULT', )
    bpy.ops.sna.save_police_end_countdown_preview_8f673('INVOKE_DEFAULT', )


@persistent
def load_post_handler_0B793(dummy):
    bpy.context.scene.sna_save_police_interval = bpy.context.preferences.addons['savepolice'].preferences.sna_interval
    graph_scripts['sna_timer_freq'] = float(bpy.context.preferences.addons['savepolice'].preferences.sna_interval * 60.0)
    graph_scripts['sna_timer_interval'] = bpy.context.preferences.addons['savepolice'].preferences.sna_interval
    graph_scripts['sna_timer_interval'] = 1.0
    if (bpy.context.preferences.addons['savepolice'].preferences.sna_save_on_load and bpy.context.preferences.addons['savepolice'].preferences.sna_call_the_save_police and bpy.context.preferences.addons['savepolice'].preferences.sna_save_default_file):
        sna_fn_start_stop_save_police_timer_34567(False)
        if bool(bpy.data.filepath):
            pass
        else:
            bpy.ops.sna.op_save_police_saving_148e8('INVOKE_DEFAULT', )
            print('🚨 Save Police: Save Startup is Active')
            bpy.ops.wm.splash('INVOKE_DEFAULT', )
    if bpy.context.preferences.addons['savepolice'].preferences.sna_call_the_save_police:

        def delayed_78357():
            bpy.context.preferences.addons['savepolice'].preferences.sna_call_the_save_police = True
        bpy.app.timers.register(delayed_78357, first_interval=1.0)
        bpy.context.preferences.addons['savepolice'].preferences.sna_call_the_save_police = False


@persistent
def save_post_handler_70958(dummy):
    bpy.context.scene.sna_save_police_reminder = False
    if bpy.context.preferences.addons['savepolice'].preferences.sna_change_theme:
        pass
    sna_fn_start_stop_save_police_timer_34567(False)
    if bpy.context.preferences.addons['savepolice'].preferences.sna_call_the_save_police:
        sna_fn_start_stop_save_police_timer_34567(True)
    if (bpy.context.preferences.addons['savepolice'].preferences.sna_interval != bpy.context.scene.sna_save_police_interval):
        bpy.context.scene.sna_save_police_interval = bpy.context.preferences.addons['savepolice'].preferences.sna_interval
    if bpy.context.scene.sna_save_police_animation_active:
        bpy.ops.sna.save_police_end_alert_image_preview_7a41b('INVOKE_DEFAULT', )
    sna_fn_removed_unused_images_A2907()
    if ((not bpy.context.scene.sna_save_police_reminder) and True and bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_on_ui and bpy.context.preferences.addons['savepolice'].preferences.sna_call_the_save_police):
        bpy.ops.sna.save_police_end_countdown_preview_8f673('INVOKE_DEFAULT', )
        bpy.ops.sna.save_police_draw_countdown_f091c('INVOKE_DEFAULT', )
    if bpy.context.preferences.addons['savepolice'].preferences.sna_view_single_or_multiple_projects:
        pass
    else:
        bpy.ops.sna.save_police_add_to_save_collection_fc42d('INVOKE_DEFAULT', )
    bpy.ops.sna.save_police_reload_save_collection_14f82('INVOKE_DEFAULT', )


class SNA_OT_Op_Save_Police_Saving_148E8(bpy.types.Operator):
    bl_idname = "sna.op_save_police_saving_148e8"
    bl_label = "Op Save Police Saving"
    bl_description = "Time for a save"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if bpy.context.preferences.addons['savepolice'].preferences.sna_pack_resources:
            bpy.ops.file.pack_all('INVOKE_DEFAULT', )
        if bool(bpy.data.filepath):
            print('🚨 Save Police: Attempting a file save')
            if ((len(os.path.basename(bpy.data.filepath)) > 0) and (len(bpy.context.preferences.addons['savepolice'].preferences.sna_default_save_prefix) > 0) and bpy.context.preferences.addons['savepolice'].preferences.sna_default_save_prefix in bpy.data.filepath and bpy.context.preferences.addons['savepolice'].preferences.sna_save_default_file and bpy.context.preferences.addons['savepolice'].preferences.sna_incremental_saving):
                bpy.ops.wm.save_mainfile(filepath=bpy.path.abspath(os.path.join(bpy.context.preferences.addons['savepolice'].preferences.sna_default_folder,bpy.context.preferences.addons['savepolice'].preferences.sna_default_save_prefix + '_' + str(datetime.now().date().year) + '-' + str(datetime.now().date().month) + '-' + str(datetime.now().date().day) + '_' + str(datetime.now().time().hour) + '-' + str(datetime.now().time().minute) + '-' + str(datetime.now().time().second) + '.blend')))
            else:
                bpy.ops.wm.save_mainfile(filepath=bpy.data.filepath, incremental=bpy.context.preferences.addons['savepolice'].preferences.sna_incremental_saving)
                self.report({'INFO'}, message='🚨 Saved: ' + bpy.data.filepath)
        else:
            if bpy.context.preferences.addons['savepolice'].preferences.sna_save_default_file:
                print('🚨 Save Police: Attempting a default file save')
                if os.path.exists(bpy.context.preferences.addons['savepolice'].preferences.sna_default_folder):
                    bpy.ops.wm.save_mainfile(filepath=bpy.path.abspath(os.path.join(bpy.context.preferences.addons['savepolice'].preferences.sna_default_folder,bpy.context.preferences.addons['savepolice'].preferences.sna_default_save_prefix + '_' + str(datetime.now().date().year) + '-' + str(datetime.now().date().month) + '-' + str(datetime.now().date().day) + '_' + str(datetime.now().time().hour) + '-' + str(datetime.now().time().minute) + '-' + str(datetime.now().time().second) + '.blend')))
                    self.report({'INFO'}, message='🚨 Saved: ' + bpy.data.filepath)
            else:
                bpy.ops.wm.save_mainfile('INVOKE_DEFAULT', )
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_detail_level_enum_items(self, context):
    enum_items = [['Simple', 'Simple', 'Select this to show only the basics.', (load_preview_icon(bpy.path.abspath(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_256x256_Render0013.png'))) if bpy.context.scene.sna_save_police_reminder else (((load_preview_icon(bpy.path.abspath(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_yellow_256x256.png'))) if bpy.context.preferences.addons['savepolice'].preferences.sna_alert else load_preview_icon(bpy.path.abspath(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_blue_256x256.png')))) if bpy.context.preferences.addons['savepolice'].preferences.sna_call_the_save_police else load_preview_icon(bpy.path.abspath(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_grey_256x256.png')))) if bpy.data.is_dirty else load_preview_icon(bpy.path.abspath(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_green_256x256.png')))))], ['Advanced', 'Advanced', 'For advanced users who want to control every aspect of their save police experience', ((load_preview_icon(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_red)) if bpy.context.scene.sna_save_police_reminder else (((load_preview_icon(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_yellow)) if bpy.context.preferences.addons['savepolice'].preferences.sna_alert else load_preview_icon(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_blue))) if bpy.context.preferences.addons['savepolice'].preferences.sna_call_the_save_police else load_preview_icon(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_grey))) if bpy.data.is_dirty else load_preview_icon(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_green)))) if bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_icon else (load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_256x256_Render0013.png')) if bpy.context.scene.sna_save_police_reminder else (((load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_yellow_256x256.png')) if bpy.context.preferences.addons['savepolice'].preferences.sna_alert else load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_blue_256x256.png'))) if bpy.context.preferences.addons['savepolice'].preferences.sna_call_the_save_police else load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_grey_256x256.png'))) if bpy.data.is_dirty else load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_green_256x256.png')))))]]
    return [make_enum_item(item[0], item[1], item[2], item[3], i) for i, item in enumerate(enum_items)]


def fn_save_police_timer_2():
    #print("Running")
    temp_duration = (graph_scripts['sna_timer_interval']*graph_scripts['sna_timer_freq'])
    if bpy.data.is_dirty:
        if graph_scripts['sna_minutes'] >= temp_duration:
            graph_scripts['sna_minutes'] = 1
            bpy.context.scene.sna_save_police_reminder = True
            if bpy.context and bpy.context.screen:
                for a in bpy.context.screen.areas:
                    a.tag_redraw()
        else:
            graph_scripts['sna_minutes'] += 1
        #print(f"Save Police timer is running for {graph_scripts['sna_minutes']} seconds")
    else:
        if bpy.context.scene.sna_save_police_reminder:
            bpy.context.scene.sna_save_police_reminder = False
    if temp_duration < graph_scripts['sna_minutes']:
        temp_time_remaining_sec = 0.0
    else:
        temp_time_remaining_sec = temp_duration - graph_scripts['sna_minutes']
    temp_time_remaining_min = temp_time_remaining_sec/60.0
    if temp_time_remaining_min < 1.0:
        graph_scripts['sna_time_remaining'] = temp_time_remaining_sec
        graph_scripts['sna_time_message'] = str(round(graph_scripts['sna_time_remaining'],1)) + ' sec'
    else:
        graph_scripts['sna_time_remaining'] = temp_time_remaining_min
        graph_scripts['sna_time_message'] = str(round(graph_scripts['sna_time_remaining'],1)) + ' min'
    return graph_scripts['sna_timer_sec']


#import datetime
workspace_handle = object()
#Triggers when window workspace has changed
subscribe_to_window = bpy.types.Window, "workspace"


def update_countdown(context):
    bpy.ops.sna.save_police_end_countdown_preview_8f673('INVOKE_DEFAULT', )
    bpy.ops.sna.save_police_draw_countdown_f091c('INVOKE_DEFAULT', )


bpy.msgbus.subscribe_rna(
    key=subscribe_to_window,
    owner=workspace_handle,
    args=(bpy.context,),
    notify=update_countdown,


)
bpy.msgbus.publish_rna(key=subscribe_to_window)


def sna_add_to_view3d_mt_editor_menus_6B622(self, context):
    if not ((not bpy.context.preferences.addons['savepolice'].preferences.sna_alert_3d_viewport)):
        layout = self.layout
        layout_function = layout
        sna_ui_fn_animate_icons_E6878(layout_function, )


def sna_ui_fn_animate_icons_E6878(layout_function, ):
    row_D5430 = layout_function.row(heading='', align=True)
    row_D5430.alert = False
    row_D5430.enabled = True
    row_D5430.active = True
    row_D5430.use_property_split = False
    row_D5430.use_property_decorate = False
    row_D5430.scale_x = 1.0
    row_D5430.scale_y = 1.0
    row_D5430.alignment = 'Expand'.upper()
    row_D5430.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
    row_D5430.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_call_the_save_police', text='', icon_value=((load_preview_icon(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_red)) if bpy.context.scene.sna_save_police_reminder else (((load_preview_icon(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_yellow)) if bpy.context.preferences.addons['savepolice'].preferences.sna_alert else load_preview_icon(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_blue))) if bpy.context.preferences.addons['savepolice'].preferences.sna_call_the_save_police else load_preview_icon(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_grey))) if bpy.data.is_dirty else load_preview_icon(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_green)))) if bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_icon else (load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_256x256_Render0013.png')) if bpy.context.scene.sna_save_police_reminder else (((load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_yellow_256x256.png')) if bpy.context.preferences.addons['savepolice'].preferences.sna_alert else load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_blue_256x256.png'))) if bpy.context.preferences.addons['savepolice'].preferences.sna_call_the_save_police else load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_grey_256x256.png'))) if bpy.data.is_dirty else load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_green_256x256.png'))))), emboss=False, toggle=True)
    if ((not bpy.context.scene.sna_save_police_reminder) and bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_on_ui and bpy.context.preferences.addons['savepolice'].preferences.sna_call_the_save_police and bpy.data.is_dirty):
        op = row_D5430.operator('sna.op_save_police_save_c2308', text=((((graph_scripts['sna_time_message'] if bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_on_ui else ' ') if bpy.context.preferences.addons['savepolice'].preferences.sna_call_the_save_police else ' ') if (not bpy.context.scene.sna_save_police_reminder) else ' ') if bpy.data.is_dirty else ' '), icon_value=(((load_preview_icon(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_countdown_icon)) if os.path.exists(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_countdown_icon)) else 678) if bpy.context.preferences.addons['savepolice'].preferences.sna_use_custom_countdown_icon else 678) if bpy.data.is_dirty else 0), emboss=False, depress=False)
    layout_function = row_D5430
    sna_ui_fn_save_alert_icons_5281A(layout_function, )


def sna_add_to_console_mt_editor_menus_9AC1C(self, context):
    if not ((not bpy.context.preferences.addons['savepolice'].preferences.sna_alert_console)):
        layout = self.layout
        layout_function = layout
        sna_ui_fn_animate_icons_E6878(layout_function, )


def sna_add_to_info_mt_editor_menus_787B8(self, context):
    if not ((not bpy.context.preferences.addons['savepolice'].preferences.sna_alert_info_log)):
        layout = self.layout
        layout_function = layout
        sna_ui_fn_animate_icons_E6878(layout_function, )


def sna_add_to_text_mt_editor_menus_C945C(self, context):
    if not ((not bpy.context.preferences.addons['savepolice'].preferences.sna_alert_text_editor)):
        layout = self.layout
        layout_function = layout
        sna_ui_fn_animate_icons_E6878(layout_function, )


def sna_ui_fn_custom_siren_059E9(layout_function, ):
    col_36B2F = layout_function.column(heading='', align=True)
    col_36B2F.alert = False
    col_36B2F.enabled = True
    col_36B2F.active = True
    col_36B2F.use_property_split = True
    col_36B2F.use_property_decorate = False
    col_36B2F.scale_x = 1.0
    col_36B2F.scale_y = 1.0
    col_36B2F.alignment = 'Expand'.upper()
    col_36B2F.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
    col_36B2F.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_custom_siren_icon', text='Use Custom Siren', icon_value=((load_preview_icon(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_red)) if bpy.context.scene.sna_save_police_reminder else (((load_preview_icon(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_yellow)) if bpy.context.preferences.addons['savepolice'].preferences.sna_alert else load_preview_icon(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_blue))) if bpy.context.preferences.addons['savepolice'].preferences.sna_call_the_save_police else load_preview_icon(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_grey))) if bpy.data.is_dirty else load_preview_icon(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_green)))) if bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_icon else (load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_256x256_Render0013.png')) if bpy.context.scene.sna_save_police_reminder else (((load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_yellow_256x256.png')) if bpy.context.preferences.addons['savepolice'].preferences.sna_alert else load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_blue_256x256.png'))) if bpy.context.preferences.addons['savepolice'].preferences.sna_call_the_save_police else load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_grey_256x256.png'))) if bpy.data.is_dirty else load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_green_256x256.png'))))), emboss=True)
    if bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_icon:
        col_B16FB = col_36B2F.column(heading='', align=True)
        col_B16FB.alert = False
        col_B16FB.enabled = True
        col_B16FB.active = True
        col_B16FB.use_property_split = False
        col_B16FB.use_property_decorate = False
        col_B16FB.scale_x = 1.0
        col_B16FB.scale_y = 1.0
        col_B16FB.alignment = 'Expand'.upper()
        col_B16FB.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_2DDE3 = col_B16FB.row(heading='', align=True)
        row_2DDE3.alert = False
        row_2DDE3.enabled = True
        row_2DDE3.active = True
        row_2DDE3.use_property_split = False
        row_2DDE3.use_property_decorate = False
        row_2DDE3.scale_x = 1.0
        row_2DDE3.scale_y = 1.0
        row_2DDE3.alignment = 'Expand'.upper()
        row_2DDE3.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_2DDE3.label(text='Saved', icon_value=(load_preview_icon(bpy.path.abspath(str(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_green))) if os.path.exists(bpy.path.abspath(str(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_green))) else load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_green_256x256.png'))))
        row_2DDE3.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_custom_siren_green', text='', icon_value=0, emboss=(not os.path.exists(bpy.path.abspath(str(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_green)))))
        row_7F058 = col_B16FB.row(heading='', align=True)
        row_7F058.alert = False
        row_7F058.enabled = True
        row_7F058.active = True
        row_7F058.use_property_split = False
        row_7F058.use_property_decorate = False
        row_7F058.scale_x = 1.0
        row_7F058.scale_y = 1.0
        row_7F058.alignment = 'Expand'.upper()
        row_7F058.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_7F058.label(text='Active', icon_value=(load_preview_icon(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_blue)) if os.path.exists(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_blue)) else load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_blue_256x256.png'))))
        row_7F058.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_custom_siren_blue', text='', icon_value=0, emboss=(not os.path.exists(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_blue))))
        row_710B7 = col_B16FB.row(heading='', align=True)
        row_710B7.alert = False
        row_710B7.enabled = True
        row_710B7.active = True
        row_710B7.use_property_split = False
        row_710B7.use_property_decorate = False
        row_710B7.scale_x = 1.0
        row_710B7.scale_y = 1.0
        row_710B7.alignment = 'Expand'.upper()
        row_710B7.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_710B7.label(text='Active (Alerts Only)', icon_value=(load_preview_icon(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_yellow)) if os.path.exists(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_yellow)) else load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_yellow_256x256.png'))))
        row_710B7.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_custom_siren_yellow', text='', icon_value=0, emboss=(not os.path.exists(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_yellow))))
        row_797FE = col_B16FB.row(heading='', align=True)
        row_797FE.alert = False
        row_797FE.enabled = True
        row_797FE.active = True
        row_797FE.use_property_split = False
        row_797FE.use_property_decorate = False
        row_797FE.scale_x = 1.0
        row_797FE.scale_y = 1.0
        row_797FE.alignment = 'Expand'.upper()
        row_797FE.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_797FE.label(text='Inactive', icon_value=(load_preview_icon(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_grey)) if os.path.exists(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_grey)) else load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_grey_256x256.png'))))
        row_797FE.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_custom_siren_grey', text='', icon_value=0, emboss=(not os.path.exists(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_grey))))
        row_F2086 = col_B16FB.row(heading='', align=True)
        row_F2086.alert = False
        row_F2086.enabled = True
        row_F2086.active = True
        row_F2086.use_property_split = False
        row_F2086.use_property_decorate = False
        row_F2086.scale_x = 1.0
        row_F2086.scale_y = 1.0
        row_F2086.alignment = 'Expand'.upper()
        row_F2086.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_F2086.label(text='Alert', icon_value=(load_preview_icon(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_red)) if os.path.exists(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_red)) else load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_256x256_Render0013.png'))))
        row_F2086.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_custom_siren_red', text='', icon_value=0, emboss=(not os.path.exists(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_red))))


def sna_ui_fn_save_alert_icons_5281A(layout_function, ):
    if (bpy.context.scene.sna_save_police_reminder and bpy.context.preferences.addons['savepolice'].preferences.sna_alert and bpy.data.is_dirty):
        if (not bpy.context.preferences.addons['savepolice'].preferences.sna_custom_icons):
            op = layout_function.operator('sna.op_save_police_save_c2308', text='', icon_value=load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'S.png')), emboss=False, depress=False)
            op = layout_function.operator('sna.op_save_police_save_c2308', text='', icon_value=load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'A.png')), emboss=False, depress=False)
            op = layout_function.operator('sna.op_save_police_save_c2308', text='', icon_value=load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'V.png')), emboss=False, depress=False)
            op = layout_function.operator('sna.op_save_police_save_c2308', text='', icon_value=load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'E.png')), emboss=False, depress=False)
        else:
            layout_function = layout_function
            sna_ui_fn_save_police_custom_icons_F4AE7(layout_function, )


def sna_add_to_statusbar_ht_header_2ABD9(self, context):
    if not ((not bpy.context.preferences.addons['savepolice'].preferences.sna_alert_footer)):
        layout = self.layout
        row_9EFD5 = layout.row(heading='', align=True)
        row_9EFD5.alert = False
        row_9EFD5.enabled = True
        row_9EFD5.active = True
        row_9EFD5.use_property_split = False
        row_9EFD5.use_property_decorate = False
        row_9EFD5.scale_x = 1.0
        row_9EFD5.scale_y = 1.0
        row_9EFD5.alignment = 'Expand'.upper()
        row_9EFD5.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_9EFD5.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_call_the_save_police', text='', icon_value=((load_preview_icon(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_red)) if bpy.context.scene.sna_save_police_reminder else (((load_preview_icon(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_yellow)) if bpy.context.preferences.addons['savepolice'].preferences.sna_alert else load_preview_icon(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_blue))) if bpy.context.preferences.addons['savepolice'].preferences.sna_call_the_save_police else load_preview_icon(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_grey))) if bpy.data.is_dirty else load_preview_icon(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_green)))) if bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_icon else (load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_256x256_Render0013.png')) if bpy.context.scene.sna_save_police_reminder else (((load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_yellow_256x256.png')) if bpy.context.preferences.addons['savepolice'].preferences.sna_alert else load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_blue_256x256.png'))) if bpy.context.preferences.addons['savepolice'].preferences.sna_call_the_save_police else load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_grey_256x256.png'))) if bpy.data.is_dirty else load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_green_256x256.png'))))), emboss=False, toggle=True)
        layout_function = row_9EFD5
        sna_ui_fn_save_alert_icons_5281A(layout_function, )
        if ((not bpy.context.scene.sna_save_police_reminder) and bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_on_ui and bpy.context.preferences.addons['savepolice'].preferences.sna_call_the_save_police and bpy.data.is_dirty):
            op = row_9EFD5.operator('sna.op_save_police_save_c2308', text='', icon_value=(((load_preview_icon(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_countdown_icon)) if os.path.exists(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_countdown_icon)) else 678) if bpy.context.preferences.addons['savepolice'].preferences.sna_use_custom_countdown_icon else 678) if bpy.data.is_dirty else 0), emboss=False, depress=False)


def sna_add_to_topbar_mt_editor_menus_020E6(self, context):
    if not ((not bpy.context.preferences.addons['savepolice'].preferences.sna_alert_header)):
        layout = self.layout
        row_A10DE = layout.row(heading='', align=True)
        row_A10DE.alert = False
        row_A10DE.enabled = True
        row_A10DE.active = True
        row_A10DE.use_property_split = False
        row_A10DE.use_property_decorate = False
        row_A10DE.scale_x = 1.0
        row_A10DE.scale_y = 1.0
        row_A10DE.alignment = 'Expand'.upper()
        row_A10DE.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_A10DE.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_call_the_save_police', text='', icon_value=((load_preview_icon(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_red)) if bpy.context.scene.sna_save_police_reminder else (((load_preview_icon(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_yellow)) if bpy.context.preferences.addons['savepolice'].preferences.sna_alert else load_preview_icon(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_blue))) if bpy.context.preferences.addons['savepolice'].preferences.sna_call_the_save_police else load_preview_icon(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_grey))) if bpy.data.is_dirty else load_preview_icon(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_green)))) if bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_icon else (load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_256x256_Render0013.png')) if bpy.context.scene.sna_save_police_reminder else (((load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_yellow_256x256.png')) if bpy.context.preferences.addons['savepolice'].preferences.sna_alert else load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_blue_256x256.png'))) if bpy.context.preferences.addons['savepolice'].preferences.sna_call_the_save_police else load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_grey_256x256.png'))) if bpy.data.is_dirty else load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_green_256x256.png'))))), emboss=False, toggle=True)
        layout_function = row_A10DE
        sna_ui_fn_save_alert_icons_5281A(layout_function, )
        if ((not bpy.context.scene.sna_save_police_reminder) and bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_on_ui and bpy.context.preferences.addons['savepolice'].preferences.sna_call_the_save_police and bpy.data.is_dirty):
            op = row_A10DE.operator('sna.op_save_police_save_c2308', text='', icon_value=(((load_preview_icon(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_countdown_icon)) if os.path.exists(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_countdown_icon)) else 678) if bpy.context.preferences.addons['savepolice'].preferences.sna_use_custom_countdown_icon else 678) if bpy.data.is_dirty else 0), emboss=False, depress=False)


def sna_add_to_node_mt_editor_menus_0C1AE(self, context):
    if not ((not bpy.context.preferences.addons['savepolice'].preferences.sna_alert_node_editors)):
        layout = self.layout
        layout_function = layout
        sna_ui_fn_animate_icons_E6878(layout_function, )


def sna_add_to_outliner_ht_header_923DF(self, context):
    if not ((not bpy.context.preferences.addons['savepolice'].preferences.sna_alert_outliner)):
        layout = self.layout
        layout_function = layout
        sna_ui_fn_animate_icons_E6878(layout_function, )


def sna_add_to_userpref_mt_editor_menus_02C87(self, context):
    if not ((not bpy.context.preferences.addons['savepolice'].preferences.sna_alert_preferences)):
        layout = self.layout
        layout_function = layout
        sna_ui_fn_animate_icons_E6878(layout_function, )


def sna_add_to_properties_ht_header_444AD(self, context):
    if not ((not bpy.context.preferences.addons['savepolice'].preferences.sna_alert_properties)):
        layout = self.layout
        layout_function = layout
        sna_ui_fn_animate_icons_E6878(layout_function, )


def sna_ui_fn_save_police_custom_icons_F4AE7(layout_function, ):
    if bpy.context.preferences.addons['savepolice'].preferences.sna_icons_collection:
        row_0D108 = layout_function.row(heading='', align=True)
        row_0D108.alert = False
        row_0D108.enabled = True
        row_0D108.active = True
        row_0D108.use_property_split = False
        row_0D108.use_property_decorate = False
        row_0D108.scale_x = 1.0
        row_0D108.scale_y = 1.0
        row_0D108.alignment = 'Expand'.upper()
        row_0D108.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        for i_A4C71 in range(len(bpy.context.preferences.addons['savepolice'].preferences.sna_icons_collection)):
            if os.path.exists(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_icons_collection[i_A4C71].icon_path)):
                op = row_0D108.operator('sna.op_save_police_save_c2308', text='', icon_value=load_preview_icon(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_icons_collection[i_A4C71].icon_path)), emboss=False, depress=False)


def sna_ui_fn_save_police_B9591(layout_function, ):
    col_6ADD0 = layout_function.column(heading='', align=True)
    col_6ADD0.alert = False
    col_6ADD0.enabled = True
    col_6ADD0.active = True
    col_6ADD0.use_property_split = True
    col_6ADD0.use_property_decorate = False
    col_6ADD0.scale_x = 1.0
    col_6ADD0.scale_y = 1.0
    col_6ADD0.alignment = 'Expand'.upper()
    col_6ADD0.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
    col_6ADD0.separator(factor=2.0)
    col_6ADD0.label(text='Initial Setup', icon_value=((load_preview_icon(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_red)) if bpy.context.scene.sna_save_police_reminder else (((load_preview_icon(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_yellow)) if bpy.context.preferences.addons['savepolice'].preferences.sna_alert else load_preview_icon(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_blue))) if bpy.context.preferences.addons['savepolice'].preferences.sna_call_the_save_police else load_preview_icon(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_grey))) if bpy.data.is_dirty else load_preview_icon(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_green)))) if bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_icon else (load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_256x256_Render0013.png')) if bpy.context.scene.sna_save_police_reminder else (((load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_yellow_256x256.png')) if bpy.context.preferences.addons['savepolice'].preferences.sna_alert else load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_blue_256x256.png'))) if bpy.context.preferences.addons['savepolice'].preferences.sna_call_the_save_police else load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_grey_256x256.png'))) if bpy.data.is_dirty else load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_green_256x256.png'))))))
    col_71522 = col_6ADD0.column(heading='', align=True)
    col_71522.alert = False
    col_71522.enabled = True
    col_71522.active = True
    col_71522.use_property_split = True
    col_71522.use_property_decorate = False
    col_71522.scale_x = 1.0
    col_71522.scale_y = 1.5
    col_71522.alignment = 'Expand'.upper()
    col_71522.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
    col_71522.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_call_the_save_police', text='Activate', icon_value=((load_preview_icon(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_red)) if bpy.context.scene.sna_save_police_reminder else (((load_preview_icon(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_yellow)) if bpy.context.preferences.addons['savepolice'].preferences.sna_alert else load_preview_icon(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_blue))) if bpy.context.preferences.addons['savepolice'].preferences.sna_call_the_save_police else load_preview_icon(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_grey))) if bpy.data.is_dirty else load_preview_icon(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_green)))) if bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_icon else (load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_256x256_Render0013.png')) if bpy.context.scene.sna_save_police_reminder else (((load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_yellow_256x256.png')) if bpy.context.preferences.addons['savepolice'].preferences.sna_alert else load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_blue_256x256.png'))) if bpy.context.preferences.addons['savepolice'].preferences.sna_call_the_save_police else load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_grey_256x256.png'))) if bpy.data.is_dirty else load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_green_256x256.png'))))), emboss=True, toggle=True)
    col_E9CE3 = col_6ADD0.column(heading='', align=True)
    col_E9CE3.alert = False
    col_E9CE3.enabled = (not bpy.context.preferences.addons['savepolice'].preferences.sna_call_the_save_police)
    col_E9CE3.active = True
    col_E9CE3.use_property_split = True
    col_E9CE3.use_property_decorate = False
    col_E9CE3.scale_x = 1.0
    col_E9CE3.scale_y = 1.0
    col_E9CE3.alignment = 'Expand'.upper()
    col_E9CE3.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
    if str(bpy.context.preferences.addons['savepolice'].preferences.sna_unit_of_time) == "Minutes":
        col_E9CE3.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_interval', text='Timer (min)', icon_value=0, emboss=True, toggle=True)
    elif str(bpy.context.preferences.addons['savepolice'].preferences.sna_unit_of_time) == "Seconds":
        col_E9CE3.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_interval', text='Timer (sec)', icon_value=0, emboss=True, toggle=True)
    elif str(bpy.context.preferences.addons['savepolice'].preferences.sna_unit_of_time) == "Hours":
        col_E9CE3.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_interval', text='Timer (hr)', icon_value=0, emboss=True, toggle=True)
    else:
        pass
    if (bpy.context.preferences.addons['savepolice'].preferences.sna_detail_level == 'Advanced'):
        col_E9CE3.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_unit_of_time', text='Unit of Time', icon_value=0, emboss=True, expand=True)
    col_E9CE3.separator(factor=2.0)
    if bpy.context.preferences.addons['savepolice'].preferences.sna_detail_level == "Advanced":
        col_6ADD0.label(text='Worry-Free Setup', icon_value=0)
        col_1F900 = col_6ADD0.column(heading='', align=True)
        col_1F900.alert = False
        col_1F900.enabled = True
        col_1F900.active = (not bpy.context.preferences.addons['savepolice'].preferences.sna_alert)
        col_1F900.use_property_split = True
        col_1F900.use_property_decorate = False
        col_1F900.scale_x = 1.0
        col_1F900.scale_y = 1.0
        col_1F900.alignment = 'Expand'.upper()
        col_1F900.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_1F900.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_save_default_file', text='Default Save', icon_value=_icons['Save Icon.png'].icon_id, emboss=True, toggle=True)
    else:
        pass
    if bpy.context.preferences.addons['savepolice'].preferences.sna_detail_level == "Advanced":
        col_6ADD0.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_save_on_load', text='Startup Save', icon_value=15, emboss=True, toggle=True)
        col_B91E4 = col_6ADD0.column(heading='', align=True)
        col_B91E4.alert = False
        col_B91E4.enabled = True
        col_B91E4.active = bpy.context.preferences.addons['savepolice'].preferences.sna_save_default_file
        col_B91E4.use_property_split = True
        col_B91E4.use_property_decorate = False
        col_B91E4.scale_x = 1.0
        col_B91E4.scale_y = 1.0
        col_B91E4.alignment = 'Expand'.upper()
        col_B91E4.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_B91E4.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_default_folder', text='Default Folder', icon_value=0, emboss=True)
        col_B91E4.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_default_save_prefix', text='Prefix', icon_value=0, emboss=True)
        if (os.path.exists(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_default_folder)) and bpy.context.preferences.addons['savepolice'].preferences.sna_save_default_file):
            col_332CC = col_B91E4.column(heading='', align=True)
            col_332CC.alert = False
            col_332CC.enabled = True
            col_332CC.active = True
            col_332CC.use_property_split = True
            col_332CC.use_property_decorate = False
            col_332CC.scale_x = 1.0
            col_332CC.scale_y = 1.0
            col_332CC.alignment = 'Right'.upper()
            col_332CC.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            col_332CC.separator(factor=2.0)
            split_92A3C = col_332CC.split(factor=0.4000000059604645, align=False)
            split_92A3C.alert = False
            split_92A3C.enabled = True
            split_92A3C.active = True
            split_92A3C.use_property_split = False
            split_92A3C.use_property_decorate = False
            split_92A3C.scale_x = 1.0
            split_92A3C.scale_y = 1.0
            split_92A3C.alignment = 'Right'.upper()
            if not True: split_92A3C.operator_context = "EXEC_DEFAULT"
            split_92A3C.label(text='Worry-Free Format', icon_value=0)
            split_92A3C.label(text='Prefix_YYYY-MM-DD_HH-MM-SS.blend', icon_value=0)
            split_1B870 = col_332CC.split(factor=0.4000000059604645, align=False)
            split_1B870.alert = False
            split_1B870.enabled = True
            split_1B870.active = True
            split_1B870.use_property_split = False
            split_1B870.use_property_decorate = False
            split_1B870.scale_x = 1.0
            split_1B870.scale_y = 1.0
            split_1B870.alignment = 'Right'.upper()
            if not True: split_1B870.operator_context = "EXEC_DEFAULT"
            split_1B870.label(text='Worry-Free Example', icon_value=0)
            split_1B870.label(text=os.path.basename(bpy.path.abspath(os.path.join(bpy.context.preferences.addons['savepolice'].preferences.sna_default_folder,bpy.context.preferences.addons['savepolice'].preferences.sna_default_save_prefix + '_' + str(datetime.now().date().year) + '-' + str(datetime.now().date().month) + '-' + str(datetime.now().date().day) + '_' + str(datetime.now().time().hour) + '-' + str(datetime.now().time().minute) + '-' + str(datetime.now().time().second) + '.blend'))), icon_value=0)
        col_B91E4.separator(factor=2.0)
    else:
        pass
    if bpy.context.preferences.addons['savepolice'].preferences.sna_detail_level == "Advanced":
        col_6ADD0.separator(factor=2.0)
        col_6ADD0.label(text='Advanced', icon_value=15)
        col_6ADD0.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_update_screen_areas', text='Always Update Screen', icon_value=692, emboss=True, toggle=True)
        col_6ADD0.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_incremental_saving', text='Increment Saves', icon_value=695, emboss=True, toggle=True)
        col_6ADD0.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_pack_resources', text='Pack Resources', icon_value=(179 if bpy.context.preferences.addons['savepolice'].preferences.sna_pack_resources else 180), emboss=True, toggle=True)
        col_6ADD0.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_use_splash_screen', text='Splash Screen', icon_value=15, emboss=True)
        col_6ADD0.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_collection_size', text='Collection Rows', icon_value=190, emboss=True)
        col_6ADD0.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_global_opacity', text='Global Opacity', icon_value=493, emboss=True)
    else:
        pass
    col_6ADD0.separator(factor=2.0)


def sna_ui_fn_alert_icons_EC7DA(layout_function, ):
    layout_function = layout_function
    sna_ui_fn_save_police_icon_collection_4D3EE(layout_function, )
    layout_function = layout_function
    sna_ui_fn_save_police_alert_only_collection_C445D(layout_function, )
    layout_function.separator(factor=2.0)


def sna_ui_fn_save_police_alerts_props_C4E09(layout_function, ):
    col_ACFCB = layout_function.column(heading='', align=True)
    col_ACFCB.alert = False
    col_ACFCB.enabled = True
    col_ACFCB.active = True
    col_ACFCB.use_property_split = True
    col_ACFCB.use_property_decorate = False
    col_ACFCB.scale_x = 1.0
    col_ACFCB.scale_y = 1.5
    col_ACFCB.alignment = 'Expand'.upper()
    col_ACFCB.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
    col_ACFCB.label(text='Alert or Notify (no auto-save)', icon_value=((load_preview_icon(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_yellow)) if os.path.exists(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_yellow)) else load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_yellow_256x256.png'))) if bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_icon else load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_yellow_256x256.png'))))
    col_ACFCB.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_alert', text='Alert Instead', icon_value=(((load_preview_icon(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_yellow)) if os.path.exists(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_yellow)) else load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_yellow_256x256.png'))) if bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_icon else load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_yellow_256x256.png'))) if bpy.context.preferences.addons['savepolice'].preferences.sna_alert else ((load_preview_icon(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_grey)) if os.path.exists(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_grey)) else load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_grey_256x256.png'))) if bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_icon else load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_grey_256x256.png')))), emboss=True, toggle=True)


def sna_ui_fn_save_police_alert_image_78119(layout_function, ):
    col_17647 = layout_function.column(heading='', align=True)
    col_17647.alert = False
    col_17647.enabled = True
    col_17647.active = True
    col_17647.use_property_split = True
    col_17647.use_property_decorate = False
    col_17647.scale_x = 1.0
    col_17647.scale_y = 1.0
    col_17647.alignment = 'Expand'.upper()
    col_17647.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
    if bpy.context.preferences.addons['savepolice'].preferences.sna_alert:
        col_17647.label(text='Image', icon_value=183)
        col_17647.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_alert_use_image', text='Use Image', icon_value=764, emboss=True)
        if bpy.context.preferences.addons['savepolice'].preferences.sna_alert_use_image:
            if bpy.context.preferences.addons['savepolice'].preferences.sna_detail_level == "Advanced":
                col_17647.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_siren_image_sequence', text='Image Sequence', icon_value=697, emboss=True)
                if bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence:
                    col_17647.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_siren_interval', text='Interval (sec)', icon_value=0, emboss=True)
                col_17647.separator(factor=2.0)
                col_17647.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_siren_custom', text=('Custom Sequence' if bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence else 'Custom Image'), icon_value=(111 if bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence else 696), emboss=True)
                if bpy.context.preferences.addons['savepolice'].preferences.sna_siren_custom:
                    if bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence:
                        col_17647.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_siren_image_sequence_directory', text='Sequence Folder', icon_value=0, emboss=True)
                    else:
                        col_17647.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_siren_image_path', text='Image Path', icon_value=0, emboss=True)
                col_17647.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_siren_image_size', text='Size', icon_value=0, emboss=True)
                col_17647.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_alert_image_location', text='Location', icon_value=0, emboss=True)
                col_21B14 = col_17647.column(heading='', align=True)
                col_21B14.alert = False
                col_21B14.enabled = True
                col_21B14.active = True
                col_21B14.use_property_split = True
                col_21B14.use_property_decorate = False
                col_21B14.scale_x = 1.0
                col_21B14.scale_y = 1.0
                col_21B14.alignment = 'Expand'.upper()
                col_21B14.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                split_8720C = col_21B14.split(factor=0.5, align=True)
                split_8720C.alert = False
                split_8720C.enabled = bpy.context.scene.sna_save_police_animation_active
                split_8720C.active = True
                split_8720C.use_property_split = False
                split_8720C.use_property_decorate = False
                split_8720C.scale_x = 1.0
                split_8720C.scale_y = 1.0
                split_8720C.alignment = 'Expand'.upper()
                if not True: split_8720C.operator_context = "EXEC_DEFAULT"
                split_8720C.label(text='', icon_value=0)
                op = split_8720C.operator('sna.save_police_move_image_f9f28', text='Set with Cursor', icon_value=256, emboss=True, depress=False)
            else:
                pass
        col_17647.separator(factor=2.0)
        col_17647.label(text='Message', icon_value=701)
        col_17647.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_alert_use_message', text='Use Message', icon_value=701, emboss=True, toggle=True)
        if bpy.context.preferences.addons['savepolice'].preferences.sna_alert_use_message:
            col_17647.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_alert_message', text='Message', icon_value=0, emboss=True)
            if bpy.context.preferences.addons['savepolice'].preferences.sna_detail_level == "Advanced":
                col_17647.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_alert_message_size', text='Size', icon_value=0, emboss=True)
                col_17647.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_alert_font', text='Font', icon_value=0, emboss=True)
                col_17647.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_alert_message_dpi', text='DPI', icon_value=0, emboss=True)
                col_17647.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_alert_message_wrap', text='Wrap Width', icon_value=0, emboss=True)
                col_17647.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_alert_color', text='Color', icon_value=0, emboss=True)
                col_17647.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_alert_message_location', text='Location', icon_value=0, emboss=True)
                col_17647.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_alert_message_rotation', text='Rotation', icon_value=0, emboss=True)
                col_086E8 = col_17647.column(heading='', align=True)
                col_086E8.alert = False
                col_086E8.enabled = True
                col_086E8.active = True
                col_086E8.use_property_split = True
                col_086E8.use_property_decorate = False
                col_086E8.scale_x = 1.0
                col_086E8.scale_y = 1.0
                col_086E8.alignment = 'Expand'.upper()
                col_086E8.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                split_0F711 = col_086E8.split(factor=0.5, align=True)
                split_0F711.alert = False
                split_0F711.enabled = bpy.context.scene.sna_save_police_animation_active
                split_0F711.active = True
                split_0F711.use_property_split = False
                split_0F711.use_property_decorate = False
                split_0F711.scale_x = 1.0
                split_0F711.scale_y = 1.0
                split_0F711.alignment = 'Expand'.upper()
                if not True: split_0F711.operator_context = "EXEC_DEFAULT"
                split_0F711.label(text='', icon_value=0)
                op = split_0F711.operator('sna.save_police_move_message_582f8', text='Set with Cursor', icon_value=256, emboss=True, depress=False)
                op.sna_alert_size_initial = 0.0
            else:
                pass
        col_17647.separator(factor=2.0)
        col_17647.label(text='Background', icon_value=362)
        col_17647.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_alert_use_background', text='Use Background', icon_value=27, emboss=True, toggle=True)
        if bpy.context.preferences.addons['savepolice'].preferences.sna_alert_use_background:
            if bpy.context.preferences.addons['savepolice'].preferences.sna_detail_level == "Advanced":
                col_17647.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_alert_custom_background', text='Custom Background', icon_value=362, emboss=True, toggle=True)
            else:
                pass
            if bpy.context.preferences.addons['savepolice'].preferences.sna_alert_custom_background:
                if bpy.context.preferences.addons['savepolice'].preferences.sna_detail_level == "Advanced":
                    col_17647.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_alert_background', text='Background', icon_value=0, emboss=True)
                else:
                    pass
            else:
                col_17647.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_alert_background_color', text='Background Color', icon_value=0, emboss=True)
            col_17647.separator(factor=1.0)
        if bpy.context.preferences.addons['savepolice'].preferences.sna_detail_level == "Advanced":
            if bpy.context.scene.sna_save_police_animation_active:
                op = col_17647.operator('sna.save_police_end_alert_image_preview_7a41b', text='End Preview', icon_value=3, emboss=True, depress=False)
            else:
                op = col_17647.operator('sna.save_police_preview_alert_image_558a3', text='Preview Alert', icon_value=503, emboss=True, depress=False)
        else:
            pass


def sna_ui_fn_alert_countdown_090BA(layout_function, ):
    col_052C5 = layout_function.column(heading='', align=True)
    col_052C5.alert = False
    col_052C5.enabled = True
    col_052C5.active = True
    col_052C5.use_property_split = True
    col_052C5.use_property_decorate = False
    col_052C5.scale_x = 1.0
    col_052C5.scale_y = 1.0
    col_052C5.alignment = 'Expand'.upper()
    col_052C5.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
    col_052C5.label(text='Countdown', icon_value=((load_preview_icon(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_countdown_icon)) if os.path.exists(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_countdown_icon)) else 678) if bpy.context.preferences.addons['savepolice'].preferences.sna_use_custom_countdown_icon else 678))
    col_052C5.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_countdown_on_ui', text='Countdown Button', icon_value=((load_preview_icon(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_countdown_icon)) if os.path.exists(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_countdown_icon)) else 678) if bpy.context.preferences.addons['savepolice'].preferences.sna_use_custom_countdown_icon else 678), emboss=True)
    if bpy.context.preferences.addons['savepolice'].preferences.sna_countdown_on_ui:
        if bpy.context.preferences.addons['savepolice'].preferences.sna_detail_level == "Advanced":
            col_052C5.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_use_custom_countdown_icon', text='Custom Icon', icon_value=((load_preview_icon(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_countdown_icon)) if os.path.exists(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_countdown_icon)) else 678) if bpy.context.preferences.addons['savepolice'].preferences.sna_use_custom_countdown_icon else 678), emboss=True)
        else:
            pass
    if bpy.context.preferences.addons['savepolice'].preferences.sna_use_custom_countdown_icon:
        if bpy.context.preferences.addons['savepolice'].preferences.sna_detail_level == "Advanced":
            col_71B3C = col_052C5.column(heading='', align=True)
            col_71B3C.alert = False
            col_71B3C.enabled = True
            col_71B3C.active = True
            col_71B3C.use_property_split = True
            col_71B3C.use_property_decorate = False
            col_71B3C.scale_x = 1.0
            col_71B3C.scale_y = 1.0
            col_71B3C.alignment = 'Expand'.upper()
            col_71B3C.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            col_71B3C.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_custom_countdown_icon', text='Countdown Icon', icon_value=(load_preview_icon(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_countdown_icon)) if os.path.exists(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_countdown_icon)) else 678), emboss=(not bool(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_countdown_icon)))
        else:
            pass
    col_052C5.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_use_countdown', text='Countdown Message', icon_value=701, emboss=True, toggle=True)
    if bpy.context.preferences.addons['savepolice'].preferences.sna_use_countdown:
        col_052C5.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_countdown_suffix_message', text='Suffix', icon_value=0, emboss=True)
        if bpy.context.preferences.addons['savepolice'].preferences.sna_detail_level == "Advanced":
            col_052C5.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_countdown_size', text='Size', icon_value=0, emboss=True)
            col_052C5.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_countdown_font', text='Font', icon_value=0, emboss=True)
            col_052C5.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_countdown_dpi', text='DPI', icon_value=0, emboss=True)
            col_052C5.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_countdown_wrap', text='Wrap Width', icon_value=0, emboss=True)
            col_052C5.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_countdown_color', text='Color', icon_value=0, emboss=True)
            col_052C5.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_countdown_location', text='Location', icon_value=0, emboss=True)
            col_052C5.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_countdown_rotation', text='Rotation', icon_value=0, emboss=True)
            col_5FA86 = col_052C5.column(heading='', align=True)
            col_5FA86.alert = False
            col_5FA86.enabled = True
            col_5FA86.active = True
            col_5FA86.use_property_split = True
            col_5FA86.use_property_decorate = False
            col_5FA86.scale_x = 1.0
            col_5FA86.scale_y = 1.0
            col_5FA86.alignment = 'Expand'.upper()
            col_5FA86.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            split_D8148 = col_5FA86.split(factor=0.5, align=True)
            split_D8148.alert = False
            split_D8148.enabled = bpy.context.scene.sna_save_police_countdown_active
            split_D8148.active = True
            split_D8148.use_property_split = False
            split_D8148.use_property_decorate = False
            split_D8148.scale_x = 1.0
            split_D8148.scale_y = 1.0
            split_D8148.alignment = 'Expand'.upper()
            if not True: split_D8148.operator_context = "EXEC_DEFAULT"
            split_D8148.label(text='', icon_value=0)
            op = split_D8148.operator('sna.save_police_move_countdown_da3ac', text='Set with Cursor', icon_value=256, emboss=True, depress=False)
            if bpy.context.scene.sna_save_police_countdown_active:
                op = col_5FA86.operator('sna.save_police_end_countdown_preview_8f673', text='End Preview', icon_value=3, emboss=True, depress=False)
            else:
                op = col_5FA86.operator('sna.save_police_preview_countdown_8b9f0', text='Preview Countdown', icon_value=503, emboss=True, depress=False)
        else:
            pass
    layout_function.separator(factor=2.0)


def sna_ui_fn_save_police_ui_settings_8BC5F(layout_function, ):
    col_AFDCC = layout_function.column(heading='', align=True)
    col_AFDCC.alert = False
    col_AFDCC.enabled = True
    col_AFDCC.active = True
    col_AFDCC.use_property_split = True
    col_AFDCC.use_property_decorate = False
    col_AFDCC.scale_x = 1.0
    col_AFDCC.scale_y = 1.0
    col_AFDCC.alignment = 'Expand'.upper()
    col_AFDCC.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
    col_AFDCC.label(text='Toggle UI', icon_value=107)
    col_AFDCC.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_alert_header', text='Header (minimal)', icon_value=49, emboss=True)
    col_AFDCC.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_alert_footer', text='Footer (minimal)', icon_value=50, emboss=True)
    col_AFDCC.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_alert_3d_viewport', text='3D Viewport', icon_value=104, emboss=True)
    col_AFDCC.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_alert_image_editor', text='Image Editor', icon_value=109, emboss=True)
    col_AFDCC.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_alert_node_editors', text='Node Editors', icon_value=24, emboss=True)
    col_AFDCC.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_alert_video_sequencer', text='VSE', icon_value=111, emboss=True)
    col_AFDCC.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_alert_movie_clip_editor', text='Movie Clip', icon_value=123, emboss=True)
    col_AFDCC.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_alert_dopesheet', text='Dope Sheet', icon_value=115, emboss=True)
    col_AFDCC.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_alert_graph_editor', text='Graph Editor', icon_value=105, emboss=True)
    col_AFDCC.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_alert_timeline', text='Timeline', icon_value=118, emboss=True)
    col_AFDCC.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_alert_nla', text='NLA Editor', icon_value=116, emboss=True)
    col_AFDCC.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_alert_text_editor', text='Text Editor', icon_value=112, emboss=True)
    col_AFDCC.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_alert_console', text='Console', icon_value=121, emboss=True)
    col_AFDCC.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_alert_info_log', text='Info Log', icon_value=110, emboss=True)
    col_AFDCC.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_alert_outliner', text='Outliner', icon_value=106, emboss=True)
    col_AFDCC.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_alert_properties', text='Properties', icon_value=107, emboss=True)
    col_AFDCC.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_alert_file_browser', text='File Browser', icon_value=108, emboss=True)
    col_AFDCC.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_alert_asset_browser', text='Asset Browser', icon_value=124, emboss=True)
    col_AFDCC.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_alert_spreadhseet', text='Spreadsheet', icon_value=113, emboss=True)
    col_AFDCC.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_alert_preferences', text='Preferences', icon_value=117, emboss=True)


def sna_ui_fn_save_police_icon_collection_4D3EE(layout_function, ):
    layout_function.label(text='UI Icons', icon_value=((load_preview_icon(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_red)) if bpy.context.scene.sna_save_police_reminder else (((load_preview_icon(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_yellow)) if bpy.context.preferences.addons['savepolice'].preferences.sna_alert else load_preview_icon(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_blue))) if bpy.context.preferences.addons['savepolice'].preferences.sna_call_the_save_police else load_preview_icon(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_grey))) if bpy.data.is_dirty else load_preview_icon(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_green)))) if bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_icon else (load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_256x256_Render0013.png')) if bpy.context.scene.sna_save_police_reminder else (((load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_yellow_256x256.png')) if bpy.context.preferences.addons['savepolice'].preferences.sna_alert else load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_blue_256x256.png'))) if bpy.context.preferences.addons['savepolice'].preferences.sna_call_the_save_police else load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_grey_256x256.png'))) if bpy.data.is_dirty else load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_green_256x256.png'))))))
    split_049C4 = layout_function.split(factor=0.10000000149011612, align=False)
    split_049C4.alert = False
    split_049C4.enabled = True
    split_049C4.active = True
    split_049C4.use_property_split = False
    split_049C4.use_property_decorate = False
    split_049C4.scale_x = 1.0
    split_049C4.scale_y = 1.0
    split_049C4.alignment = 'Expand'.upper()
    if not True: split_049C4.operator_context = "EXEC_DEFAULT"
    split_049C4.label(text='', icon_value=0)
    col_4C13F = split_049C4.column(heading='', align=True)
    col_4C13F.alert = False
    col_4C13F.enabled = True
    col_4C13F.active = True
    col_4C13F.use_property_split = True
    col_4C13F.use_property_decorate = False
    col_4C13F.scale_x = 1.0
    col_4C13F.scale_y = 1.0
    col_4C13F.alignment = 'Expand'.upper()
    col_4C13F.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
    layout_function = col_4C13F
    sna_ui_fn_custom_siren_059E9(layout_function, )


def sna_ui_fn_save_police_alert_only_collection_C445D(layout_function, ):
    layout_function.separator(factor=4.0)
    col_E855F = layout_function.column(heading='', align=True)
    col_E855F.alert = False
    col_E855F.enabled = True
    col_E855F.active = True
    col_E855F.use_property_split = True
    col_E855F.use_property_decorate = False
    col_E855F.scale_x = 1.0
    col_E855F.scale_y = 1.0
    col_E855F.alignment = 'Expand'.upper()
    col_E855F.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
    row_201BA = col_E855F.row(heading='', align=True)
    row_201BA.alert = False
    row_201BA.enabled = True
    row_201BA.active = True
    row_201BA.use_property_split = False
    row_201BA.use_property_decorate = False
    row_201BA.scale_x = 1.0
    row_201BA.scale_y = 1.0
    row_201BA.alignment = 'Expand'.upper()
    row_201BA.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
    layout_function = row_201BA
    sna_ui_fn_save_police_custom_icons_F4AE7(layout_function, )
    row_201BA.label(text=' Alert Notification Icon(s)', icon_value=0)
    split_3A603 = col_E855F.split(factor=0.10000000149011612, align=False)
    split_3A603.alert = False
    split_3A603.enabled = True
    split_3A603.active = True
    split_3A603.use_property_split = False
    split_3A603.use_property_decorate = False
    split_3A603.scale_x = 1.0
    split_3A603.scale_y = 1.0
    split_3A603.alignment = 'Expand'.upper()
    if not True: split_3A603.operator_context = "EXEC_DEFAULT"
    split_3A603.label(text='', icon_value=0)
    col_CF535 = split_3A603.column(heading='', align=True)
    col_CF535.alert = False
    col_CF535.enabled = True
    col_CF535.active = True
    col_CF535.use_property_split = True
    col_CF535.use_property_decorate = False
    col_CF535.scale_x = 1.0
    col_CF535.scale_y = 1.0
    col_CF535.alignment = 'Expand'.upper()
    col_CF535.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
    col_CF535.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_custom_icons', text='Use Custom Icons', icon_value=731, emboss=True)
    if bpy.context.preferences.addons['savepolice'].preferences.sna_custom_icons:
        row_941E4 = col_CF535.row(heading='', align=True)
        row_941E4.alert = False
        row_941E4.enabled = True
        row_941E4.active = True
        row_941E4.use_property_split = False
        row_941E4.use_property_decorate = False
        row_941E4.scale_x = 1.0
        row_941E4.scale_y = 1.0
        row_941E4.alignment = 'Expand'.upper()
        row_941E4.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        coll_id = display_collection_id('4517F', locals())
        row_941E4.template_list('SNA_UL_display_collection_list_4517F', coll_id, bpy.context.preferences.addons['savepolice'].preferences, 'sna_icons_collection', bpy.context.scene, 'sna_save_police_icons_index', rows=0)
        col_15594 = row_941E4.column(heading='', align=True)
        col_15594.alert = False
        col_15594.enabled = True
        col_15594.active = True
        col_15594.use_property_split = False
        col_15594.use_property_decorate = False
        col_15594.scale_x = 1.0
        col_15594.scale_y = 1.0
        col_15594.alignment = 'Expand'.upper()
        col_15594.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = col_15594.operator('sna.add_icon_70949', text='', icon_value=31, emboss=False, depress=False)
        op = col_15594.operator('sna.remove_icon_c74e7', text='', icon_value=32, emboss=False, depress=False)
        col_15594.separator(factor=2.0)
        op = col_15594.operator('sna.move_icon_up_add44', text='', icon_value=7, emboss=False, depress=False)
        op = col_15594.operator('sna.move_icon_down_cffa5', text='', icon_value=5, emboss=False, depress=False)


class SNA_PT_SAVE_POLICE_CD3E3(bpy.types.Panel):
    bl_label = 'Save Police'
    bl_idname = 'SNA_PT_SAVE_POLICE_CD3E3'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Tool'
    bl_order = 0
    bl_options = {'DEFAULT_CLOSED'}
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout
        layout.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_call_the_save_police', text='', icon_value=((load_preview_icon(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_red)) if bpy.context.scene.sna_save_police_reminder else (((load_preview_icon(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_yellow)) if bpy.context.preferences.addons['savepolice'].preferences.sna_alert else load_preview_icon(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_blue))) if bpy.context.preferences.addons['savepolice'].preferences.sna_call_the_save_police else load_preview_icon(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_grey))) if bpy.data.is_dirty else load_preview_icon(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_green)))) if bpy.context.preferences.addons['savepolice'].preferences.sna_custom_siren_icon else (load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_256x256_Render0013.png')) if bpy.context.scene.sna_save_police_reminder else (((load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_yellow_256x256.png')) if bpy.context.preferences.addons['savepolice'].preferences.sna_alert else load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_blue_256x256.png'))) if bpy.context.preferences.addons['savepolice'].preferences.sna_call_the_save_police else load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_grey_256x256.png'))) if bpy.data.is_dirty else load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_green_256x256.png'))))), emboss=False)

    def draw(self, context):
        layout = self.layout
        col_3680D = layout.column(heading='', align=True)
        col_3680D.alert = False
        col_3680D.enabled = True
        col_3680D.active = True
        col_3680D.use_property_split = False
        col_3680D.use_property_decorate = False
        col_3680D.scale_x = 1.0
        col_3680D.scale_y = 1.0
        col_3680D.alignment = 'Expand'.upper()
        col_3680D.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_0952C = col_3680D.row(heading='', align=False)
        row_0952C.alert = False
        row_0952C.enabled = True
        row_0952C.active = True
        row_0952C.use_property_split = False
        row_0952C.use_property_decorate = False
        row_0952C.scale_x = 1.0
        row_0952C.scale_y = 1.5
        row_0952C.alignment = 'Expand'.upper()
        row_0952C.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_0952C.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_detail_level', text=' ', icon_value=0, emboss=True, expand=True)


class SNA_PT_SAVE_POLICE_POPOVER_E6F83(bpy.types.Panel):
    bl_label = 'Save Police Popover'
    bl_idname = 'SNA_PT_SAVE_POLICE_POPOVER_E6F83'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'WINDOW'
    bl_context = ''
    bl_order = 0
    bl_options = {'HIDE_HEADER', 'DEFAULT_CLOSED'}
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout_function = layout
        sna_ui_fn_save_police_B9591(layout_function, )
        layout_function = layout
        sna_ui_fn_alert_countdown_090BA(layout_function, )
        layout_function = layout
        sna_ui_fn_alert_icons_EC7DA(layout_function, )
        layout_function = layout
        sna_ui_fn_save_police_alerts_props_C4E09(layout_function, )
        layout_function = layout
        sna_ui_fn_save_police_alert_image_78119(layout_function, )
        layout_function = layout
        sna_ui_fn_save_police_ui_settings_8BC5F(layout_function, )


def sna_add_to_dopesheet_mt_editor_menus_80884(self, context):
    if not ((not bpy.context.preferences.addons['savepolice'].preferences.sna_alert_dopesheet)):
        layout = self.layout
        layout_function = layout
        sna_ui_fn_animate_icons_E6878(layout_function, )


def sna_add_to_time_mt_editor_menus_1A29B(self, context):
    if not ((not bpy.context.preferences.addons['savepolice'].preferences.sna_alert_timeline)):
        layout = self.layout
        layout_function = layout
        sna_ui_fn_animate_icons_E6878(layout_function, )


def sna_add_to_graph_mt_editor_menus_2E65F(self, context):
    if not ((not bpy.context.preferences.addons['savepolice'].preferences.sna_alert_graph_editor)):
        layout = self.layout
        layout_function = layout
        sna_ui_fn_animate_icons_E6878(layout_function, )


def sna_add_to_nla_mt_editor_menus_33C91(self, context):
    if not ((not bpy.context.preferences.addons['savepolice'].preferences.sna_alert_nla)):
        layout = self.layout
        layout_function = layout
        sna_ui_fn_animate_icons_E6878(layout_function, )


def sna_add_to_image_mt_editor_menus_F9369(self, context):
    if not ((not bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_editor)):
        layout = self.layout
        layout_function = layout
        sna_ui_fn_animate_icons_E6878(layout_function, )


def sna_add_to_sequencer_mt_editor_menus_9024E(self, context):
    if not ((not bpy.context.preferences.addons['savepolice'].preferences.sna_alert_video_sequencer)):
        layout = self.layout
        layout_function = layout
        sna_ui_fn_animate_icons_E6878(layout_function, )


def sna_add_to_clip_mt_tracking_editor_menus_C9255(self, context):
    if not ((not bpy.context.preferences.addons['savepolice'].preferences.sna_alert_movie_clip_editor)):
        layout = self.layout
        layout_function = layout
        sna_ui_fn_animate_icons_E6878(layout_function, )


class SNA_PT_MY_PROJECTS_34DB0(bpy.types.Panel):
    bl_label = 'My Projects'
    bl_idname = 'SNA_PT_MY_PROJECTS_34DB0'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 0
    bl_options = {'DEFAULT_CLOSED'}
    bl_parent_id = 'SNA_PT_SAVE_POLICE_CD3E3'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout_function = layout
        sna_ui_fn_save_police_collection_14313(layout_function, )


class SNA_PT_COUNTDOWN_3644D(bpy.types.Panel):
    bl_label = 'Countdown'
    bl_idname = 'SNA_PT_COUNTDOWN_3644D'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 3
    bl_options = {'DEFAULT_CLOSED'}
    bl_parent_id = 'SNA_PT_SAVE_POLICE_CD3E3'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout_function = layout
        sna_ui_fn_alert_countdown_090BA(layout_function, )


class SNA_PT_GENERAL_915B6(bpy.types.Panel):
    bl_label = 'General'
    bl_idname = 'SNA_PT_GENERAL_915B6'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 1
    bl_options = {'DEFAULT_CLOSED'}
    bl_parent_id = 'SNA_PT_SAVE_POLICE_CD3E3'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout_function = layout
        sna_ui_fn_save_police_B9591(layout_function, )


class SNA_PT_ALERT_B867A(bpy.types.Panel):
    bl_label = 'Alert'
    bl_idname = 'SNA_PT_ALERT_B867A'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 4
    bl_options = {'DEFAULT_CLOSED'}
    bl_parent_id = 'SNA_PT_SAVE_POLICE_CD3E3'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout_function = layout
        sna_ui_fn_save_police_alerts_props_C4E09(layout_function, )
        layout_function = layout
        sna_ui_fn_save_police_alert_image_78119(layout_function, )


class SNA_PT_UI_SETTINGS_6C127(bpy.types.Panel):
    bl_label = 'UI Settings'
    bl_idname = 'SNA_PT_UI_SETTINGS_6C127'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 6
    bl_options = {'DEFAULT_CLOSED'}
    bl_parent_id = 'SNA_PT_SAVE_POLICE_CD3E3'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout_function = layout
        sna_ui_fn_save_police_ui_settings_8BC5F(layout_function, )


class SNA_PT_ICONS_DF022(bpy.types.Panel):
    bl_label = 'Icons'
    bl_idname = 'SNA_PT_ICONS_DF022'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 5
    bl_options = {'DEFAULT_CLOSED'}
    bl_parent_id = 'SNA_PT_SAVE_POLICE_CD3E3'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ((bpy.context.preferences.addons['savepolice'].preferences.sna_detail_level != 'Advanced'))

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout_function = layout
        sna_ui_fn_alert_icons_EC7DA(layout_function, )


class SNA_GROUP_sna_save_police_group(bpy.types.PropertyGroup):
    save_police_file_name: bpy.props.StringProperty(name='Save Police File Name', description='File name', default='', subtype='NONE', maxlen=0)
    save_police_file: bpy.props.StringProperty(name='Save Police File', description='Save file', default='', subtype='FILE_PATH', maxlen=0)


class SNA_GROUP_sna_save_police_icons_group(bpy.types.PropertyGroup):
    icon_path: bpy.props.StringProperty(name='Icon Path', description='Select an icon file (best for small images)', default='', subtype='FILE_PATH', maxlen=0)


class SNA_GROUP_sna_save_police_directory_group(bpy.types.PropertyGroup):
    directory: bpy.props.StringProperty(name='Directory', description='Save Police Directory', default='', subtype='DIR_PATH', maxlen=0, update=sna_update_directory_15C6C)
    project_name: bpy.props.StringProperty(name='Project Name', description='Name of this project', default='', subtype='NONE', maxlen=0)


class SNA_AddonPreferences_70C5B(bpy.types.AddonPreferences):
    bl_idname = 'savepolice'
    sna_call_the_save_police: bpy.props.BoolProperty(name='Call the Save Police', description='Activate the save police timer then perform an auto-save or alert when the timer ends', default=False, update=sna_update_sna_call_the_save_police_8EE76)
    sna_alert: bpy.props.BoolProperty(name='Alert', description='Creates an alert or notification when the timer ends instead of saving', default=False, update=sna_update_sna_alert_1467F)
    sna_save_police_annoy_color: bpy.props.FloatVectorProperty(name='Save Police Annoy Color', description='The annoyance color', size=3, default=(1.0, 0.11900000274181366, 0.07000000029802322), subtype='COLOR', unit='NONE', min=0.0, max=1.0, step=3, precision=6)
    sna_interval: bpy.props.FloatProperty(name='Interval', description='Set the amount of time for the timer. Toggle Advanced settings to change units of time', default=10.0, subtype='NONE', unit='NONE', min=0.009999999776482582, step=1, precision=2, update=sna_update_sna_interval_CA391)
    sna_save_default_file: bpy.props.BoolProperty(name='Save Default File', description='Save a default file when no file save exists (disabled when using alerts)', default=False, update=sna_update_sna_save_default_file_FCB28)
    sna_default_folder: bpy.props.StringProperty(name='Default Folder', description='If no save file exists then auto save file here. Leave blank to disable default saving', default='', subtype='DIR_PATH', maxlen=0)
    sna_default_save_prefix: bpy.props.StringProperty(name='Default Save Prefix', description='Enter a prefix for the default save', default='SavePolice', subtype='NONE', maxlen=0)
    sna_save_on_load: bpy.props.BoolProperty(name='Save On Load', description='Save on blender startup or when loading a file', default=False)
    sna_incremental_saving: bpy.props.BoolProperty(name='Incremental Saving', description='Use incremental saving', default=False)
    sna_alert_3d_viewport: bpy.props.BoolProperty(name='Alert 3D Viewport', description='Use 3D Viewport. Supports all Alert UI elements', default=True)
    sna_alert_image_editor: bpy.props.BoolProperty(name='Alert Image Editor', description='Use the Image Editor. Supports all Alert UI elements', default=False)
    sna_alert_uv_editor: bpy.props.BoolProperty(name='Alert UV Editor', description='Use the UV Editor. Supports all Alert UI elements', default=False)
    sna_alert_node_editors: bpy.props.BoolProperty(name='Alert Node Editors', description='Use Node Editors. Supports all Alert UI elements', default=False)
    sna_alert_video_sequencer: bpy.props.BoolProperty(name='Alert Video Sequencer', description='Use the Video Sequencer. Supports all Alert UI elements', default=False)
    sna_alert_movie_clip_editor: bpy.props.BoolProperty(name='Alert Movie Clip Editor', description='Use Movie Clip Editor. Minimal UI but supports countdown', default=False)
    sna_alert_dopesheet: bpy.props.BoolProperty(name='Alert Dopesheet', description='Use Dopesheet Editor. Minimal UI but supports countdown', default=False)
    sna_alert_timeline: bpy.props.BoolProperty(name='Alert Timeline', description='Use Timeline. Minimal UI but supports countdown', default=False)
    sna_alert_graph_editor: bpy.props.BoolProperty(name='Alert Graph Editor', description='Use Graph Editor. Minimal UI but supports countdown', default=False)
    sna_alert_nla: bpy.props.BoolProperty(name='Alert NLA', description='Use NLA Editor. Minimal UI but supports countdown', default=False)
    sna_alert_text_editor: bpy.props.BoolProperty(name='Alert Text Editor', description='Use Text Editor. Minimal UI but supports countdown', default=False)
    sna_alert_console: bpy.props.BoolProperty(name='Alert Console', description='Use Console. Minimal UI but supports countdown', default=False)
    sna_alert_info_log: bpy.props.BoolProperty(name='Alert Info Log', description='Use Info Log. Minimal UI but supports countdown', default=False)
    sna_alert_outliner: bpy.props.BoolProperty(name='Alert Outliner', description='Use Outliner. Minimal UI but supports countdown', default=False)
    sna_alert_properties: bpy.props.BoolProperty(name='Alert Properties', description='Use Properties. Minimal UI but supports countdown', default=False)
    sna_alert_file_browser: bpy.props.BoolProperty(name='Alert File Browser', description='Use File Browser. Minimal UI but supports countdown', default=False)
    sna_alert_asset_browser: bpy.props.BoolProperty(name='Alert Asset Browser', description='Use Asset Browser. Minimal UI but supports countdown', default=False)
    sna_alert_spreadhseet: bpy.props.BoolProperty(name='Alert Spreadhseet', description='Use Spreadsheet. Minimal UI but supports countdown', default=False)
    sna_alert_preferences: bpy.props.BoolProperty(name='Alert Preferences', description='Use Preferences. Minimal UI but supports countdown', default=False)
    sna_change_theme: bpy.props.BoolProperty(name='Change Theme', description='Change Theme Colors on Alert', default=False)
    sna_animate: bpy.props.BoolProperty(name='Animate', description='Animate the Alert', default=False)
    sna_alert_footer: bpy.props.BoolProperty(name='Alert Footer', description='Use Footer. Minimal UI with no countdown', default=False)
    sna_alert_header: bpy.props.BoolProperty(name='Alert Header', description='Use Header. Minimal UI with no countdown', default=False)
    sna_siren_image_active: bpy.props.BoolProperty(name='Siren Image Active', description='Siren Image Alert is Active', default=False)
    sna_siren_image_sequence: bpy.props.BoolProperty(name='Siren Image Sequence', description='Use Siren Image Sequence', default=False)
    sna_siren_image_sequence_directory: bpy.props.StringProperty(name='Siren Image Sequence Directory', description='Siren Image Directory', default='', subtype='DIR_PATH', maxlen=0)
    sna_siren_image_path: bpy.props.StringProperty(name='Siren Image Path', description='Siren Image Path', default='', subtype='FILE_PATH', maxlen=0)
    sna_siren_custom: bpy.props.BoolProperty(name='Siren Custom', description='Use Custom Image or Sequence', default=False)
    sna_siren_image_size: bpy.props.FloatVectorProperty(name='Siren Image Size', description='', size=2, default=(256.0, 256.0), subtype='XYZ', unit='NONE', min=10.0, soft_min=10.0, soft_max=1024.0, step=100, precision=0)
    sna_siren_interval: bpy.props.FloatProperty(name='Siren Interval', description='The amount of time between images in the sequence in seconds', default=0.25, subtype='TIME', unit='TIME', min=0.029999999329447746, max=60.0, soft_max=2.0, step=5, precision=2)
    sna_alert_message: bpy.props.StringProperty(name='Alert Message', description='Enter a custom message for your alert', default='Time to Save', subtype='NONE', maxlen=0)
    sna_alert_font: bpy.props.StringProperty(name='Alert Font', description='Leave Blank for Default Font', default='', subtype='FILE_PATH', maxlen=0)
    sna_alert_color: bpy.props.FloatVectorProperty(name='Alert Color', description='Color of Alert Font', size=4, default=(0.7940999865531921, 0.7940999865531921, 0.7940999865531921, 0.75), subtype='COLOR', unit='NONE', min=0.0, max=1.0, step=1, precision=4)
    sna_alert_message_size: bpy.props.FloatProperty(name='Alert Message Size', description='Size of the Alert Text', default=48.0, subtype='NONE', unit='NONE', min=8.0, soft_max=300.0, step=5, precision=0)
    sna_alert_message_location: bpy.props.FloatVectorProperty(name='Alert Message Location', description='', size=2, default=(20.0, 20.0), subtype='XYZ', unit='NONE', min=1.0, step=100, precision=0)
    sna_alert_image_location: bpy.props.FloatVectorProperty(name='Alert Image Location', description='Location of the Image', size=2, default=(32.0, 64.0), subtype='XYZ', unit='NONE', min=1.0, step=100, precision=0)
    sna_alert_background: bpy.props.StringProperty(name='Alert Background', description='Backgorund Image', default='', subtype='FILE_PATH', maxlen=0)
    sna_alert_use_background: bpy.props.BoolProperty(name='Alert Use Background', description='Add A Background to Your Alert', default=False)
    sna_alert_custom_background: bpy.props.BoolProperty(name='Alert Custom Background', description='Use a Custom Background', default=False)
    sna_alert_background_color: bpy.props.FloatVectorProperty(name='Alert Background Color', description='Set the background color of the alert', size=4, default=(0.05000000074505806, 0.05000000074505806, 0.05000000074505806, 0.5), subtype='COLOR', unit='NONE', min=0.0, max=1.0, step=1, precision=4)
    sna_alert_use_image: bpy.props.BoolProperty(name='Alert Use Image', description='Use an Image for the Alert', default=False)
    sna_alert_message_wrap: bpy.props.IntProperty(name='Alert Message Wrap', description='Wrap width of alert message', default=3000, subtype='NONE', min=0)
    sna_alert_message_dpi: bpy.props.IntProperty(name='Alert Message DPI', description='DPI of Text', default=72, subtype='NONE', min=2, soft_min=72)
    sna_alert_message_rotation: bpy.props.FloatProperty(name='Alert Message Rotation', description='Rotation of the Message', default=0.0, subtype='ANGLE', unit='ROTATION', step=5, precision=0)
    sna_alert_use_message: bpy.props.BoolProperty(name='Alert Use Message', description='Use alert Message', default=False)
    sna_use_countdown: bpy.props.BoolProperty(name='Use Countdown', description='Show Countdown on screen', default=False, update=sna_update_sna_use_countdown_255C0)
    sna_countdown_font: bpy.props.StringProperty(name='Countdown Font', description='Leave Blank for Default Font', default='', subtype='FILE_PATH', maxlen=0)
    sna_countdown_size: bpy.props.FloatProperty(name='Countdown Size', description='', default=48.0, subtype='NONE', unit='NONE', min=8.0, soft_max=300.0, step=100, precision=0)
    sna_countdown_location: bpy.props.FloatVectorProperty(name='Countdown Location', description='Location of the Countdown', size=2, default=(20.0, 20.0), subtype='XYZ', unit='NONE', min=1.0, step=100, precision=0)
    sna_countdown_wrap: bpy.props.IntProperty(name='Countdown Wrap', description='Wrap width of the countdown', default=3000, subtype='NONE', min=0)
    sna_countdown_dpi: bpy.props.IntProperty(name='Countdown DPI', description='DPI of Countdown text', default=72, subtype='NONE', min=2, soft_min=72)
    sna_countdown_rotation: bpy.props.FloatProperty(name='Countdown Rotation', description='', default=0.0, subtype='ANGLE', unit='ROTATION', step=5, precision=0)
    sna_countdown_color: bpy.props.FloatVectorProperty(name='Countdown Color', description='Color of Countdown Font', size=4, default=(0.7940999865531921, 0.7940999865531921, 0.7940999865531921, 0.75), subtype='COLOR', unit='NONE', min=0.0, max=1.0, step=1, precision=4)
    sna_countdown_suffix_message: bpy.props.StringProperty(name='Countdown Suffix Message', description='Leave blank for no suffix', default='remaining', subtype='NONE', maxlen=0)
    sna_update_screen_areas: bpy.props.BoolProperty(name='Update Screen Areas', description='Show updates each second (might affect performance)', default=False)
    sna_countdown_on_ui: bpy.props.BoolProperty(name='Countdown on UI', description='Display time remaining on UI (updates when you hover over it)', default=True)
    sna_pack_resources: bpy.props.BoolProperty(name='Pack Resources', description='Pack Resources with Save or prior to Alert', default=False)
    sna_global_opacity: bpy.props.FloatProperty(name='Global Opacity', description='Set the opacity for countdown, alert, message, etc.', default=1.0, subtype='NONE', unit='NONE', min=0.0, max=1.0, step=1, precision=2)
    sna_use_splash_screen: bpy.props.BoolProperty(name='Use Splash Screen', description='Place the Save Police Collection on the Splash Screen', default=False)
    sna_collection_size: bpy.props.IntProperty(name='Collection Size', description='Set the number of rows for the collection (set to 0 for default behavior)', default=0, subtype='NONE', min=0, soft_max=25)
    sna_icons_collection: bpy.props.CollectionProperty(name='Icons Collection', description='', type=SNA_GROUP_sna_save_police_icons_group)
    sna_custom_icons: bpy.props.BoolProperty(name='Custom Icons', description='Use Custom Icons', default=False)
    sna_custom_siren_icon: bpy.props.BoolProperty(name='Custom Siren Icon', description='Use Custom Siren', default=False)
    sna_custom_siren_grey: bpy.props.StringProperty(name='Custom Siren Grey', description='Choose a file for inactive Siren', default='', subtype='FILE_PATH', maxlen=0)
    sna_custom_siren_blue: bpy.props.StringProperty(name='Custom Siren Blue', description='Choose a file for active Siren', default='', subtype='FILE_PATH', maxlen=0)
    sna_custom_siren_yellow: bpy.props.StringProperty(name='Custom Siren Yellow', description='Choose a file for active unsaved Siren', default='', subtype='FILE_PATH', maxlen=0)
    sna_custom_siren_red: bpy.props.StringProperty(name='Custom Siren Red', description='Choose a file for active alert Siren', default='', subtype='FILE_PATH', maxlen=0)
    sna_custom_siren_green: bpy.props.StringProperty(name='Custom Siren Green', description='Choose a file for saved Siren', default='', subtype='FILE_PATH', maxlen=0)
    sna_use_custom_countdown_icon: bpy.props.BoolProperty(name='Use Custom Countdown Icon', description='Use a Custom Countdown Icon', default=False)
    sna_custom_countdown_icon: bpy.props.StringProperty(name='Custom Countdown Icon', description='Select the file for the custom countdown icon', default='', subtype='FILE_PATH', maxlen=0)
    sna_view_single_or_multiple_projects: bpy.props.BoolProperty(name='View Single or Multiple Projects', description='View files in a Single Project Folder or Multiple Projects', default=False, update=sna_update_sna_view_single_or_multiple_projects_4BB3A)
    sna_save_police_directory_collection: bpy.props.CollectionProperty(name='Save Police Directory Collection', description='', type=SNA_GROUP_sna_save_police_directory_group)
    sna_save_police_directory_collection_index: bpy.props.IntProperty(name='Save Police Directory Collection Index', description='Selected directory of save files', default=0, subtype='NONE', update=sna_update_sna_save_police_directory_collection_index_D956E)
    sna_detail_level: bpy.props.EnumProperty(name='Detail Level', description='', items=sna_detail_level_enum_items)

    def sna_unit_of_time_enum_items(self, context):
        return [("No Items", "No Items", "No generate enum items node found to create items!", "ERROR", 0)]
    sna_unit_of_time: bpy.props.EnumProperty(name='Unit of Time', description='', items=[('Minutes', 'Minutes', 'Set the Time Interval in Minutes', 675, 0), ('Seconds', 'Seconds', 'Set the Time Interval in Seconds', 675, 1), ('Hours', 'Hours', 'Set the Time Interval in Hours', 675, 2)])

    def draw(self, context):
        if not (False):
            layout = self.layout 
            col_9FF99 = layout.column(heading='', align=True)
            col_9FF99.alert = False
            col_9FF99.enabled = True
            col_9FF99.active = True
            col_9FF99.use_property_split = False
            col_9FF99.use_property_decorate = False
            col_9FF99.scale_x = 1.0
            col_9FF99.scale_y = 1.0
            col_9FF99.alignment = 'Expand'.upper()
            col_9FF99.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_F753E = col_9FF99.row(heading='', align=False)
            row_F753E.alert = False
            row_F753E.enabled = True
            row_F753E.active = True
            row_F753E.use_property_split = False
            row_F753E.use_property_decorate = False
            row_F753E.scale_x = 1.0
            row_F753E.scale_y = 1.5
            row_F753E.alignment = 'Expand'.upper()
            row_F753E.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_F753E.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_detail_level', text=' ', icon_value=0, emboss=True, expand=True)
            layout_function = layout
            sna_ui_fn_save_police_B9591(layout_function, )
            layout_function = layout
            sna_ui_fn_alert_countdown_090BA(layout_function, )
            layout_function = layout
            sna_ui_fn_save_police_alerts_props_C4E09(layout_function, )
            layout_function = layout
            sna_ui_fn_save_police_alert_image_78119(layout_function, )
            layout.separator(factor=2.0)
            if (bpy.context.preferences.addons['savepolice'].preferences.sna_detail_level == 'Advanced'):
                layout_function = layout
                sna_ui_fn_alert_icons_EC7DA(layout_function, )
            layout_function = layout
            sna_ui_fn_save_police_ui_settings_8BC5F(layout_function, )
            layout.separator(factor=2.0)


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.utils.register_class(SNA_GROUP_sna_save_police_group)
    bpy.utils.register_class(SNA_GROUP_sna_save_police_icons_group)
    bpy.utils.register_class(SNA_GROUP_sna_save_police_directory_group)
    bpy.types.Scene.sna_save_police_animation_active = bpy.props.BoolProperty(name='Save Police Animation Active', description='The Image Animation is Active', default=False)
    bpy.types.Scene.sna_save_police_countdown_active = bpy.props.BoolProperty(name='Save Police Countdown Active', description='The Countdown is active', default=False)
    bpy.types.Scene.sna_save_police_theme_active = bpy.props.BoolProperty(name='Save Police Theme Active', description='Theme color changing is active', default=False)
    bpy.types.Scene.sna_save_police_interval = bpy.props.FloatProperty(name='Save Police Interval', description='Number of minutes for Save Police', default=10.0, subtype='NONE', unit='NONE', min=0.009999999776482582, step=1, precision=1, update=sna_update_sna_save_police_interval_8D7BA)
    bpy.types.Scene.sna_save_police_script_interval = bpy.props.IntProperty(name='Save Police Script Interval', description='', default=60, subtype='NONE', min=1, soft_min=1440)
    bpy.types.Scene.sna_save_police_timer_freq = bpy.props.IntProperty(name='Save Police Timer Freq', description='How many seconds per minute', default=60, subtype='NONE', min=1, soft_max=60)
    bpy.types.Scene.sna_save_police_reminder = bpy.props.BoolProperty(name='Save Police Reminder', description='Reminder after save police timer completes', default=False, update=sna_update_sna_save_police_reminder_9D6ED)
    bpy.types.Scene.sna_save_police_annoy_active = bpy.props.BoolProperty(name='Save Police Annoy Active', description='Annoyance is now active', default=False)
    bpy.types.Scene.sna_animation_timer = bpy.props.FloatProperty(name='Animation Timer', description='How fast do you want the animation to run in seconds', default=0.25, subtype='NONE', unit='NONE', min=0.009999999776482582, soft_max=1.0, step=3, precision=6)
    bpy.types.Scene.sna_animation_interval = bpy.props.IntProperty(name='Animation Interval', description='Number of animations', default=5, subtype='NONE', min=1, soft_max=23)
    bpy.types.Scene.sna_save_police_collection = bpy.props.CollectionProperty(name='Save Police Collection', description='Collection of Saves', type=SNA_GROUP_sna_save_police_group)
    bpy.types.Scene.sna_save_police_collection_index = bpy.props.IntProperty(name='Save Police Collection Index', description='', default=0, subtype='NONE')
    bpy.types.Scene.sna_load_save_police_collection = bpy.props.BoolProperty(name='Load Save Police Collection', description='Load Save Police Saves from Default Folder or latest save folder', default=False, update=sna_update_sna_load_save_police_collection_69320)
    bpy.types.Scene.sna_save_police_icons_index = bpy.props.IntProperty(name='Save Police Icons Index', description='', default=0, subtype='NONE')
    bpy.utils.register_class(SNA_OT_Save_Police_Preview_Alert_Image_558A3)
    bpy.utils.register_class(SNA_OT_Save_Police_End_Alert_Image_Preview_7A41B)
    bpy.utils.register_class(SNA_OT_Save_Police_End_Countdown_Preview_8F673)
    bpy.utils.register_class(SNA_OT_Save_Police_Preview_Countdown_8B9F0)
    bpy.utils.register_class(SNA_OT_Save_Police_Draw_Countdown_F091C)
    bpy.utils.register_class(SNA_OT_Add_Icon_70949)
    bpy.utils.register_class(SNA_OT_Remove_Icon_C74E7)
    bpy.utils.register_class(SNA_OT_Move_Icon_Up_Add44)
    bpy.utils.register_class(SNA_OT_Move_Icon_Down_Cffa5)
    bpy.utils.register_class(SNA_OT_Save_Police_Move_Countdown_Da3Ac)
    bpy.utils.register_class(SNA_OT_Save_Police_Move_Image_F9F28)
    bpy.utils.register_class(SNA_OT_Save_Police_Move_Message_582F8)
    bpy.utils.register_class(SNA_OT_Save_Police_Reload_Save_Collection_14F82)
    bpy.utils.register_class(SNA_OT_Save_Police_Add_To_Save_Collection_Fc42D)
    bpy.utils.register_class(SNA_OT_Open_Save_Police_File_B25Ee)
    bpy.utils.register_class(SNA_OT_Delete_File_Eea1A)
    bpy.utils.register_class(SNA_OT_Add_Save_Police_Directory_4283D)
    bpy.utils.register_class(SNA_OT_Remove_A_Folder_48Bb9)
    bpy.utils.register_class(SNA_OT_Move_Save_Police_Directory_Item_Up_27Fc6)
    bpy.utils.register_class(SNA_OT_Move_Save_Police_Directory_Item_Down_4373D)
    bpy.utils.register_class(SNA_OT_Add_A_Folder_0414E)
    bpy.utils.register_class(SNA_OT_Save_To_Selected_Project_39F67)
    bpy.utils.register_class(SNA_OT_Change_Folder_81F37)
    bpy.utils.register_class(SNA_OT_Op_Save_Police_Save_C2308)
    bpy.utils.register_class(SNA_UL_display_collection_list_0B171)
    bpy.utils.register_class(SNA_MT_2F16D)
    bpy.utils.register_class(SNA_UL_display_collection_list_E485D)
    bpy.types.WM_MT_splash.prepend(sna_add_to_wm_mt_splash_F2C56)
    bpy.types.FILEBROWSER_MT_editor_menus.append(sna_add_to_filebrowser_mt_editor_menus_457D3)
    bpy.types.ASSETBROWSER_MT_editor_menus.append(sna_add_to_assetbrowser_mt_editor_menus_E5265)
    bpy.types.SPREADSHEET_HT_header.append(sna_add_to_spreadsheet_ht_header_318BA)
    atexit.register(before_exit_handler_8A0D1)
    bpy.app.handlers.load_post.append(load_post_handler_0B793)
    bpy.app.handlers.save_post.append(save_post_handler_70958)
    bpy.utils.register_class(SNA_OT_Op_Save_Police_Saving_148E8)
    bpy.types.VIEW3D_MT_editor_menus.append(sna_add_to_view3d_mt_editor_menus_6B622)
    bpy.types.CONSOLE_MT_editor_menus.append(sna_add_to_console_mt_editor_menus_9AC1C)
    bpy.types.INFO_MT_editor_menus.append(sna_add_to_info_mt_editor_menus_787B8)
    bpy.types.TEXT_MT_editor_menus.append(sna_add_to_text_mt_editor_menus_C945C)
    bpy.types.STATUSBAR_HT_header.append(sna_add_to_statusbar_ht_header_2ABD9)
    bpy.types.TOPBAR_MT_editor_menus.append(sna_add_to_topbar_mt_editor_menus_020E6)
    bpy.types.NODE_MT_editor_menus.append(sna_add_to_node_mt_editor_menus_0C1AE)
    bpy.types.OUTLINER_HT_header.append(sna_add_to_outliner_ht_header_923DF)
    bpy.types.USERPREF_MT_editor_menus.append(sna_add_to_userpref_mt_editor_menus_02C87)
    bpy.types.PROPERTIES_HT_header.append(sna_add_to_properties_ht_header_444AD)
    if not 'Save Icon.png' in _icons: _icons.load('Save Icon.png', os.path.join(os.path.dirname(__file__), 'icons', 'Save Icon.png'), "IMAGE")
    bpy.utils.register_class(SNA_UL_display_collection_list_4517F)
    bpy.utils.register_class(SNA_PT_SAVE_POLICE_CD3E3)
    bpy.utils.register_class(SNA_PT_SAVE_POLICE_POPOVER_E6F83)
    bpy.types.DOPESHEET_MT_editor_menus.append(sna_add_to_dopesheet_mt_editor_menus_80884)
    bpy.types.TIME_MT_editor_menus.append(sna_add_to_time_mt_editor_menus_1A29B)
    bpy.types.GRAPH_MT_editor_menus.append(sna_add_to_graph_mt_editor_menus_2E65F)
    bpy.types.NLA_MT_editor_menus.append(sna_add_to_nla_mt_editor_menus_33C91)
    bpy.types.IMAGE_MT_editor_menus.append(sna_add_to_image_mt_editor_menus_F9369)
    bpy.types.SEQUENCER_MT_editor_menus.append(sna_add_to_sequencer_mt_editor_menus_9024E)
    bpy.types.CLIP_MT_tracking_editor_menus.append(sna_add_to_clip_mt_tracking_editor_menus_C9255)
    bpy.utils.register_class(SNA_AddonPreferences_70C5B)
    bpy.utils.register_class(SNA_PT_MY_PROJECTS_34DB0)
    bpy.utils.register_class(SNA_PT_COUNTDOWN_3644D)
    bpy.utils.register_class(SNA_PT_GENERAL_915B6)
    bpy.utils.register_class(SNA_PT_ALERT_B867A)
    bpy.utils.register_class(SNA_PT_UI_SETTINGS_6C127)
    bpy.utils.register_class(SNA_PT_ICONS_DF022)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    del bpy.types.Scene.sna_save_police_icons_index
    del bpy.types.Scene.sna_load_save_police_collection
    del bpy.types.Scene.sna_save_police_collection_index
    del bpy.types.Scene.sna_save_police_collection
    del bpy.types.Scene.sna_animation_interval
    del bpy.types.Scene.sna_animation_timer
    del bpy.types.Scene.sna_save_police_annoy_active
    del bpy.types.Scene.sna_save_police_reminder
    del bpy.types.Scene.sna_save_police_timer_freq
    del bpy.types.Scene.sna_save_police_script_interval
    del bpy.types.Scene.sna_save_police_interval
    del bpy.types.Scene.sna_save_police_theme_active
    del bpy.types.Scene.sna_save_police_countdown_active
    del bpy.types.Scene.sna_save_police_animation_active
    bpy.utils.unregister_class(SNA_GROUP_sna_save_police_directory_group)
    bpy.utils.unregister_class(SNA_GROUP_sna_save_police_icons_group)
    bpy.utils.unregister_class(SNA_GROUP_sna_save_police_group)
    if handler_5FE5D:
        bpy.types.SpaceView3D.draw_handler_remove(handler_5FE5D[0], 'WINDOW')
        handler_5FE5D.pop(0)
    if handler_D8705:
        bpy.types.SpaceImageEditor.draw_handler_remove(handler_D8705[0], 'WINDOW')
        handler_D8705.pop(0)
    if handler_AAAFB:
        bpy.types.SpaceNodeEditor.draw_handler_remove(handler_AAAFB[0], 'WINDOW')
        handler_AAAFB.pop(0)
    bpy.utils.unregister_class(SNA_OT_Save_Police_Preview_Alert_Image_558A3)
    bpy.utils.unregister_class(SNA_OT_Save_Police_End_Alert_Image_Preview_7A41B)
    if handler_CB41D:
        bpy.types.SpaceSequenceEditor.draw_handler_remove(handler_CB41D[0], 'WINDOW')
        handler_CB41D.pop(0)
    if handler_EE591:
        bpy.types.SpaceView3D.draw_handler_remove(handler_EE591[0], 'WINDOW')
        handler_EE591.pop(0)
    if handler_A1E89:
        bpy.types.SpaceImageEditor.draw_handler_remove(handler_A1E89[0], 'WINDOW')
        handler_A1E89.pop(0)
    if handler_0A529:
        bpy.types.SpaceNodeEditor.draw_handler_remove(handler_0A529[0], 'WINDOW')
        handler_0A529.pop(0)
    bpy.utils.unregister_class(SNA_OT_Save_Police_End_Countdown_Preview_8F673)
    bpy.utils.unregister_class(SNA_OT_Save_Police_Preview_Countdown_8B9F0)
    bpy.utils.unregister_class(SNA_OT_Save_Police_Draw_Countdown_F091C)
    if handler_F57E6:
        bpy.types.SpaceSequenceEditor.draw_handler_remove(handler_F57E6[0], 'WINDOW')
        handler_F57E6.pop(0)
    bpy.utils.unregister_class(SNA_OT_Add_Icon_70949)
    bpy.utils.unregister_class(SNA_OT_Remove_Icon_C74E7)
    bpy.utils.unregister_class(SNA_OT_Move_Icon_Up_Add44)
    bpy.utils.unregister_class(SNA_OT_Move_Icon_Down_Cffa5)
    bpy.utils.unregister_class(SNA_OT_Save_Police_Move_Countdown_Da3Ac)
    bpy.utils.unregister_class(SNA_OT_Save_Police_Move_Image_F9F28)
    bpy.utils.unregister_class(SNA_OT_Save_Police_Move_Message_582F8)
    bpy.utils.unregister_class(SNA_OT_Save_Police_Reload_Save_Collection_14F82)
    bpy.utils.unregister_class(SNA_OT_Save_Police_Add_To_Save_Collection_Fc42D)
    bpy.utils.unregister_class(SNA_OT_Open_Save_Police_File_B25Ee)
    bpy.utils.unregister_class(SNA_OT_Delete_File_Eea1A)
    bpy.utils.unregister_class(SNA_OT_Add_Save_Police_Directory_4283D)
    bpy.utils.unregister_class(SNA_OT_Remove_A_Folder_48Bb9)
    bpy.utils.unregister_class(SNA_OT_Move_Save_Police_Directory_Item_Up_27Fc6)
    bpy.utils.unregister_class(SNA_OT_Move_Save_Police_Directory_Item_Down_4373D)
    bpy.utils.unregister_class(SNA_OT_Add_A_Folder_0414E)
    bpy.utils.unregister_class(SNA_OT_Save_To_Selected_Project_39F67)
    bpy.utils.unregister_class(SNA_OT_Change_Folder_81F37)
    bpy.utils.unregister_class(SNA_OT_Op_Save_Police_Save_C2308)
    bpy.utils.unregister_class(SNA_UL_display_collection_list_0B171)
    bpy.utils.unregister_class(SNA_MT_2F16D)
    bpy.utils.unregister_class(SNA_UL_display_collection_list_E485D)
    bpy.types.WM_MT_splash.remove(sna_add_to_wm_mt_splash_F2C56)
    bpy.types.FILEBROWSER_MT_editor_menus.remove(sna_add_to_filebrowser_mt_editor_menus_457D3)
    bpy.types.ASSETBROWSER_MT_editor_menus.remove(sna_add_to_assetbrowser_mt_editor_menus_E5265)
    bpy.types.SPREADSHEET_HT_header.remove(sna_add_to_spreadsheet_ht_header_318BA)
    atexit.unregister(before_exit_handler_8A0D1)
    bpy.app.handlers.load_post.remove(load_post_handler_0B793)
    bpy.app.handlers.save_post.remove(save_post_handler_70958)
    bpy.utils.unregister_class(SNA_OT_Op_Save_Police_Saving_148E8)
    bpy.types.VIEW3D_MT_editor_menus.remove(sna_add_to_view3d_mt_editor_menus_6B622)
    bpy.types.CONSOLE_MT_editor_menus.remove(sna_add_to_console_mt_editor_menus_9AC1C)
    bpy.types.INFO_MT_editor_menus.remove(sna_add_to_info_mt_editor_menus_787B8)
    bpy.types.TEXT_MT_editor_menus.remove(sna_add_to_text_mt_editor_menus_C945C)
    bpy.types.STATUSBAR_HT_header.remove(sna_add_to_statusbar_ht_header_2ABD9)
    bpy.types.TOPBAR_MT_editor_menus.remove(sna_add_to_topbar_mt_editor_menus_020E6)
    bpy.types.NODE_MT_editor_menus.remove(sna_add_to_node_mt_editor_menus_0C1AE)
    bpy.types.OUTLINER_HT_header.remove(sna_add_to_outliner_ht_header_923DF)
    bpy.types.USERPREF_MT_editor_menus.remove(sna_add_to_userpref_mt_editor_menus_02C87)
    bpy.types.PROPERTIES_HT_header.remove(sna_add_to_properties_ht_header_444AD)
    bpy.utils.unregister_class(SNA_UL_display_collection_list_4517F)
    bpy.utils.unregister_class(SNA_PT_SAVE_POLICE_CD3E3)
    bpy.utils.unregister_class(SNA_PT_SAVE_POLICE_POPOVER_E6F83)
    bpy.types.DOPESHEET_MT_editor_menus.remove(sna_add_to_dopesheet_mt_editor_menus_80884)
    bpy.types.TIME_MT_editor_menus.remove(sna_add_to_time_mt_editor_menus_1A29B)
    bpy.types.GRAPH_MT_editor_menus.remove(sna_add_to_graph_mt_editor_menus_2E65F)
    bpy.types.NLA_MT_editor_menus.remove(sna_add_to_nla_mt_editor_menus_33C91)
    bpy.types.IMAGE_MT_editor_menus.remove(sna_add_to_image_mt_editor_menus_F9369)
    bpy.types.SEQUENCER_MT_editor_menus.remove(sna_add_to_sequencer_mt_editor_menus_9024E)
    bpy.types.CLIP_MT_tracking_editor_menus.remove(sna_add_to_clip_mt_tracking_editor_menus_C9255)
    bpy.utils.unregister_class(SNA_AddonPreferences_70C5B)
    bpy.utils.unregister_class(SNA_PT_MY_PROJECTS_34DB0)
    bpy.utils.unregister_class(SNA_PT_COUNTDOWN_3644D)
    bpy.utils.unregister_class(SNA_PT_GENERAL_915B6)
    bpy.utils.unregister_class(SNA_PT_ALERT_B867A)
    bpy.utils.unregister_class(SNA_PT_UI_SETTINGS_6C127)
    bpy.utils.unregister_class(SNA_PT_ICONS_DF022)
