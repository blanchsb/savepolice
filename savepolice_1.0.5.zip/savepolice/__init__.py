# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "SavePolice",
    "author" : "blanchsb", 
    "description" : "Call upon the save police to serve and protect your work",
    "blender" : (3, 0, 0),
    "version" : (1, 0, 5),
    "location" : "Tool Panel",
    "warning" : "",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "System" 
}


import bpy
import bpy.utils.previews
import gpu
import gpu_extras
import os
import blf
import atexit
from bpy.app.handlers import persistent


addon_keymaps = {}
_icons = None
g_draw_alert_image_3d_view = {'sna_frame': 0, 'sna_stop': False, 'sna_custom_frame_length': 0, }
g_draw_alert_image_image_editor = {'sna_frame': 0, 'sna_custom_frame_length': 0, 'sna_stop': False, }
g_draw_alert_image_node_editor = {'sna_frame': 0, 'sna_custom_frame_length': 0, 'sna_stop': False, }
g_draw_alert_image_vse_editor = {'sna_frame': 0, 'sna_custom_frame_length': 0, 'sna_stop': False, }
graph_debug_testing = {'sna_debug_count': 0, 'sna_var_run_in_intervals': False, }
graph_scripts = {'sna_minutes': 0, 'sna_animation_minutes': 0, 'sna_timer_freq': 60, 'sna_timer_interval': 10, 'sna_timer_sec': 1, }
handler_5FE5D = []
handler_D8705 = []
handler_AAAFB = []


def find_areas_of_type(screen, area_type):
    areas = []
    for area in screen.areas:
        if area.type == area_type:
            areas.append(area)
    return areas


def find_biggest_area_by_type(screen, area_type):
    areas = find_areas_of_type(screen, area_type)
    if not areas: return []
    max_area = (areas[0], areas[0].width * areas[0].height)
    for area in areas:
        if area.width * area.height > max_area[1]:
            max_area = (area, area.width * area.height)
    return max_area[0]


handler_CB41D = []


def property_exists(prop_path, glob, loc):
    try:
        eval(prop_path, glob, loc)
        return True
    except:
        return False


handler_64666 = []


def sna_update_sna_call_the_save_police_8EE76(self, context):
    sna_updated_prop = self.sna_call_the_save_police
    bpy.context.scene.sna_save_police_interval = bpy.context.preferences.addons['savepolice'].preferences.sna_interval
    if sna_updated_prop:
        if (bpy.context.preferences.addons['savepolice'].preferences.sna_save_default_file and (not os.path.exists(bpy.data.filepath)) and os.path.exists(bpy.context.preferences.addons['savepolice'].preferences.sna_default_folder)):
            bpy.ops.sna.op_save_police_saving_148e8('INVOKE_DEFAULT', )
        sna_fn_start_stop_save_police_timer_34567(True)
    else:
        bpy.context.scene.sna_save_police_reminder = False
        sna_fn_start_stop_save_police_timer_34567(False)


def sna_update_sna_annoyance_only_1467F(self, context):
    sna_updated_prop = self.sna_annoyance_only
    if sna_updated_prop:
        pass
    else:
        bpy.context.scene.sna_save_police_reminder = False
        bpy.ops.sna.op_annoy_restore_theme_colors_954ce('INVOKE_DEFAULT', )
    if bpy.context.preferences.addons['savepolice'].preferences.sna_call_the_save_police:
        sna_fn_start_stop_save_police_timer_34567(True)


def sna_update_sna_change_theme_993B2(self, context):
    sna_updated_prop = self.sna_change_theme
    if sna_updated_prop:
        if (bpy.context.preferences.addons['savepolice'].preferences.sna_call_the_save_police and (not bpy.context.scene.sna_save_police_theme_active) and bpy.context.scene.sna_save_police_reminder):
            bpy.ops.sna.op_annoy_store_and_swap_theme_colors_c1b7f('INVOKE_DEFAULT', )
    else:
        bpy.ops.sna.op_annoy_restore_theme_colors_954ce('INVOKE_DEFAULT', )


def sna_update_sna_interval_CA391(self, context):
    sna_updated_prop = self.sna_interval
    bpy.context.scene.sna_save_police_interval = sna_updated_prop


def sna_update_sna_save_police_reminder_9D6ED(self, context):
    sna_updated_prop = self.sna_save_police_reminder
    if sna_updated_prop:
        if bpy.context.preferences.addons['savepolice'].preferences.sna_annoyance_only:
            sna_fn_start_stop_save_police_timer_34567(False)
            sna_fn_animate_icons_EF932()
            if bpy.context.preferences.addons['savepolice'].preferences.sna_change_theme:
                bpy.ops.sna.op_annoy_store_and_swap_theme_colors_c1b7f('INVOKE_DEFAULT', )
        else:
            if (bpy.data.is_dirty and bpy.context.preferences.addons['savepolice'].preferences.sna_call_the_save_police):
                bpy.ops.sna.op_save_police_saving_148e8('INVOKE_DEFAULT', )
        if bpy.context.scene.sna_save_police_animation_active:
            pass
        else:
            bpy.ops.sna.save_police_preview_alert_image_558a3('INVOKE_DEFAULT', )
    else:
        if bpy.context.scene.sna_save_police_annoy_active:
            bpy.context.scene.sna_save_police_annoy_active = False
            if bpy.context.preferences.addons['savepolice'].preferences.sna_change_theme:
                bpy.ops.sna.op_annoy_restore_theme_colors_954ce('INVOKE_DEFAULT', )


def sna_update_sna_save_police_interval_8D7BA(self, context):
    sna_updated_prop = self.sna_save_police_interval


def load_preview_icon(path):
    global _icons
    if not path in _icons:
        if os.path.exists(path):
            _icons.load(path, path, "IMAGE")
        else:
            return 0
    return _icons[path].icon_id


def sna_fn_modal_drawing_2699F():
    if bool(find_areas_of_type(bpy.context.screen, 'VIEW_3D')):
        if bpy.context.preferences.addons['savepolice'].preferences.sna_alert_use_background:
            if (os.path.exists(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_alert_background)) and bpy.context.preferences.addons['savepolice'].preferences.sna_alert_custom_background):
                coords = (  ((1.0, 1.0)[0], (1.0, 1.0)[1])   , ((1.0, 1.0)[0]+find_biggest_area_by_type(bpy.context.screen, 'VIEW_3D').width,(1.0, 1.0)[1])  ,  ((1.0, 1.0)[0]+find_biggest_area_by_type(bpy.context.screen, 'VIEW_3D').width, (1.0, 1.0)[1]+find_biggest_area_by_type(bpy.context.screen, 'VIEW_3D').height)  ,   ((1.0, 1.0)[0], (1.0, 1.0)[1]+find_biggest_area_by_type(bpy.context.screen, 'VIEW_3D').height)   )
                bpy.data.images.load(filepath=bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_alert_background), check_existing=True, )

                def get_img_name():
                    this = os.path.basename(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_alert_background))
                    for i in range(len(bpy.data.images)):
                        if bpy.data.images[i].name == bpy.data.images[this].name:
                            return bpy.data.images[i]
                texture = gpu.texture.from_image(get_img_name())
                blender_version = bpy.app.version
                if blender_version >= (4, 0, 0):
                    shader = gpu.shader.from_builtin('IMAGE')
                else: 
                    shader = gpu.shader.from_builtin('2D_IMAGE')
                batch = gpu_extras.batch.batch_for_shader(
                    shader, 'TRI_FAN',
                    {
                        "pos": coords,
                        "texCoord": ((0, 0), (1, 0), (1, 1), (0, 1)),
                    },
                )
                shader.bind()
                gpu.state.blend_set('ALPHA')
                shader.uniform_sampler("image", texture)
                batch.draw(shader)
            else:
                quads = [[tuple((1.0, 1.0)), tuple((find_biggest_area_by_type(bpy.context.screen, 'VIEW_3D').width, 1.0)), tuple((1.0, find_biggest_area_by_type(bpy.context.screen, 'VIEW_3D').height)), tuple((find_biggest_area_by_type(bpy.context.screen, 'VIEW_3D').width, find_biggest_area_by_type(bpy.context.screen, 'VIEW_3D').height))]]
                vertices = []
                indices = []
                for i_7A2A5, quad in enumerate(quads):
                    vertices.extend(quad)
                    indices.extend([(i_7A2A5 * 4, i_7A2A5 * 4 + 1, i_7A2A5 * 4 + 2), (i_7A2A5 * 4 + 2, i_7A2A5 * 4 + 1, i_7A2A5 * 4 + 3)])
                shader = gpu.shader.from_builtin('UNIFORM_COLOR')
                batch = gpu_extras.batch.batch_for_shader(shader, 'TRIS', {"pos": tuple(vertices)}, indices=tuple(indices))
                shader.bind()
                shader.uniform_float("color", bpy.context.preferences.addons['savepolice'].preferences.sna_alert_background_color)
                gpu.state.blend_set('ALPHA')
                batch.draw(shader)
        if bpy.context.preferences.addons['savepolice'].preferences.sna_alert_use_image:
            if bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence:
                if bpy.context.preferences.addons['savepolice'].preferences.sna_siren_custom:
                    if os.path.isdir(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory)):
                        directory = bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory)

                        def get_sequence_length(directory):
                            if not directory or not os.path.exists(directory):  # Check if the directory is empty or does not exist
                                return 0
                            try:
                                files = [f for f in os.listdir(directory) if f.endswith('.png')]
                                return min(len(files), 101)
                            except Exception as e:
                                print(f"An error occurred while getting the sequence length: {e}")
                                return 0
                        if directory:
                            sequence_length = get_sequence_length(directory)
                            start_frame_value = g_draw_alert_image_3d_view['sna_frame']
                            start_frame = max(0, min(100, start_frame_value))
                            end_frame_value = g_draw_alert_image_3d_view['sna_custom_frame_length']
                            end_frame = max(0, min(100, end_frame_value))
                            start_frame = min(start_frame, end_frame)
                            bl = bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location
                            coords = ((bl[0], bl[1]), (bl[0] + bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[0], bl[1]), (bl[0] + 
                            bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[0], bl[1] + bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[1]), (bl[0], bl[1] + 
                            bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[1]))

                            def get_image_from_directory(dial_value, directory):
                                files = [f for f in os.listdir(directory) if f.endswith('.png')]
                                files.sort()
                                sequence_length = min(get_sequence_length(directory), 101)
                                if 0 <= dial_value < sequence_length:
                                    image_path = os.path.join(directory, files[dial_value])
                                    bpy.data.images.load(filepath=image_path, check_existing=True)
                                    return bpy.data.images[os.path.basename(image_path)]
                                else:
                                    return None
                            dial_value = g_draw_alert_image_3d_view['sna_frame']
                            image = get_image_from_directory(dial_value, directory)
                            if image is not None:
                                texture = gpu.texture.from_image(image)
                                blender_version = bpy.app.version
                                if blender_version >= (4, 0, 0):
                                    shader = gpu.shader.from_builtin('IMAGE')
                                else: 
                                    shader = gpu.shader.from_builtin('2D_IMAGE')
                                batch = gpu_extras.batch.batch_for_shader(
                                    shader, 'TRI_FAN',
                                    {
                                        'pos': coords,
                                        'texCoord': ((0, 0), (1, 0), (1, 1), (0, 1)),
                                    },
                                )
                                shader.bind()
                                gpu.state.blend_set('ALPHA')
                                shader.uniform_sampler('image', texture)
                                batch.draw(shader)
                else:
                    directory = os.path.join(os.path.dirname(__file__), 'assets', 'Becon Composites 256 x 256')

                    def get_sequence_length(directory):
                        if not directory or not os.path.exists(directory):  # Check if the directory is empty or does not exist
                            return 0
                        try:
                            files = [f for f in os.listdir(directory) if f.endswith('.png')]
                            return min(len(files), 101)
                        except Exception as e:
                            print(f"An error occurred while getting the sequence length: {e}")
                            return 0
                    if directory:
                        sequence_length = get_sequence_length(directory)
                        start_frame_value = g_draw_alert_image_3d_view['sna_frame']
                        start_frame = max(0, min(100, start_frame_value))
                        end_frame_value = 22
                        end_frame = max(0, min(100, end_frame_value))
                        start_frame = min(start_frame, end_frame)
                        bl = bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location
                        coords = ((bl[0], bl[1]), (bl[0] + bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[0], bl[1]), (bl[0] + 
                        bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[0], bl[1] + bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[1]), (bl[0], bl[1] + 
                        bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[1]))

                        def get_image_from_directory(dial_value, directory):
                            files = [f for f in os.listdir(directory) if f.endswith('.png')]
                            files.sort()
                            sequence_length = min(get_sequence_length(directory), 101)
                            if 0 <= dial_value < sequence_length:
                                image_path = os.path.join(directory, files[dial_value])
                                bpy.data.images.load(filepath=image_path, check_existing=True)
                                return bpy.data.images[os.path.basename(image_path)]
                            else:
                                return None
                        dial_value = g_draw_alert_image_3d_view['sna_frame']
                        image = get_image_from_directory(dial_value, directory)
                        if image is not None:
                            texture = gpu.texture.from_image(image)
                            blender_version = bpy.app.version
                            if blender_version >= (4, 0, 0):
                                shader = gpu.shader.from_builtin('IMAGE')
                            else: 
                                shader = gpu.shader.from_builtin('2D_IMAGE')
                            batch = gpu_extras.batch.batch_for_shader(
                                shader, 'TRI_FAN',
                                {
                                    'pos': coords,
                                    'texCoord': ((0, 0), (1, 0), (1, 1), (0, 1)),
                                },
                            )
                            shader.bind()
                            gpu.state.blend_set('ALPHA')
                            shader.uniform_sampler('image', texture)
                            batch.draw(shader)
            else:
                if bpy.context.preferences.addons['savepolice'].preferences.sna_siren_custom:
                    if os.path.exists(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_path)):
                        coords = (  (bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[0], bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[1])   , (bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[0]+bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[0],bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[1])  ,  (bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[0]+bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[0], bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[1]+bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[1])  ,   (bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[0], bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[1]+bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[1])   )
                        bpy.data.images.load(filepath=bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_path), check_existing=True, )

                        def get_img_name():
                            this = os.path.basename(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_path))
                            for i in range(len(bpy.data.images)):
                                if bpy.data.images[i].name == bpy.data.images[this].name:
                                    return bpy.data.images[i]
                        texture = gpu.texture.from_image(get_img_name())
                        blender_version = bpy.app.version
                        if blender_version >= (4, 0, 0):
                            shader = gpu.shader.from_builtin('IMAGE')
                        else: 
                            shader = gpu.shader.from_builtin('2D_IMAGE')
                        batch = gpu_extras.batch.batch_for_shader(
                            shader, 'TRI_FAN',
                            {
                                "pos": coords,
                                "texCoord": ((0, 0), (1, 0), (1, 1), (0, 1)),
                            },
                        )
                        shader.bind()
                        gpu.state.blend_set('ALPHA')
                        shader.uniform_sampler("image", texture)
                        batch.draw(shader)
                else:
                    coords = (  (bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[0], bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[1])   , (bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[0]+bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[0],bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[1])  ,  (bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[0]+bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[0], bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[1]+bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[1])  ,   (bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[0], bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[1]+bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[1])   )
                    bpy.data.images.load(filepath=os.path.join(os.path.dirname(__file__), 'assets', 'Siren_256x256_Render0013.png'), check_existing=True, )

                    def get_img_name():
                        this = os.path.basename(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_256x256_Render0013.png'))
                        for i in range(len(bpy.data.images)):
                            if bpy.data.images[i].name == bpy.data.images[this].name:
                                return bpy.data.images[i]
                    texture = gpu.texture.from_image(get_img_name())
                    blender_version = bpy.app.version
                    if blender_version >= (4, 0, 0):
                        shader = gpu.shader.from_builtin('IMAGE')
                    else: 
                        shader = gpu.shader.from_builtin('2D_IMAGE')
                    batch = gpu_extras.batch.batch_for_shader(
                        shader, 'TRI_FAN',
                        {
                            "pos": coords,
                            "texCoord": ((0, 0), (1, 0), (1, 1), (0, 1)),
                        },
                    )
                    shader.bind()
                    gpu.state.blend_set('ALPHA')
                    shader.uniform_sampler("image", texture)
                    batch.draw(shader)
            font_id = 0
            if bpy.context.preferences.addons['savepolice'].preferences.sna_alert_font and os.path.exists(bpy.context.preferences.addons['savepolice'].preferences.sna_alert_font):
                font_id = blf.load(bpy.context.preferences.addons['savepolice'].preferences.sna_alert_font)
            if font_id == -1:
                print("Couldn't load font!")
            else:
                x_F0888, y_F0888 = bpy.context.preferences.addons['savepolice'].preferences.sna_alert_message_location
                blf.position(font_id, x_F0888, y_F0888, 0)
                if bpy.app.version >= (3, 4, 0):
                    blf.size(font_id, bpy.context.preferences.addons['savepolice'].preferences.sna_alert_message_size)
                else:
                    blf.size(font_id, bpy.context.preferences.addons['savepolice'].preferences.sna_alert_message_size, 72)
                clr = bpy.context.preferences.addons['savepolice'].preferences.sna_alert_color
                blf.color(font_id, clr[0], clr[1], clr[2], clr[3])
                if 0:
                    blf.enable(font_id, blf.WORD_WRAP)
                    blf.word_wrap(font_id, 0)
                if 0.0:
                    blf.enable(font_id, blf.ROTATION)
                    blf.rotation(font_id, 0.0)
                blf.enable(font_id, blf.WORD_WRAP)
                blf.draw(font_id, bpy.context.preferences.addons['savepolice'].preferences.sna_alert_message)
                blf.disable(font_id, blf.ROTATION)
                blf.disable(font_id, blf.WORD_WRAP)


def sna_fn_draw_siren_end_5EC29():
    bpy.context.scene.sna_save_police_animation_active = False
    g_draw_alert_image_3d_view['sna_stop'] = True
    if handler_5FE5D:
        bpy.types.SpaceView3D.draw_handler_remove(handler_5FE5D[0], 'WINDOW')
        handler_5FE5D.pop(0)
        for a in bpy.context.screen.areas: a.tag_redraw()


def sna_fn_draw_siren_start_FE25B():
    g_draw_alert_image_3d_view['sna_frame'] = 0
    g_draw_alert_image_3d_view['sna_custom_frame_length'] = 0
    g_draw_alert_image_3d_view['sna_stop'] = False
    bpy.context.scene.sna_save_police_animation_active = True
    handler_5FE5D.append(bpy.types.SpaceView3D.draw_handler_add(sna_fn_modal_drawing_2699F, (), 'WINDOW', 'POST_PIXEL'))
    for a in bpy.context.screen.areas: a.tag_redraw()
    if bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence:

        def delayed_CF5D6():
            if bpy.context.preferences.addons['savepolice'].preferences.sna_siren_custom:
                if os.path.isdir(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory)):
                    if (len([os.path.join(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory), f) for f in os.listdir(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory)) if os.path.isfile(os.path.join(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory), f))]) > 0):
                        g_draw_alert_image_3d_view['sna_custom_frame_length'] = len([os.path.join(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory), f) for f in os.listdir(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory)) if os.path.isfile(os.path.join(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory), f))])
                    else:
                        g_draw_alert_image_3d_view['sna_custom_frame_length'] = 0
                else:
                    g_draw_alert_image_3d_view['sna_custom_frame_length'] = 0
            g_draw_alert_image_3d_view['sna_frame'] += 1
            if (g_draw_alert_image_3d_view['sna_frame'] >= (g_draw_alert_image_3d_view['sna_custom_frame_length'] if bpy.context.preferences.addons['savepolice'].preferences.sna_siren_custom else 22)):
                g_draw_alert_image_3d_view['sna_frame'] = 0
            if g_draw_alert_image_3d_view['sna_stop']:
                return None
            return bpy.context.preferences.addons['savepolice'].preferences.sna_siren_interval
        bpy.app.timers.register(delayed_CF5D6, first_interval=0.0)


def sna_fn_modal_drawing_image_editor_B195C():
    if bool(find_areas_of_type(bpy.context.screen, 'IMAGE_EDITOR')):
        if bpy.context.preferences.addons['savepolice'].preferences.sna_alert_use_background:
            if (os.path.exists(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_alert_background)) and bpy.context.preferences.addons['savepolice'].preferences.sna_alert_custom_background):
                coords = (  ((1.0, 1.0)[0], (1.0, 1.0)[1])   , ((1.0, 1.0)[0]+find_biggest_area_by_type(bpy.context.screen, 'IMAGE_EDITOR').width,(1.0, 1.0)[1])  ,  ((1.0, 1.0)[0]+find_biggest_area_by_type(bpy.context.screen, 'IMAGE_EDITOR').width, (1.0, 1.0)[1]+find_biggest_area_by_type(bpy.context.screen, 'IMAGE_EDITOR').height)  ,   ((1.0, 1.0)[0], (1.0, 1.0)[1]+find_biggest_area_by_type(bpy.context.screen, 'IMAGE_EDITOR').height)   )
                bpy.data.images.load(filepath=bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_alert_background), check_existing=True, )

                def get_img_name():
                    this = os.path.basename(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_alert_background))
                    for i in range(len(bpy.data.images)):
                        if bpy.data.images[i].name == bpy.data.images[this].name:
                            return bpy.data.images[i]
                texture = gpu.texture.from_image(get_img_name())
                blender_version = bpy.app.version
                if blender_version >= (4, 0, 0):
                    shader = gpu.shader.from_builtin('IMAGE')
                else: 
                    shader = gpu.shader.from_builtin('2D_IMAGE')
                batch = gpu_extras.batch.batch_for_shader(
                    shader, 'TRI_FAN',
                    {
                        "pos": coords,
                        "texCoord": ((0, 0), (1, 0), (1, 1), (0, 1)),
                    },
                )
                shader.bind()
                gpu.state.blend_set('ALPHA')
                shader.uniform_sampler("image", texture)
                batch.draw(shader)
            else:
                quads = [[tuple((1.0, 1.0)), tuple((find_biggest_area_by_type(bpy.context.screen, 'IMAGE_EDITOR').width, 1.0)), tuple((1.0, find_biggest_area_by_type(bpy.context.screen, 'IMAGE_EDITOR').height)), tuple((find_biggest_area_by_type(bpy.context.screen, 'IMAGE_EDITOR').width, find_biggest_area_by_type(bpy.context.screen, 'IMAGE_EDITOR').height))]]
                vertices = []
                indices = []
                for i_B5E84, quad in enumerate(quads):
                    vertices.extend(quad)
                    indices.extend([(i_B5E84 * 4, i_B5E84 * 4 + 1, i_B5E84 * 4 + 2), (i_B5E84 * 4 + 2, i_B5E84 * 4 + 1, i_B5E84 * 4 + 3)])
                shader = gpu.shader.from_builtin('UNIFORM_COLOR')
                batch = gpu_extras.batch.batch_for_shader(shader, 'TRIS', {"pos": tuple(vertices)}, indices=tuple(indices))
                shader.bind()
                shader.uniform_float("color", bpy.context.preferences.addons['savepolice'].preferences.sna_alert_background_color)
                gpu.state.blend_set('ALPHA')
                batch.draw(shader)
        if bpy.context.preferences.addons['savepolice'].preferences.sna_alert_use_image:
            if bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence:
                if bpy.context.preferences.addons['savepolice'].preferences.sna_siren_custom:
                    if os.path.isdir(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory)):
                        directory = bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory)

                        def get_sequence_length(directory):
                            if not directory or not os.path.exists(directory):  # Check if the directory is empty or does not exist
                                return 0
                            try:
                                files = [f for f in os.listdir(directory) if f.endswith('.png')]
                                return min(len(files), 101)
                            except Exception as e:
                                print(f"An error occurred while getting the sequence length: {e}")
                                return 0
                        if directory:
                            sequence_length = get_sequence_length(directory)
                            start_frame_value = g_draw_alert_image_image_editor['sna_frame']
                            start_frame = max(0, min(100, start_frame_value))
                            end_frame_value = g_draw_alert_image_image_editor['sna_custom_frame_length']
                            end_frame = max(0, min(100, end_frame_value))
                            start_frame = min(start_frame, end_frame)
                            bl = bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location
                            coords = ((bl[0], bl[1]), (bl[0] + bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[0], bl[1]), (bl[0] + 
                            bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[0], bl[1] + bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[1]), (bl[0], bl[1] + 
                            bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[1]))

                            def get_image_from_directory(dial_value, directory):
                                files = [f for f in os.listdir(directory) if f.endswith('.png')]
                                files.sort()
                                sequence_length = min(get_sequence_length(directory), 101)
                                if 0 <= dial_value < sequence_length:
                                    image_path = os.path.join(directory, files[dial_value])
                                    bpy.data.images.load(filepath=image_path, check_existing=True)
                                    return bpy.data.images[os.path.basename(image_path)]
                                else:
                                    return None
                            dial_value = g_draw_alert_image_image_editor['sna_frame']
                            image = get_image_from_directory(dial_value, directory)
                            if image is not None:
                                texture = gpu.texture.from_image(image)
                                blender_version = bpy.app.version
                                if blender_version >= (4, 0, 0):
                                    shader = gpu.shader.from_builtin('IMAGE')
                                else: 
                                    shader = gpu.shader.from_builtin('2D_IMAGE')
                                batch = gpu_extras.batch.batch_for_shader(
                                    shader, 'TRI_FAN',
                                    {
                                        'pos': coords,
                                        'texCoord': ((0, 0), (1, 0), (1, 1), (0, 1)),
                                    },
                                )
                                shader.bind()
                                gpu.state.blend_set('ALPHA')
                                shader.uniform_sampler('image', texture)
                                batch.draw(shader)
                else:
                    directory = os.path.join(os.path.dirname(__file__), 'assets', 'Becon Composites 256 x 256')

                    def get_sequence_length(directory):
                        if not directory or not os.path.exists(directory):  # Check if the directory is empty or does not exist
                            return 0
                        try:
                            files = [f for f in os.listdir(directory) if f.endswith('.png')]
                            return min(len(files), 101)
                        except Exception as e:
                            print(f"An error occurred while getting the sequence length: {e}")
                            return 0
                    if directory:
                        sequence_length = get_sequence_length(directory)
                        start_frame_value = g_draw_alert_image_image_editor['sna_frame']
                        start_frame = max(0, min(100, start_frame_value))
                        end_frame_value = 22
                        end_frame = max(0, min(100, end_frame_value))
                        start_frame = min(start_frame, end_frame)
                        bl = bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location
                        coords = ((bl[0], bl[1]), (bl[0] + bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[0], bl[1]), (bl[0] + 
                        bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[0], bl[1] + bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[1]), (bl[0], bl[1] + 
                        bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[1]))

                        def get_image_from_directory(dial_value, directory):
                            files = [f for f in os.listdir(directory) if f.endswith('.png')]
                            files.sort()
                            sequence_length = min(get_sequence_length(directory), 101)
                            if 0 <= dial_value < sequence_length:
                                image_path = os.path.join(directory, files[dial_value])
                                bpy.data.images.load(filepath=image_path, check_existing=True)
                                return bpy.data.images[os.path.basename(image_path)]
                            else:
                                return None
                        dial_value = g_draw_alert_image_image_editor['sna_frame']
                        image = get_image_from_directory(dial_value, directory)
                        if image is not None:
                            texture = gpu.texture.from_image(image)
                            blender_version = bpy.app.version
                            if blender_version >= (4, 0, 0):
                                shader = gpu.shader.from_builtin('IMAGE')
                            else: 
                                shader = gpu.shader.from_builtin('2D_IMAGE')
                            batch = gpu_extras.batch.batch_for_shader(
                                shader, 'TRI_FAN',
                                {
                                    'pos': coords,
                                    'texCoord': ((0, 0), (1, 0), (1, 1), (0, 1)),
                                },
                            )
                            shader.bind()
                            gpu.state.blend_set('ALPHA')
                            shader.uniform_sampler('image', texture)
                            batch.draw(shader)
            else:
                if bpy.context.preferences.addons['savepolice'].preferences.sna_siren_custom:
                    if os.path.exists(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_path)):
                        coords = (  (bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[0], bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[1])   , (bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[0]+bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[0],bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[1])  ,  (bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[0]+bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[0], bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[1]+bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[1])  ,   (bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[0], bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[1]+bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[1])   )
                        bpy.data.images.load(filepath=bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_path), check_existing=True, )

                        def get_img_name():
                            this = os.path.basename(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_path))
                            for i in range(len(bpy.data.images)):
                                if bpy.data.images[i].name == bpy.data.images[this].name:
                                    return bpy.data.images[i]
                        texture = gpu.texture.from_image(get_img_name())
                        blender_version = bpy.app.version
                        if blender_version >= (4, 0, 0):
                            shader = gpu.shader.from_builtin('IMAGE')
                        else: 
                            shader = gpu.shader.from_builtin('2D_IMAGE')
                        batch = gpu_extras.batch.batch_for_shader(
                            shader, 'TRI_FAN',
                            {
                                "pos": coords,
                                "texCoord": ((0, 0), (1, 0), (1, 1), (0, 1)),
                            },
                        )
                        shader.bind()
                        gpu.state.blend_set('ALPHA')
                        shader.uniform_sampler("image", texture)
                        batch.draw(shader)
                else:
                    coords = (  (bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[0], bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[1])   , (bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[0]+bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[0],bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[1])  ,  (bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[0]+bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[0], bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[1]+bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[1])  ,   (bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[0], bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[1]+bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[1])   )
                    bpy.data.images.load(filepath=os.path.join(os.path.dirname(__file__), 'assets', 'Siren_256x256_Render0013.png'), check_existing=True, )

                    def get_img_name():
                        this = os.path.basename(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_256x256_Render0013.png'))
                        for i in range(len(bpy.data.images)):
                            if bpy.data.images[i].name == bpy.data.images[this].name:
                                return bpy.data.images[i]
                    texture = gpu.texture.from_image(get_img_name())
                    blender_version = bpy.app.version
                    if blender_version >= (4, 0, 0):
                        shader = gpu.shader.from_builtin('IMAGE')
                    else: 
                        shader = gpu.shader.from_builtin('2D_IMAGE')
                    batch = gpu_extras.batch.batch_for_shader(
                        shader, 'TRI_FAN',
                        {
                            "pos": coords,
                            "texCoord": ((0, 0), (1, 0), (1, 1), (0, 1)),
                        },
                    )
                    shader.bind()
                    gpu.state.blend_set('ALPHA')
                    shader.uniform_sampler("image", texture)
                    batch.draw(shader)
            font_id = 0
            if bpy.context.preferences.addons['savepolice'].preferences.sna_alert_font and os.path.exists(bpy.context.preferences.addons['savepolice'].preferences.sna_alert_font):
                font_id = blf.load(bpy.context.preferences.addons['savepolice'].preferences.sna_alert_font)
            if font_id == -1:
                print("Couldn't load font!")
            else:
                x_3A761, y_3A761 = bpy.context.preferences.addons['savepolice'].preferences.sna_alert_message_location
                blf.position(font_id, x_3A761, y_3A761, 0)
                if bpy.app.version >= (3, 4, 0):
                    blf.size(font_id, bpy.context.preferences.addons['savepolice'].preferences.sna_alert_message_size)
                else:
                    blf.size(font_id, bpy.context.preferences.addons['savepolice'].preferences.sna_alert_message_size, 72)
                clr = bpy.context.preferences.addons['savepolice'].preferences.sna_alert_color
                blf.color(font_id, clr[0], clr[1], clr[2], clr[3])
                if 0:
                    blf.enable(font_id, blf.WORD_WRAP)
                    blf.word_wrap(font_id, 0)
                if 0.0:
                    blf.enable(font_id, blf.ROTATION)
                    blf.rotation(font_id, 0.0)
                blf.enable(font_id, blf.WORD_WRAP)
                blf.draw(font_id, bpy.context.preferences.addons['savepolice'].preferences.sna_alert_message)
                blf.disable(font_id, blf.ROTATION)
                blf.disable(font_id, blf.WORD_WRAP)


def sna_fn_draw_siren_end_8EADA():
    bpy.context.scene.sna_save_police_animation_active = False
    g_draw_alert_image_image_editor['sna_stop'] = True
    if handler_D8705:
        bpy.types.SpaceImageEditor.draw_handler_remove(handler_D8705[0], 'WINDOW')
        handler_D8705.pop(0)
        for a in bpy.context.screen.areas: a.tag_redraw()


def sna_fn_draw_siren_start_68E9D():
    g_draw_alert_image_image_editor['sna_frame'] = 0
    g_draw_alert_image_image_editor['sna_custom_frame_length'] = 0
    g_draw_alert_image_image_editor['sna_stop'] = False
    bpy.context.scene.sna_save_police_animation_active = True
    handler_D8705.append(bpy.types.SpaceImageEditor.draw_handler_add(sna_fn_modal_drawing_image_editor_B195C, (), 'WINDOW', 'POST_PIXEL'))
    for a in bpy.context.screen.areas: a.tag_redraw()
    if bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence:

        def delayed_3E6B7():
            if bpy.context.preferences.addons['savepolice'].preferences.sna_siren_custom:
                if os.path.isdir(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory)):
                    if (len([os.path.join(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory), f) for f in os.listdir(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory)) if os.path.isfile(os.path.join(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory), f))]) > 0):
                        g_draw_alert_image_image_editor['sna_custom_frame_length'] = len([os.path.join(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory), f) for f in os.listdir(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory)) if os.path.isfile(os.path.join(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory), f))])
                    else:
                        g_draw_alert_image_image_editor['sna_custom_frame_length'] = 0
                else:
                    g_draw_alert_image_image_editor['sna_custom_frame_length'] = 0
            g_draw_alert_image_image_editor['sna_frame'] += 1
            if (g_draw_alert_image_image_editor['sna_frame'] >= (g_draw_alert_image_image_editor['sna_custom_frame_length'] if bpy.context.preferences.addons['savepolice'].preferences.sna_siren_custom else 22)):
                g_draw_alert_image_image_editor['sna_frame'] = 0
            if g_draw_alert_image_image_editor['sna_stop']:
                return None
            return bpy.context.preferences.addons['savepolice'].preferences.sna_siren_interval
        bpy.app.timers.register(delayed_3E6B7, first_interval=0.0)


def sna_fn_modal_drawing_node_editor_BA36C():
    if bool(find_areas_of_type(bpy.context.screen, 'NODE_EDITOR')):
        if bpy.context.preferences.addons['savepolice'].preferences.sna_alert_use_background:
            if (os.path.exists(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_alert_background)) and bpy.context.preferences.addons['savepolice'].preferences.sna_alert_custom_background):
                coords = (  ((1.0, 1.0)[0], (1.0, 1.0)[1])   , ((1.0, 1.0)[0]+find_biggest_area_by_type(bpy.context.screen, 'NODE_EDITOR').width,(1.0, 1.0)[1])  ,  ((1.0, 1.0)[0]+find_biggest_area_by_type(bpy.context.screen, 'NODE_EDITOR').width, (1.0, 1.0)[1]+find_biggest_area_by_type(bpy.context.screen, 'NODE_EDITOR').height)  ,   ((1.0, 1.0)[0], (1.0, 1.0)[1]+find_biggest_area_by_type(bpy.context.screen, 'NODE_EDITOR').height)   )
                bpy.data.images.load(filepath=bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_alert_background), check_existing=True, )

                def get_img_name():
                    this = os.path.basename(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_alert_background))
                    for i in range(len(bpy.data.images)):
                        if bpy.data.images[i].name == bpy.data.images[this].name:
                            return bpy.data.images[i]
                texture = gpu.texture.from_image(get_img_name())
                blender_version = bpy.app.version
                if blender_version >= (4, 0, 0):
                    shader = gpu.shader.from_builtin('IMAGE')
                else: 
                    shader = gpu.shader.from_builtin('2D_IMAGE')
                batch = gpu_extras.batch.batch_for_shader(
                    shader, 'TRI_FAN',
                    {
                        "pos": coords,
                        "texCoord": ((0, 0), (1, 0), (1, 1), (0, 1)),
                    },
                )
                shader.bind()
                gpu.state.blend_set('ALPHA')
                shader.uniform_sampler("image", texture)
                batch.draw(shader)
            else:
                quads = [[tuple((1.0, 1.0)), tuple((find_biggest_area_by_type(bpy.context.screen, 'NODE_EDITOR').width, 1.0)), tuple((1.0, find_biggest_area_by_type(bpy.context.screen, 'NODE_EDITOR').height)), tuple((find_biggest_area_by_type(bpy.context.screen, 'NODE_EDITOR').width, find_biggest_area_by_type(bpy.context.screen, 'NODE_EDITOR').height))]]
                vertices = []
                indices = []
                for i_1A51A, quad in enumerate(quads):
                    vertices.extend(quad)
                    indices.extend([(i_1A51A * 4, i_1A51A * 4 + 1, i_1A51A * 4 + 2), (i_1A51A * 4 + 2, i_1A51A * 4 + 1, i_1A51A * 4 + 3)])
                shader = gpu.shader.from_builtin('UNIFORM_COLOR')
                batch = gpu_extras.batch.batch_for_shader(shader, 'TRIS', {"pos": tuple(vertices)}, indices=tuple(indices))
                shader.bind()
                shader.uniform_float("color", bpy.context.preferences.addons['savepolice'].preferences.sna_alert_background_color)
                gpu.state.blend_set('ALPHA')
                batch.draw(shader)
        if bpy.context.preferences.addons['savepolice'].preferences.sna_alert_use_image:
            if bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence:
                if bpy.context.preferences.addons['savepolice'].preferences.sna_siren_custom:
                    if os.path.isdir(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory)):
                        directory = bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory)

                        def get_sequence_length(directory):
                            if not directory or not os.path.exists(directory):  # Check if the directory is empty or does not exist
                                return 0
                            try:
                                files = [f for f in os.listdir(directory) if f.endswith('.png')]
                                return min(len(files), 101)
                            except Exception as e:
                                print(f"An error occurred while getting the sequence length: {e}")
                                return 0
                        if directory:
                            sequence_length = get_sequence_length(directory)
                            start_frame_value = g_draw_alert_image_node_editor['sna_frame']
                            start_frame = max(0, min(100, start_frame_value))
                            end_frame_value = g_draw_alert_image_node_editor['sna_custom_frame_length']
                            end_frame = max(0, min(100, end_frame_value))
                            start_frame = min(start_frame, end_frame)
                            bl = bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location
                            coords = ((bl[0], bl[1]), (bl[0] + bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[0], bl[1]), (bl[0] + 
                            bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[0], bl[1] + bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[1]), (bl[0], bl[1] + 
                            bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[1]))

                            def get_image_from_directory(dial_value, directory):
                                files = [f for f in os.listdir(directory) if f.endswith('.png')]
                                files.sort()
                                sequence_length = min(get_sequence_length(directory), 101)
                                if 0 <= dial_value < sequence_length:
                                    image_path = os.path.join(directory, files[dial_value])
                                    bpy.data.images.load(filepath=image_path, check_existing=True)
                                    return bpy.data.images[os.path.basename(image_path)]
                                else:
                                    return None
                            dial_value = g_draw_alert_image_node_editor['sna_frame']
                            image = get_image_from_directory(dial_value, directory)
                            if image is not None:
                                texture = gpu.texture.from_image(image)
                                blender_version = bpy.app.version
                                if blender_version >= (4, 0, 0):
                                    shader = gpu.shader.from_builtin('IMAGE')
                                else: 
                                    shader = gpu.shader.from_builtin('2D_IMAGE')
                                batch = gpu_extras.batch.batch_for_shader(
                                    shader, 'TRI_FAN',
                                    {
                                        'pos': coords,
                                        'texCoord': ((0, 0), (1, 0), (1, 1), (0, 1)),
                                    },
                                )
                                shader.bind()
                                gpu.state.blend_set('ALPHA')
                                shader.uniform_sampler('image', texture)
                                batch.draw(shader)
                else:
                    directory = os.path.join(os.path.dirname(__file__), 'assets', 'Becon Composites 256 x 256')

                    def get_sequence_length(directory):
                        if not directory or not os.path.exists(directory):  # Check if the directory is empty or does not exist
                            return 0
                        try:
                            files = [f for f in os.listdir(directory) if f.endswith('.png')]
                            return min(len(files), 101)
                        except Exception as e:
                            print(f"An error occurred while getting the sequence length: {e}")
                            return 0
                    if directory:
                        sequence_length = get_sequence_length(directory)
                        start_frame_value = g_draw_alert_image_node_editor['sna_frame']
                        start_frame = max(0, min(100, start_frame_value))
                        end_frame_value = 22
                        end_frame = max(0, min(100, end_frame_value))
                        start_frame = min(start_frame, end_frame)
                        bl = bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location
                        coords = ((bl[0], bl[1]), (bl[0] + bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[0], bl[1]), (bl[0] + 
                        bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[0], bl[1] + bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[1]), (bl[0], bl[1] + 
                        bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[1]))

                        def get_image_from_directory(dial_value, directory):
                            files = [f for f in os.listdir(directory) if f.endswith('.png')]
                            files.sort()
                            sequence_length = min(get_sequence_length(directory), 101)
                            if 0 <= dial_value < sequence_length:
                                image_path = os.path.join(directory, files[dial_value])
                                bpy.data.images.load(filepath=image_path, check_existing=True)
                                return bpy.data.images[os.path.basename(image_path)]
                            else:
                                return None
                        dial_value = g_draw_alert_image_node_editor['sna_frame']
                        image = get_image_from_directory(dial_value, directory)
                        if image is not None:
                            texture = gpu.texture.from_image(image)
                            blender_version = bpy.app.version
                            if blender_version >= (4, 0, 0):
                                shader = gpu.shader.from_builtin('IMAGE')
                            else: 
                                shader = gpu.shader.from_builtin('2D_IMAGE')
                            batch = gpu_extras.batch.batch_for_shader(
                                shader, 'TRI_FAN',
                                {
                                    'pos': coords,
                                    'texCoord': ((0, 0), (1, 0), (1, 1), (0, 1)),
                                },
                            )
                            shader.bind()
                            gpu.state.blend_set('ALPHA')
                            shader.uniform_sampler('image', texture)
                            batch.draw(shader)
            else:
                if bpy.context.preferences.addons['savepolice'].preferences.sna_siren_custom:
                    if os.path.exists(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_path)):
                        coords = (  (bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[0], bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[1])   , (bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[0]+bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[0],bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[1])  ,  (bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[0]+bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[0], bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[1]+bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[1])  ,   (bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[0], bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[1]+bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[1])   )
                        bpy.data.images.load(filepath=bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_path), check_existing=True, )

                        def get_img_name():
                            this = os.path.basename(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_path))
                            for i in range(len(bpy.data.images)):
                                if bpy.data.images[i].name == bpy.data.images[this].name:
                                    return bpy.data.images[i]
                        texture = gpu.texture.from_image(get_img_name())
                        blender_version = bpy.app.version
                        if blender_version >= (4, 0, 0):
                            shader = gpu.shader.from_builtin('IMAGE')
                        else: 
                            shader = gpu.shader.from_builtin('2D_IMAGE')
                        batch = gpu_extras.batch.batch_for_shader(
                            shader, 'TRI_FAN',
                            {
                                "pos": coords,
                                "texCoord": ((0, 0), (1, 0), (1, 1), (0, 1)),
                            },
                        )
                        shader.bind()
                        gpu.state.blend_set('ALPHA')
                        shader.uniform_sampler("image", texture)
                        batch.draw(shader)
                else:
                    coords = (  (bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[0], bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[1])   , (bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[0]+bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[0],bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[1])  ,  (bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[0]+bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[0], bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[1]+bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[1])  ,   (bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[0], bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[1]+bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[1])   )
                    bpy.data.images.load(filepath=os.path.join(os.path.dirname(__file__), 'assets', 'Siren_256x256_Render0013.png'), check_existing=True, )

                    def get_img_name():
                        this = os.path.basename(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_256x256_Render0013.png'))
                        for i in range(len(bpy.data.images)):
                            if bpy.data.images[i].name == bpy.data.images[this].name:
                                return bpy.data.images[i]
                    texture = gpu.texture.from_image(get_img_name())
                    blender_version = bpy.app.version
                    if blender_version >= (4, 0, 0):
                        shader = gpu.shader.from_builtin('IMAGE')
                    else: 
                        shader = gpu.shader.from_builtin('2D_IMAGE')
                    batch = gpu_extras.batch.batch_for_shader(
                        shader, 'TRI_FAN',
                        {
                            "pos": coords,
                            "texCoord": ((0, 0), (1, 0), (1, 1), (0, 1)),
                        },
                    )
                    shader.bind()
                    gpu.state.blend_set('ALPHA')
                    shader.uniform_sampler("image", texture)
                    batch.draw(shader)
            font_id = 0
            if bpy.context.preferences.addons['savepolice'].preferences.sna_alert_font and os.path.exists(bpy.context.preferences.addons['savepolice'].preferences.sna_alert_font):
                font_id = blf.load(bpy.context.preferences.addons['savepolice'].preferences.sna_alert_font)
            if font_id == -1:
                print("Couldn't load font!")
            else:
                x_7DEC2, y_7DEC2 = bpy.context.preferences.addons['savepolice'].preferences.sna_alert_message_location
                blf.position(font_id, x_7DEC2, y_7DEC2, 0)
                if bpy.app.version >= (3, 4, 0):
                    blf.size(font_id, bpy.context.preferences.addons['savepolice'].preferences.sna_alert_message_size)
                else:
                    blf.size(font_id, bpy.context.preferences.addons['savepolice'].preferences.sna_alert_message_size, 72)
                clr = bpy.context.preferences.addons['savepolice'].preferences.sna_alert_color
                blf.color(font_id, clr[0], clr[1], clr[2], clr[3])
                if 0:
                    blf.enable(font_id, blf.WORD_WRAP)
                    blf.word_wrap(font_id, 0)
                if 0.0:
                    blf.enable(font_id, blf.ROTATION)
                    blf.rotation(font_id, 0.0)
                blf.enable(font_id, blf.WORD_WRAP)
                blf.draw(font_id, bpy.context.preferences.addons['savepolice'].preferences.sna_alert_message)
                blf.disable(font_id, blf.ROTATION)
                blf.disable(font_id, blf.WORD_WRAP)


def sna_fn_draw_siren_end_2CF21():
    bpy.context.scene.sna_save_police_animation_active = False
    g_draw_alert_image_node_editor['sna_stop'] = True
    if handler_AAAFB:
        bpy.types.SpaceNodeEditor.draw_handler_remove(handler_AAAFB[0], 'WINDOW')
        handler_AAAFB.pop(0)
        for a in bpy.context.screen.areas: a.tag_redraw()


def sna_fn_draw_siren_start_00FEB():
    g_draw_alert_image_node_editor['sna_frame'] = 0
    g_draw_alert_image_node_editor['sna_custom_frame_length'] = 0
    g_draw_alert_image_node_editor['sna_stop'] = False
    bpy.context.scene.sna_save_police_animation_active = True
    handler_AAAFB.append(bpy.types.SpaceNodeEditor.draw_handler_add(sna_fn_modal_drawing_node_editor_BA36C, (), 'WINDOW', 'POST_PIXEL'))
    for a in bpy.context.screen.areas: a.tag_redraw()
    if bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence:

        def delayed_EAB06():
            if bpy.context.preferences.addons['savepolice'].preferences.sna_siren_custom:
                if os.path.isdir(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory)):
                    if (len([os.path.join(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory), f) for f in os.listdir(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory)) if os.path.isfile(os.path.join(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory), f))]) > 0):
                        g_draw_alert_image_node_editor['sna_custom_frame_length'] = len([os.path.join(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory), f) for f in os.listdir(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory)) if os.path.isfile(os.path.join(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory), f))])
                    else:
                        g_draw_alert_image_node_editor['sna_custom_frame_length'] = 0
                else:
                    g_draw_alert_image_node_editor['sna_custom_frame_length'] = 0
            g_draw_alert_image_node_editor['sna_frame'] += 1
            if (g_draw_alert_image_node_editor['sna_frame'] >= (g_draw_alert_image_node_editor['sna_custom_frame_length'] if bpy.context.preferences.addons['savepolice'].preferences.sna_siren_custom else 22)):
                g_draw_alert_image_node_editor['sna_frame'] = 0
            if g_draw_alert_image_node_editor['sna_stop']:
                return None
            return bpy.context.preferences.addons['savepolice'].preferences.sna_siren_interval
        bpy.app.timers.register(delayed_EAB06, first_interval=0.0)


class SNA_OT_Save_Police_Preview_Alert_Image_558A3(bpy.types.Operator):
    bl_idname = "sna.save_police_preview_alert_image_558a3"
    bl_label = "Save Police Preview Alert Image"
    bl_description = "Preview the Alert Message"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('Image is active wait until it is inactive')
        return not bpy.context.scene.sna_save_police_animation_active

    def execute(self, context):
        if (not bpy.context.scene.sna_save_police_animation_active):
            if (bool(find_areas_of_type(bpy.context.screen, 'VIEW_3D')) and bpy.context.preferences.addons['savepolice'].preferences.sna_alert_3d_viewport):
                sna_fn_draw_siren_start_FE25B()
            if (bool(find_areas_of_type(bpy.context.screen, 'NODE_EDITOR')) and bpy.context.preferences.addons['savepolice'].preferences.sna_alert_node_editors):
                sna_fn_draw_siren_start_00FEB()
            if (bool(find_areas_of_type(bpy.context.screen, 'IMAGE_EDITOR')) and bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_editor):
                sna_fn_draw_siren_start_68E9D()
            if (bool(find_areas_of_type(bpy.context.screen, 'SEQUENCE_EDITOR')) and bpy.context.preferences.addons['savepolice'].preferences.sna_alert_video_sequencer):
                sna_fn_draw_siren_start_279D8()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Save_Police_End_Alert_Image_Preview_7A41B(bpy.types.Operator):
    bl_idname = "sna.save_police_end_alert_image_preview_7a41b"
    bl_label = "Save Police End Alert Image Preview"
    bl_description = "Preview the Alert Message"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('Image is active wait until it is inactive')
        return not (not bpy.context.scene.sna_save_police_animation_active)

    def execute(self, context):
        sna_fn_draw_siren_end_5EC29()
        sna_fn_draw_siren_end_2CF21()
        sna_fn_draw_siren_end_8EADA()
        sna_fn_draw_siren_end_CC28D()
        sna_fn_removed_unused_images_A2907()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_fn_modal_drawing_vse_F7409():
    if bool(find_areas_of_type(bpy.context.screen, 'SEQUENCE_EDITOR')):
        if bpy.context.preferences.addons['savepolice'].preferences.sna_alert_use_background:
            if (os.path.exists(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_alert_background)) and bpy.context.preferences.addons['savepolice'].preferences.sna_alert_custom_background):
                coords = (  ((1.0, 1.0)[0], (1.0, 1.0)[1])   , ((1.0, 1.0)[0]+find_biggest_area_by_type(bpy.context.screen, 'SEQUENCE_EDITOR').width,(1.0, 1.0)[1])  ,  ((1.0, 1.0)[0]+find_biggest_area_by_type(bpy.context.screen, 'SEQUENCE_EDITOR').width, (1.0, 1.0)[1]+find_biggest_area_by_type(bpy.context.screen, 'SEQUENCE_EDITOR').height)  ,   ((1.0, 1.0)[0], (1.0, 1.0)[1]+find_biggest_area_by_type(bpy.context.screen, 'SEQUENCE_EDITOR').height)   )
                bpy.data.images.load(filepath=bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_alert_background), check_existing=True, )

                def get_img_name():
                    this = os.path.basename(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_alert_background))
                    for i in range(len(bpy.data.images)):
                        if bpy.data.images[i].name == bpy.data.images[this].name:
                            return bpy.data.images[i]
                texture = gpu.texture.from_image(get_img_name())
                blender_version = bpy.app.version
                if blender_version >= (4, 0, 0):
                    shader = gpu.shader.from_builtin('IMAGE')
                else: 
                    shader = gpu.shader.from_builtin('2D_IMAGE')
                batch = gpu_extras.batch.batch_for_shader(
                    shader, 'TRI_FAN',
                    {
                        "pos": coords,
                        "texCoord": ((0, 0), (1, 0), (1, 1), (0, 1)),
                    },
                )
                shader.bind()
                gpu.state.blend_set('ALPHA')
                shader.uniform_sampler("image", texture)
                batch.draw(shader)
            else:
                quads = [[tuple((1.0, 1.0)), tuple((find_biggest_area_by_type(bpy.context.screen, 'SEQUENCE_EDITOR').width, 1.0)), tuple((1.0, find_biggest_area_by_type(bpy.context.screen, 'SEQUENCE_EDITOR').height)), tuple((find_biggest_area_by_type(bpy.context.screen, 'SEQUENCE_EDITOR').width, find_biggest_area_by_type(bpy.context.screen, 'SEQUENCE_EDITOR').height))]]
                vertices = []
                indices = []
                for i_91289, quad in enumerate(quads):
                    vertices.extend(quad)
                    indices.extend([(i_91289 * 4, i_91289 * 4 + 1, i_91289 * 4 + 2), (i_91289 * 4 + 2, i_91289 * 4 + 1, i_91289 * 4 + 3)])
                shader = gpu.shader.from_builtin('UNIFORM_COLOR')
                batch = gpu_extras.batch.batch_for_shader(shader, 'TRIS', {"pos": tuple(vertices)}, indices=tuple(indices))
                shader.bind()
                shader.uniform_float("color", bpy.context.preferences.addons['savepolice'].preferences.sna_alert_background_color)
                gpu.state.blend_set('ALPHA')
                batch.draw(shader)
        if bpy.context.preferences.addons['savepolice'].preferences.sna_alert_use_image:
            if bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence:
                if bpy.context.preferences.addons['savepolice'].preferences.sna_siren_custom:
                    if os.path.isdir(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory)):
                        directory = bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory)

                        def get_sequence_length(directory):
                            if not directory or not os.path.exists(directory):  # Check if the directory is empty or does not exist
                                return 0
                            try:
                                files = [f for f in os.listdir(directory) if f.endswith('.png')]
                                return min(len(files), 101)
                            except Exception as e:
                                print(f"An error occurred while getting the sequence length: {e}")
                                return 0
                        if directory:
                            sequence_length = get_sequence_length(directory)
                            start_frame_value = g_draw_alert_image_vse_editor['sna_frame']
                            start_frame = max(0, min(100, start_frame_value))
                            end_frame_value = g_draw_alert_image_vse_editor['sna_custom_frame_length']
                            end_frame = max(0, min(100, end_frame_value))
                            start_frame = min(start_frame, end_frame)
                            bl = bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location
                            coords = ((bl[0], bl[1]), (bl[0] + bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[0], bl[1]), (bl[0] + 
                            bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[0], bl[1] + bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[1]), (bl[0], bl[1] + 
                            bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[1]))

                            def get_image_from_directory(dial_value, directory):
                                files = [f for f in os.listdir(directory) if f.endswith('.png')]
                                files.sort()
                                sequence_length = min(get_sequence_length(directory), 101)
                                if 0 <= dial_value < sequence_length:
                                    image_path = os.path.join(directory, files[dial_value])
                                    bpy.data.images.load(filepath=image_path, check_existing=True)
                                    return bpy.data.images[os.path.basename(image_path)]
                                else:
                                    return None
                            dial_value = g_draw_alert_image_vse_editor['sna_frame']
                            image = get_image_from_directory(dial_value, directory)
                            if image is not None:
                                texture = gpu.texture.from_image(image)
                                blender_version = bpy.app.version
                                if blender_version >= (4, 0, 0):
                                    shader = gpu.shader.from_builtin('IMAGE')
                                else: 
                                    shader = gpu.shader.from_builtin('2D_IMAGE')
                                batch = gpu_extras.batch.batch_for_shader(
                                    shader, 'TRI_FAN',
                                    {
                                        'pos': coords,
                                        'texCoord': ((0, 0), (1, 0), (1, 1), (0, 1)),
                                    },
                                )
                                shader.bind()
                                gpu.state.blend_set('ALPHA')
                                shader.uniform_sampler('image', texture)
                                batch.draw(shader)
                else:
                    directory = os.path.join(os.path.dirname(__file__), 'assets', 'Becon Composites 256 x 256')

                    def get_sequence_length(directory):
                        if not directory or not os.path.exists(directory):  # Check if the directory is empty or does not exist
                            return 0
                        try:
                            files = [f for f in os.listdir(directory) if f.endswith('.png')]
                            return min(len(files), 101)
                        except Exception as e:
                            print(f"An error occurred while getting the sequence length: {e}")
                            return 0
                    if directory:
                        sequence_length = get_sequence_length(directory)
                        start_frame_value = g_draw_alert_image_vse_editor['sna_frame']
                        start_frame = max(0, min(100, start_frame_value))
                        end_frame_value = 22
                        end_frame = max(0, min(100, end_frame_value))
                        start_frame = min(start_frame, end_frame)
                        bl = bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location
                        coords = ((bl[0], bl[1]), (bl[0] + bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[0], bl[1]), (bl[0] + 
                        bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[0], bl[1] + bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[1]), (bl[0], bl[1] + 
                        bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[1]))

                        def get_image_from_directory(dial_value, directory):
                            files = [f for f in os.listdir(directory) if f.endswith('.png')]
                            files.sort()
                            sequence_length = min(get_sequence_length(directory), 101)
                            if 0 <= dial_value < sequence_length:
                                image_path = os.path.join(directory, files[dial_value])
                                bpy.data.images.load(filepath=image_path, check_existing=True)
                                return bpy.data.images[os.path.basename(image_path)]
                            else:
                                return None
                        dial_value = g_draw_alert_image_vse_editor['sna_frame']
                        image = get_image_from_directory(dial_value, directory)
                        if image is not None:
                            texture = gpu.texture.from_image(image)
                            blender_version = bpy.app.version
                            if blender_version >= (4, 0, 0):
                                shader = gpu.shader.from_builtin('IMAGE')
                            else: 
                                shader = gpu.shader.from_builtin('2D_IMAGE')
                            batch = gpu_extras.batch.batch_for_shader(
                                shader, 'TRI_FAN',
                                {
                                    'pos': coords,
                                    'texCoord': ((0, 0), (1, 0), (1, 1), (0, 1)),
                                },
                            )
                            shader.bind()
                            gpu.state.blend_set('ALPHA')
                            shader.uniform_sampler('image', texture)
                            batch.draw(shader)
            else:
                if bpy.context.preferences.addons['savepolice'].preferences.sna_siren_custom:
                    if os.path.exists(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_path)):
                        coords = (  (bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[0], bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[1])   , (bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[0]+bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[0],bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[1])  ,  (bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[0]+bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[0], bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[1]+bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[1])  ,   (bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[0], bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[1]+bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[1])   )
                        bpy.data.images.load(filepath=bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_path), check_existing=True, )

                        def get_img_name():
                            this = os.path.basename(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_path))
                            for i in range(len(bpy.data.images)):
                                if bpy.data.images[i].name == bpy.data.images[this].name:
                                    return bpy.data.images[i]
                        texture = gpu.texture.from_image(get_img_name())
                        blender_version = bpy.app.version
                        if blender_version >= (4, 0, 0):
                            shader = gpu.shader.from_builtin('IMAGE')
                        else: 
                            shader = gpu.shader.from_builtin('2D_IMAGE')
                        batch = gpu_extras.batch.batch_for_shader(
                            shader, 'TRI_FAN',
                            {
                                "pos": coords,
                                "texCoord": ((0, 0), (1, 0), (1, 1), (0, 1)),
                            },
                        )
                        shader.bind()
                        gpu.state.blend_set('ALPHA')
                        shader.uniform_sampler("image", texture)
                        batch.draw(shader)
                else:
                    coords = (  (bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[0], bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[1])   , (bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[0]+bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[0],bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[1])  ,  (bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[0]+bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[0], bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[1]+bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[1])  ,   (bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[0], bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_location[1]+bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_size[1])   )
                    bpy.data.images.load(filepath=os.path.join(os.path.dirname(__file__), 'assets', 'Siren_256x256_Render0013.png'), check_existing=True, )

                    def get_img_name():
                        this = os.path.basename(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_256x256_Render0013.png'))
                        for i in range(len(bpy.data.images)):
                            if bpy.data.images[i].name == bpy.data.images[this].name:
                                return bpy.data.images[i]
                    texture = gpu.texture.from_image(get_img_name())
                    blender_version = bpy.app.version
                    if blender_version >= (4, 0, 0):
                        shader = gpu.shader.from_builtin('IMAGE')
                    else: 
                        shader = gpu.shader.from_builtin('2D_IMAGE')
                    batch = gpu_extras.batch.batch_for_shader(
                        shader, 'TRI_FAN',
                        {
                            "pos": coords,
                            "texCoord": ((0, 0), (1, 0), (1, 1), (0, 1)),
                        },
                    )
                    shader.bind()
                    gpu.state.blend_set('ALPHA')
                    shader.uniform_sampler("image", texture)
                    batch.draw(shader)
            font_id = 0
            if bpy.context.preferences.addons['savepolice'].preferences.sna_alert_font and os.path.exists(bpy.context.preferences.addons['savepolice'].preferences.sna_alert_font):
                font_id = blf.load(bpy.context.preferences.addons['savepolice'].preferences.sna_alert_font)
            if font_id == -1:
                print("Couldn't load font!")
            else:
                x_096BF, y_096BF = bpy.context.preferences.addons['savepolice'].preferences.sna_alert_message_location
                blf.position(font_id, x_096BF, y_096BF, 0)
                if bpy.app.version >= (3, 4, 0):
                    blf.size(font_id, bpy.context.preferences.addons['savepolice'].preferences.sna_alert_message_size)
                else:
                    blf.size(font_id, bpy.context.preferences.addons['savepolice'].preferences.sna_alert_message_size, 72)
                clr = bpy.context.preferences.addons['savepolice'].preferences.sna_alert_color
                blf.color(font_id, clr[0], clr[1], clr[2], clr[3])
                if 0:
                    blf.enable(font_id, blf.WORD_WRAP)
                    blf.word_wrap(font_id, 0)
                if 0.0:
                    blf.enable(font_id, blf.ROTATION)
                    blf.rotation(font_id, 0.0)
                blf.enable(font_id, blf.WORD_WRAP)
                blf.draw(font_id, bpy.context.preferences.addons['savepolice'].preferences.sna_alert_message)
                blf.disable(font_id, blf.ROTATION)
                blf.disable(font_id, blf.WORD_WRAP)


def sna_fn_draw_siren_end_CC28D():
    bpy.context.scene.sna_save_police_animation_active = False
    g_draw_alert_image_vse_editor['sna_stop'] = True
    if handler_CB41D:
        bpy.types.SpaceSequenceEditor.draw_handler_remove(handler_CB41D[0], 'WINDOW')
        handler_CB41D.pop(0)
        for a in bpy.context.screen.areas: a.tag_redraw()


def sna_fn_draw_siren_start_279D8():
    g_draw_alert_image_vse_editor['sna_frame'] = 0
    g_draw_alert_image_vse_editor['sna_custom_frame_length'] = 0
    g_draw_alert_image_vse_editor['sna_stop'] = False
    bpy.context.scene.sna_save_police_animation_active = True
    handler_CB41D.append(bpy.types.SpaceSequenceEditor.draw_handler_add(sna_fn_modal_drawing_vse_F7409, (), 'WINDOW', 'POST_PIXEL'))
    for a in bpy.context.screen.areas: a.tag_redraw()
    if bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence:

        def delayed_8C706():
            if bpy.context.preferences.addons['savepolice'].preferences.sna_siren_custom:
                if os.path.isdir(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory)):
                    if (len([os.path.join(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory), f) for f in os.listdir(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory)) if os.path.isfile(os.path.join(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory), f))]) > 0):
                        g_draw_alert_image_vse_editor['sna_custom_frame_length'] = len([os.path.join(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory), f) for f in os.listdir(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory)) if os.path.isfile(os.path.join(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory), f))])
                    else:
                        g_draw_alert_image_vse_editor['sna_custom_frame_length'] = 0
                else:
                    g_draw_alert_image_vse_editor['sna_custom_frame_length'] = 0
            g_draw_alert_image_vse_editor['sna_frame'] += 1
            if (g_draw_alert_image_vse_editor['sna_frame'] >= (g_draw_alert_image_vse_editor['sna_custom_frame_length'] if bpy.context.preferences.addons['savepolice'].preferences.sna_siren_custom else 22)):
                g_draw_alert_image_vse_editor['sna_frame'] = 0
            if g_draw_alert_image_vse_editor['sna_stop']:
                return None
            return bpy.context.preferences.addons['savepolice'].preferences.sna_siren_interval
        bpy.app.timers.register(delayed_8C706, first_interval=0.0)


def sna_fn_removed_unused_images_A2907():
    if os.path.exists(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_path)):
        if (property_exists("bpy.data.images", globals(), locals()) and os.path.basename(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_path)) in bpy.data.images):
            if (0 == bpy.data.images[os.path.basename(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_path))].users):
                bpy.data.images.remove(image=bpy.data.images[os.path.basename(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_path))], do_unlink=True, do_id_user=True, do_ui_user=True, )
    if os.path.exists(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory)):
        if [os.path.join(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory), f) for f in os.listdir(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory)) if os.path.isfile(os.path.join(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory), f))]:
            for i_BCF06 in range(len([os.path.join(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory), f) for f in os.listdir(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory)) if os.path.isfile(os.path.join(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory), f))])):
                if os.path.exists([os.path.join(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory), f) for f in os.listdir(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory)) if os.path.isfile(os.path.join(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory), f))][i_BCF06]):
                    if (property_exists("bpy.data.images", globals(), locals()) and os.path.basename([os.path.join(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory), f) for f in os.listdir(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory)) if os.path.isfile(os.path.join(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory), f))][i_BCF06]) in bpy.data.images):
                        if (0 == bpy.data.images[os.path.basename([os.path.join(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory), f) for f in os.listdir(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory)) if os.path.isfile(os.path.join(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory), f))][i_BCF06])].users):
                            bpy.data.images.remove(image=bpy.data.images[os.path.basename([os.path.join(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory), f) for f in os.listdir(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory)) if os.path.isfile(os.path.join(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence_directory), f))][i_BCF06])], do_unlink=True, do_id_user=True, do_ui_user=True, )
    if os.path.exists(bpy.path.abspath(os.path.join(os.path.dirname(__file__), 'assets', 'Becon Composites 256 x 256'))):
        if [os.path.join(bpy.path.abspath(os.path.join(os.path.dirname(__file__), 'assets', 'Becon Composites 256 x 256')), f) for f in os.listdir(bpy.path.abspath(os.path.join(os.path.dirname(__file__), 'assets', 'Becon Composites 256 x 256'))) if os.path.isfile(os.path.join(bpy.path.abspath(os.path.join(os.path.dirname(__file__), 'assets', 'Becon Composites 256 x 256')), f))]:
            for i_85208 in range(len([os.path.join(bpy.path.abspath(os.path.join(os.path.dirname(__file__), 'assets', 'Becon Composites 256 x 256')), f) for f in os.listdir(bpy.path.abspath(os.path.join(os.path.dirname(__file__), 'assets', 'Becon Composites 256 x 256'))) if os.path.isfile(os.path.join(bpy.path.abspath(os.path.join(os.path.dirname(__file__), 'assets', 'Becon Composites 256 x 256')), f))])):
                if os.path.exists([os.path.join(bpy.path.abspath(os.path.join(os.path.dirname(__file__), 'assets', 'Becon Composites 256 x 256')), f) for f in os.listdir(bpy.path.abspath(os.path.join(os.path.dirname(__file__), 'assets', 'Becon Composites 256 x 256'))) if os.path.isfile(os.path.join(bpy.path.abspath(os.path.join(os.path.dirname(__file__), 'assets', 'Becon Composites 256 x 256')), f))][i_85208]):
                    if (property_exists("bpy.data.images", globals(), locals()) and os.path.basename([os.path.join(bpy.path.abspath(os.path.join(os.path.dirname(__file__), 'assets', 'Becon Composites 256 x 256')), f) for f in os.listdir(bpy.path.abspath(os.path.join(os.path.dirname(__file__), 'assets', 'Becon Composites 256 x 256'))) if os.path.isfile(os.path.join(bpy.path.abspath(os.path.join(os.path.dirname(__file__), 'assets', 'Becon Composites 256 x 256')), f))][i_85208]) in bpy.data.images):
                        if (0 == bpy.data.images[os.path.basename([os.path.join(bpy.path.abspath(os.path.join(os.path.dirname(__file__), 'assets', 'Becon Composites 256 x 256')), f) for f in os.listdir(bpy.path.abspath(os.path.join(os.path.dirname(__file__), 'assets', 'Becon Composites 256 x 256'))) if os.path.isfile(os.path.join(bpy.path.abspath(os.path.join(os.path.dirname(__file__), 'assets', 'Becon Composites 256 x 256')), f))][i_85208])].users):
                            bpy.data.images.remove(image=bpy.data.images[os.path.basename([os.path.join(bpy.path.abspath(os.path.join(os.path.dirname(__file__), 'assets', 'Becon Composites 256 x 256')), f) for f in os.listdir(bpy.path.abspath(os.path.join(os.path.dirname(__file__), 'assets', 'Becon Composites 256 x 256'))) if os.path.isfile(os.path.join(bpy.path.abspath(os.path.join(os.path.dirname(__file__), 'assets', 'Becon Composites 256 x 256')), f))][i_85208])], do_unlink=True, do_id_user=True, do_ui_user=True, )
    if os.path.exists(bpy.path.abspath(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_256x256_Render0013.png'))):
        if (property_exists("bpy.data.images", globals(), locals()) and os.path.basename(bpy.path.abspath(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_256x256_Render0013.png'))) in bpy.data.images):
            if (0 == bpy.data.images[os.path.basename(bpy.path.abspath(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_256x256_Render0013.png')))].users):
                bpy.data.images.remove(image=bpy.data.images[os.path.basename(bpy.path.abspath(os.path.join(os.path.dirname(__file__), 'assets', 'Siren_256x256_Render0013.png')))], do_unlink=True, do_id_user=True, do_ui_user=True, )
    if os.path.exists(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_alert_background)):
        if (property_exists("bpy.data.images", globals(), locals()) and os.path.basename(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_alert_background)) in bpy.data.images):
            if (0 == bpy.data.images[os.path.basename(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_alert_background))].users):
                bpy.data.images.remove(image=bpy.data.images[os.path.basename(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_alert_background))], do_unlink=True, do_id_user=True, do_ui_user=True, )


class SNA_OT_Op_Start_Drawing_E7A6D(bpy.types.Operator):
    bl_idname = "sna.op_start_drawing_e7a6d"
    bl_label = "Op_Start_Drawing"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        handler_64666.append(bpy.types.SpaceNodeEditor.draw_handler_add(sna_function_execute_4A9EF, (os.path.join(os.path.dirname(__file__), 'assets', 'Becon Composites 256 x 256'), ), 'WINDOW', 'POST_PIXEL'))
        for a in bpy.context.screen.areas: a.tag_redraw()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Op_End_Drawing_3823D(bpy.types.Operator):
    bl_idname = "sna.op_end_drawing_3823d"
    bl_label = "Op_End_Drawing"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if handler_0B5B1:
            bpy.types.SpaceNodeEditor.draw_handler_remove(handler_0B5B1[0], 'WINDOW')
            handler_0B5B1.pop(0)
            for a in bpy.context.screen.areas: a.tag_redraw()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_function_execute_4A9EF(Asset):
    directory = Asset

    def get_sequence_length(directory):
        if not directory or not os.path.exists(directory):  # Check if the directory is empty or does not exist
            return 0
        try:
            files = [f for f in os.listdir(directory) if f.endswith('.png')]
            return min(len(files), 101)
        except Exception as e:
            print(f"An error occurred while getting the sequence length: {e}")
            return 0
    if directory:
        sequence_length = get_sequence_length(directory)
        start_frame_value = 0
        start_frame = max(0, min(100, start_frame_value))
        end_frame_value = 0
        end_frame = max(0, min(100, end_frame_value))
        start_frame = min(start_frame, end_frame)
        bl = (1.0, 1.0)
        coords = ((bl[0], bl[1]), (bl[0] + 100.0, bl[1]), (bl[0] + 
        100.0, bl[1] + 100.0), (bl[0], bl[1] + 
        100.0))

        def get_image_from_directory(dial_value, directory):
            files = [f for f in os.listdir(directory) if f.endswith('.png')]
            files.sort()
            sequence_length = min(get_sequence_length(directory), 101)
            if 0 <= dial_value < sequence_length:
                image_path = os.path.join(directory, files[dial_value])
                bpy.data.images.load(filepath=image_path, check_existing=True)
                return bpy.data.images[os.path.basename(image_path)]
            else:
                return None
        dial_value = 0
        image = get_image_from_directory(dial_value, directory)
        if image is not None:
            texture = gpu.texture.from_image(image)
            blender_version = bpy.app.version
            if blender_version >= (4, 0, 0):
                shader = gpu.shader.from_builtin('IMAGE')
            else: 
                shader = gpu.shader.from_builtin('2D_IMAGE')
            batch = gpu_extras.batch.batch_for_shader(
                shader, 'TRI_FAN',
                {
                    'pos': coords,
                    'texCoord': ((0, 0), (1, 0), (1, 1), (0, 1)),
                },
            )
            shader.bind()
            gpu.state.blend_set('ALPHA')
            shader.uniform_sampler('image', texture)
            batch.draw(shader)


def sna_add_to_filebrowser_mt_editor_menus_65F56(self, context):
    if not ((not bpy.context.preferences.addons['savepolice'].preferences.sna_alert_file_browser)):
        layout = self.layout
        layout_function = layout
        sna_ui_fn_save_police_popover_9BE6E(layout_function, )
        layout_function = layout
        sna_ui_fn_animate_icons_E6878(layout_function, )


def sna_add_to_assetbrowser_mt_editor_menus_09A7D(self, context):
    if not ((not bpy.context.preferences.addons['savepolice'].preferences.sna_alert_asset_browser)):
        layout = self.layout
        layout_function = layout
        sna_ui_fn_save_police_popover_9BE6E(layout_function, )
        layout_function = layout
        sna_ui_fn_animate_icons_E6878(layout_function, )


def sna_add_to_spreadsheet_ht_header_A1142(self, context):
    if not ((not bpy.context.preferences.addons['savepolice'].preferences.sna_alert_spreadhseet)):
        layout = self.layout
        layout_function = layout
        sna_ui_fn_save_police_popover_9BE6E(layout_function, )
        layout_function = layout
        sna_ui_fn_animate_icons_E6878(layout_function, )


def sna_fn_animate_icons_EF932():
    bpy.context.scene.sna_save_police_annoy_active = True

    def delayed_2370D():
        if (graph_scripts['sna_animation_minutes'] > bpy.context.scene.sna_animation_interval):
            graph_scripts['sna_animation_minutes'] = 1
        else:
            graph_scripts['sna_animation_minutes'] = int(graph_scripts['sna_animation_minutes'] + 1.0)
        if bpy.context and bpy.context.screen:
            for a in bpy.context.screen.areas:
                a.tag_redraw()
        if (not bpy.context.scene.sna_save_police_reminder):
            return None
        return bpy.context.scene.sna_animation_timer
    bpy.app.timers.register(delayed_2370D, first_interval=0.0)


def sna_fn_start_stop_save_police_timer_34567(Start_Timer):
    if Start_Timer:
        graph_scripts['sna_minutes'] = 0
        graph_scripts['sna_animation_minutes'] = 0
    graph_scripts['sna_timer_freq'] = int(bpy.context.preferences.addons['savepolice'].preferences.sna_interval * 60.0)
    graph_scripts['sna_timer_interval'] = bpy.context.preferences.addons['savepolice'].preferences.sna_interval
    graph_scripts['sna_timer_interval'] = 1
    start = Start_Timer
    timer_interval = bpy.context.preferences.addons['savepolice'].preferences.sna_interval
    timer_sec = 1
    timer_freq = int(bpy.context.preferences.addons['savepolice'].preferences.sna_interval * 60.0)
    if not start:
        if bpy.app.timers.is_registered(fn_save_police_timer_2):
            bpy.app.timers.unregister(fn_save_police_timer_2)
    else:
        if not bpy.app.timers.is_registered(fn_save_police_timer_2):
            bpy.app.timers.register(fn_save_police_timer_2)


def before_exit_handler_8A0D1():
    bpy.ops.sna.op_annoy_restore_theme_colors_954ce('INVOKE_DEFAULT', )
    bpy.ops.wm.save_userpref()


@persistent
def load_post_handler_0B793(dummy):
    bpy.context.scene.sna_save_police_interval = bpy.context.preferences.addons['savepolice'].preferences.sna_interval
    graph_scripts['sna_timer_freq'] = int(bpy.context.preferences.addons['savepolice'].preferences.sna_interval * 60.0)
    graph_scripts['sna_timer_interval'] = bpy.context.preferences.addons['savepolice'].preferences.sna_interval
    graph_scripts['sna_timer_interval'] = 1
    if (bpy.context.preferences.addons['savepolice'].preferences.sna_save_on_load and bpy.context.preferences.addons['savepolice'].preferences.sna_call_the_save_police):
        sna_fn_start_stop_save_police_timer_34567(False)
        if bool(bpy.data.filepath):
            pass
        else:
            bpy.ops.sna.op_save_police_saving_148e8('INVOKE_DEFAULT', )
            bpy.ops.wm.splash('INVOKE_DEFAULT', )
    if bpy.context.preferences.addons['savepolice'].preferences.sna_call_the_save_police:

        def delayed_78357():
            bpy.context.preferences.addons['savepolice'].preferences.sna_call_the_save_police = True
        bpy.app.timers.register(delayed_78357, first_interval=1.0)
        bpy.context.preferences.addons['savepolice'].preferences.sna_call_the_save_police = False
    print('🚨 Save Police: Save Startup is Active')


@persistent
def save_post_handler_70958(dummy):
    bpy.context.scene.sna_save_police_reminder = False
    if bpy.context.preferences.addons['savepolice'].preferences.sna_change_theme:
        bpy.ops.sna.op_annoy_restore_theme_colors_954ce('INVOKE_DEFAULT', )
    sna_fn_start_stop_save_police_timer_34567(False)
    if bpy.context.preferences.addons['savepolice'].preferences.sna_call_the_save_police:
        sna_fn_start_stop_save_police_timer_34567(True)
    if (bpy.context.preferences.addons['savepolice'].preferences.sna_interval != bpy.context.scene.sna_save_police_interval):
        bpy.context.scene.sna_save_police_interval = bpy.context.preferences.addons['savepolice'].preferences.sna_interval
    if bpy.context.scene.sna_save_police_animation_active:
        bpy.ops.sna.save_police_end_alert_image_preview_7a41b('INVOKE_DEFAULT', )
    sna_fn_removed_unused_images_A2907()


class SNA_OT_Op_Save_Police_Saving_148E8(bpy.types.Operator):
    bl_idname = "sna.op_save_police_saving_148e8"
    bl_label = "Op Save Police Saving"
    bl_description = "Time for a save"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if bool(bpy.data.filepath):
            print('🚨 Save Police: Attempting a file save')
            if ((len(os.path.basename(bpy.data.filepath)) > 0) and (len(bpy.context.preferences.addons['savepolice'].preferences.sna_default_save_prefix) > 0) and bpy.context.preferences.addons['savepolice'].preferences.sna_default_save_prefix in bpy.data.filepath and bpy.context.preferences.addons['savepolice'].preferences.sna_save_default_file):
                bpy.ops.wm.save_mainfile(filepath=bpy.path.abspath(os.path.join(bpy.context.preferences.addons['savepolice'].preferences.sna_default_folder,bpy.context.preferences.addons['savepolice'].preferences.sna_default_save_prefix + '_' + str(datetime.now().date().year) + '-' + str(datetime.now().date().month) + '-' + str(datetime.now().date().day) + '_' + str(datetime.now().time().hour) + '-' + str(datetime.now().time().minute) + '-' + str(datetime.now().time().second) + '.blend')))
            else:
                bpy.ops.wm.save_mainfile(filepath=bpy.data.filepath, incremental=bpy.context.preferences.addons['savepolice'].preferences.sna_incremental_saving)
                self.report({'INFO'}, message='🚨 Saved: ' + bpy.data.filepath)
        else:
            if bpy.context.preferences.addons['savepolice'].preferences.sna_save_default_file:
                print('🚨 Save Police: Attempting a default file save')
                if os.path.exists(bpy.context.preferences.addons['savepolice'].preferences.sna_default_folder):
                    bpy.ops.wm.save_mainfile(filepath=bpy.path.abspath(os.path.join(bpy.context.preferences.addons['savepolice'].preferences.sna_default_folder,bpy.context.preferences.addons['savepolice'].preferences.sna_default_save_prefix + '_' + str(datetime.now().date().year) + '-' + str(datetime.now().date().month) + '-' + str(datetime.now().date().day) + '_' + str(datetime.now().time().hour) + '-' + str(datetime.now().time().minute) + '-' + str(datetime.now().time().second) + '.blend')))
                    self.report({'INFO'}, message='🚨 Saved: ' + bpy.data.filepath)
            else:
                bpy.ops.wm.save_mainfile('INVOKE_DEFAULT', )
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Op_Annoy_Store_And_Swap_Theme_Colors_C1B7F(bpy.types.Operator):
    bl_idname = "sna.op_annoy_store_and_swap_theme_colors_c1b7f"
    bl_label = "Op Annoy Store and Swap Theme Colors"
    bl_description = "Store and swap theme colors to remind to save"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if (not bpy.context.scene.sna_save_police_theme_active):
            bpy.context.scene.sna_theme_color__menu = bpy.context.preferences.themes['Default'].user_interface.wcol_menu.text
            bpy.context.preferences.themes['Default'].user_interface.wcol_menu.text = bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_annoy_color
            bpy.context.scene.sna_theme_color__list_item = bpy.context.preferences.themes['Default'].user_interface.wcol_list_item.text
            bpy.context.preferences.themes['Default'].user_interface.wcol_list_item.text = bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_annoy_color
            bpy.context.scene.sna_theme_color__list_item_sel = bpy.context.preferences.themes['Default'].user_interface.wcol_list_item.text_sel
            bpy.context.preferences.themes['Default'].user_interface.wcol_list_item.text_sel = bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_annoy_color
            bpy.context.scene.sna_theme_color__number = bpy.context.preferences.themes['Default'].user_interface.wcol_num.text
            bpy.context.preferences.themes['Default'].user_interface.wcol_num.text = bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_annoy_color
            bpy.context.scene.sna_theme_color__option = bpy.context.preferences.themes['Default'].user_interface.wcol_option.text
            bpy.context.preferences.themes['Default'].user_interface.wcol_option.text = bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_annoy_color
            bpy.context.scene.sna_theme_color__pulldown = bpy.context.preferences.themes['Default'].user_interface.wcol_pulldown.text
            bpy.context.preferences.themes['Default'].user_interface.wcol_pulldown.text = bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_annoy_color
            bpy.context.scene.sna_theme_color__regular = bpy.context.preferences.themes['Default'].user_interface.wcol_regular.text
            bpy.context.preferences.themes['Default'].user_interface.wcol_regular.text = bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_annoy_color
            bpy.context.scene.sna_theme_color__tab = bpy.context.preferences.themes['Default'].user_interface.wcol_tab.text
            bpy.context.preferences.themes['Default'].user_interface.wcol_tab.text = bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_annoy_color
            bpy.context.scene.sna_theme_color__tab_sel = bpy.context.preferences.themes['Default'].user_interface.wcol_tab.text_sel
            bpy.context.preferences.themes['Default'].user_interface.wcol_tab.text_sel = bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_annoy_color
            bpy.context.scene.sna_theme_color__radio_buttons = bpy.context.preferences.themes['Default'].user_interface.wcol_radio.text
            bpy.context.preferences.themes['Default'].user_interface.wcol_radio.text = bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_annoy_color
            bpy.context.scene.sna_theme_color__text = bpy.context.preferences.themes['Default'].user_interface.wcol_text.text
            bpy.context.preferences.themes['Default'].user_interface.wcol_text.text = bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_annoy_color
            bpy.context.scene.sna_theme_color__tool = bpy.context.preferences.themes['Default'].user_interface.wcol_tool.text
            bpy.context.preferences.themes['Default'].user_interface.wcol_tool.text = bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_annoy_color
            bpy.context.scene.sna_theme_color__toolbar_item_selected = bpy.context.preferences.themes['Default'].user_interface.wcol_toolbar_item.inner_sel
            bpy.context.preferences.themes['Default'].user_interface.wcol_toolbar_item.inner_sel = (bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_annoy_color[0], bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_annoy_color[1], bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_annoy_color[2], 1.0)
            bpy.context.scene.sna_theme_color__value_slider = bpy.context.preferences.themes['Default'].user_interface.wcol_numslider.text
            bpy.context.preferences.themes['Default'].user_interface.wcol_numslider.text = bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_annoy_color
            bpy.context.scene.sna_theme_color__toggle_text = bpy.context.preferences.themes['Default'].user_interface.wcol_toggle.text
            bpy.context.preferences.themes['Default'].user_interface.wcol_toggle.text = bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_annoy_color
            bpy.context.scene.sna_theme_color__toggle_text_sel = bpy.context.preferences.themes['Default'].user_interface.wcol_toggle.text_sel
            bpy.context.preferences.themes['Default'].user_interface.wcol_toggle.text_sel = bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_annoy_color
            bpy.context.scene.sna_theme_color__scroll_bar_item = bpy.context.preferences.themes['Default'].user_interface.wcol_scroll.item
            bpy.context.preferences.themes['Default'].user_interface.wcol_scroll.item = (bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_annoy_color[0], bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_annoy_color[1], bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_annoy_color[2], 1.0)
            bpy.context.scene.sna_theme_color__regular_sel = bpy.context.preferences.themes['Default'].user_interface.wcol_regular.text_sel
            bpy.context.preferences.themes['Default'].user_interface.wcol_regular.text_sel = bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_annoy_color
            bpy.context.scene.sna_theme_color__radio_buttons_sel = bpy.context.preferences.themes['Default'].user_interface.wcol_radio.text_sel
            bpy.context.preferences.themes['Default'].user_interface.wcol_radio.text_sel = bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_annoy_color
            bpy.context.scene.sna_theme_color__option_text_sel = bpy.context.preferences.themes['Default'].user_interface.wcol_option.text_sel
            bpy.context.preferences.themes['Default'].user_interface.wcol_option.text_sel = bpy.context.preferences.addons['savepolice'].preferences.sna_save_police_annoy_color
            bpy.context.scene.sna_save_police_theme_active = True
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Op_Annoy_Restore_Theme_Colors_954Ce(bpy.types.Operator):
    bl_idname = "sna.op_annoy_restore_theme_colors_954ce"
    bl_label = "Op Annoy Restore Theme Colors"
    bl_description = "Restore theme colors after annoying is complete"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if bpy.context.scene.sna_save_police_theme_active:
            bpy.context.preferences.themes['Default'].user_interface.wcol_menu.text = bpy.context.scene.sna_theme_color__menu
            bpy.context.preferences.themes['Default'].user_interface.wcol_list_item.text = bpy.context.scene.sna_theme_color__list_item
            bpy.context.preferences.themes['Default'].user_interface.wcol_list_item.text_sel = bpy.context.scene.sna_theme_color__list_item_sel
            bpy.context.preferences.themes['Default'].user_interface.wcol_num.text = bpy.context.scene.sna_theme_color__number
            bpy.context.preferences.themes['Default'].user_interface.wcol_option.text = bpy.context.scene.sna_theme_color__option
            bpy.context.preferences.themes['Default'].user_interface.wcol_pulldown.text = bpy.context.scene.sna_theme_color__pulldown
            bpy.context.preferences.themes['Default'].user_interface.wcol_regular.text = bpy.context.scene.sna_theme_color__regular
            bpy.context.preferences.themes['Default'].user_interface.wcol_tab.text = bpy.context.scene.sna_theme_color__tab
            bpy.context.preferences.themes['Default'].user_interface.wcol_tab.text_sel = bpy.context.scene.sna_theme_color__tab_sel
            bpy.context.preferences.themes['Default'].user_interface.wcol_radio.text = bpy.context.scene.sna_theme_color__radio_buttons
            bpy.context.preferences.themes['Default'].user_interface.wcol_text.text = bpy.context.scene.sna_theme_color__text
            bpy.context.preferences.themes['Default'].user_interface.wcol_tool.text = bpy.context.scene.sna_theme_color__tool
            bpy.context.preferences.themes['Default'].user_interface.wcol_toolbar_item.inner_sel = bpy.context.scene.sna_theme_color__toolbar_item_selected
            bpy.context.preferences.themes['Default'].user_interface.wcol_numslider.text = bpy.context.scene.sna_theme_color__value_slider
            bpy.context.preferences.themes['Default'].user_interface.wcol_toggle.text = bpy.context.scene.sna_theme_color__toggle_text
            bpy.context.preferences.themes['Default'].user_interface.wcol_toggle.text_sel = bpy.context.scene.sna_theme_color__toggle_text_sel
            bpy.context.preferences.themes['Default'].user_interface.wcol_scroll.item = bpy.context.scene.sna_theme_color__scroll_bar_item
            bpy.context.preferences.themes['Default'].user_interface.wcol_regular.text_sel = bpy.context.scene.sna_theme_color__regular_sel
            bpy.context.preferences.themes['Default'].user_interface.wcol_radio.text_sel = bpy.context.scene.sna_theme_color__radio_buttons_sel
            bpy.context.preferences.themes['Default'].user_interface.wcol_option.text_sel = bpy.context.scene.sna_theme_color__option_text_sel
            bpy.context.scene.sna_save_police_theme_active = False
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Op_Preview_Theme_Change_2Ea4A(bpy.types.Operator):
    bl_idname = "sna.op_preview_theme_change_2ea4a"
    bl_label = "Op Preview Theme Change"
    bl_description = "See a 3 second preview of your alert via theme changing color"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('Theme is already active. Preview is disabled')
        return not bpy.context.scene.sna_save_police_theme_active

    def execute(self, context):

        def delayed_CDF5B():
            bpy.ops.sna.op_annoy_restore_theme_colors_954ce('INVOKE_DEFAULT', )
        bpy.app.timers.register(delayed_CDF5B, first_interval=3.0)
        bpy.ops.sna.op_annoy_store_and_swap_theme_colors_c1b7f('INVOKE_DEFAULT', )
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def fn_save_police_timer_2():
    #print("Running")
    if bpy.data.is_dirty:
        if graph_scripts['sna_minutes'] >= ((graph_scripts['sna_timer_interval']*graph_scripts['sna_timer_freq'])):
            graph_scripts['sna_minutes'] = 1
            bpy.context.scene.sna_save_police_reminder = True
            if bpy.context and bpy.context.screen:
                for a in bpy.context.screen.areas:
                    a.tag_redraw()
        else:
            graph_scripts['sna_minutes'] += 1
        #print(f"Save Police timer is running for {graph_scripts['sna_minutes']} seconds")
    else:
        if bpy.context.scene.sna_save_police_reminder:
            bpy.context.scene.sna_save_police_reminder = False
    return graph_scripts['sna_timer_sec']


def sna_add_to_view3d_mt_editor_menus_AA738(self, context):
    if not ((not bpy.context.preferences.addons['savepolice'].preferences.sna_alert_3d_viewport)):
        layout = self.layout
        layout_function = layout
        sna_ui_fn_save_police_popover_9BE6E(layout_function, )
        layout_function = layout
        sna_ui_fn_animate_icons_E6878(layout_function, )


def sna_ui_fn_animate_icons_E6878(layout_function, ):
    pass


def sna_add_to_console_mt_editor_menus_C1336(self, context):
    if not ((not bpy.context.preferences.addons['savepolice'].preferences.sna_alert_console)):
        layout = self.layout
        layout_function = layout
        sna_ui_fn_save_police_popover_9BE6E(layout_function, )
        layout_function = layout
        sna_ui_fn_animate_icons_E6878(layout_function, )


def sna_add_to_info_mt_editor_menus_E1CA9(self, context):
    if not ((not bpy.context.preferences.addons['savepolice'].preferences.sna_alert_info_log)):
        layout = self.layout
        layout_function = layout
        sna_ui_fn_save_police_popover_9BE6E(layout_function, )
        layout_function = layout
        sna_ui_fn_animate_icons_E6878(layout_function, )


def sna_add_to_text_mt_editor_menus_E4C6F(self, context):
    if not ((not bpy.context.preferences.addons['savepolice'].preferences.sna_alert_text_editor)):
        layout = self.layout
        layout_function = layout
        sna_ui_fn_save_police_popover_9BE6E(layout_function, )
        layout_function = layout
        sna_ui_fn_animate_icons_E6878(layout_function, )


def sna_add_to_topbar_mt_editor_menus_AEEC7(self, context):
    if not ((not bpy.context.preferences.addons['savepolice'].preferences.sna_alert_header)):
        layout = self.layout
        layout.label(text=((((str(int(graph_scripts['sna_timer_freq'] - graph_scripts['sna_minutes'])) + ' sec' if (round(float(float(graph_scripts['sna_timer_freq'] - graph_scripts['sna_minutes']) / 60.0), abs(1)) < 1.0) else str(round(float(float(graph_scripts['sna_timer_freq'] - graph_scripts['sna_minutes']) / 60.0), abs(1))) + ' min ') if bpy.context.preferences.addons['savepolice'].preferences.sna_call_the_save_police else '') if (not bpy.context.scene.sna_save_police_reminder) else '') if bpy.data.is_dirty else ''), icon_value=((((((load_preview_icon(r'Z:\my-bucket-one\Dev\Personal\Save Police\Icons\Becon Composites 256 x 256\Siren_256x256_Render0023.png') if (graph_scripts['sna_animation_minutes'] > 4) else load_preview_icon(r'Z:\my-bucket-one\Dev\Personal\Save Police\Icons\Becon Composites 256 x 256\Siren_256x256_Render0019.png')) if (graph_scripts['sna_animation_minutes'] > 3) else load_preview_icon(r'Z:\my-bucket-one\Dev\Personal\Save Police\Icons\Becon Composites 256 x 256\Siren_256x256_Render0013.png')) if (graph_scripts['sna_animation_minutes'] > 2) else load_preview_icon(r'Z:\my-bucket-one\Dev\Personal\Save Police\Icons\Becon Composites 256 x 256\Siren_256x256_Render0007.png')) if (graph_scripts['sna_animation_minutes'] > 1) else load_preview_icon(r'Z:\my-bucket-one\Dev\Personal\Save Police\Icons\Becon Composites 256 x 256\Siren_256x256_Render0001.png')) if bpy.context.preferences.addons['savepolice'].preferences.sna_animate else load_preview_icon(r'Z:\my-bucket-one\Dev\Personal\Save Police\Icons\Becon Composites 256 x 256\Siren_256x256_Render0013.png')) if bpy.context.scene.sna_save_police_reminder else ((load_preview_icon(r'Z:\my-bucket-one\Dev\Personal\Save Police\Icons\Siren_blue_256x256.png') if bpy.context.preferences.addons['savepolice'].preferences.sna_call_the_save_police else load_preview_icon(r'Z:\my-bucket-one\Dev\Personal\Save Police\Icons\Siren_grey_256x256.png')) if bpy.data.is_dirty else load_preview_icon(r'Z:\my-bucket-one\Dev\Personal\Save Police\Icons\Siren_green_256x256.png'))))
        if (bpy.context.scene.sna_save_police_reminder and bpy.context.preferences.addons['savepolice'].preferences.sna_annoyance_only):
            layout.label(text='', icon_value=load_preview_icon(r'Z:\my-bucket-one\Dev\Personal\Save Police\Icons\Save Icons\S.png'))
            layout.label(text='', icon_value=load_preview_icon(r'Z:\my-bucket-one\Dev\Personal\Save Police\Icons\Save Icons\A.png'))
            layout.label(text='', icon_value=load_preview_icon(r'Z:\my-bucket-one\Dev\Personal\Save Police\Icons\Save Icons\V.png'))
            layout.label(text='', icon_value=load_preview_icon(r'Z:\my-bucket-one\Dev\Personal\Save Police\Icons\Save Icons\E.png'))


def sna_add_to_statusbar_ht_header_1E57C(self, context):
    if not ((not bpy.context.preferences.addons['savepolice'].preferences.sna_alert_footer)):
        layout = self.layout
        layout.label(text=((((str(int(graph_scripts['sna_timer_freq'] - graph_scripts['sna_minutes'])) + ' sec' if (round(float(float(graph_scripts['sna_timer_freq'] - graph_scripts['sna_minutes']) / 60.0), abs(1)) < 1.0) else str(round(float(float(graph_scripts['sna_timer_freq'] - graph_scripts['sna_minutes']) / 60.0), abs(1))) + ' min ') if bpy.context.preferences.addons['savepolice'].preferences.sna_call_the_save_police else '') if (not bpy.context.scene.sna_save_police_reminder) else '') if bpy.data.is_dirty else ''), icon_value=((((((load_preview_icon(r'Z:\my-bucket-one\Dev\Personal\Save Police\Icons\Becon Composites 256 x 256\Siren_256x256_Render0023.png') if (graph_scripts['sna_animation_minutes'] > 4) else load_preview_icon(r'Z:\my-bucket-one\Dev\Personal\Save Police\Icons\Becon Composites 256 x 256\Siren_256x256_Render0019.png')) if (graph_scripts['sna_animation_minutes'] > 3) else load_preview_icon(r'Z:\my-bucket-one\Dev\Personal\Save Police\Icons\Becon Composites 256 x 256\Siren_256x256_Render0013.png')) if (graph_scripts['sna_animation_minutes'] > 2) else load_preview_icon(r'Z:\my-bucket-one\Dev\Personal\Save Police\Icons\Becon Composites 256 x 256\Siren_256x256_Render0007.png')) if (graph_scripts['sna_animation_minutes'] > 1) else load_preview_icon(r'Z:\my-bucket-one\Dev\Personal\Save Police\Icons\Becon Composites 256 x 256\Siren_256x256_Render0001.png')) if bpy.context.preferences.addons['savepolice'].preferences.sna_animate else load_preview_icon(r'Z:\my-bucket-one\Dev\Personal\Save Police\Icons\Becon Composites 256 x 256\Siren_256x256_Render0013.png')) if bpy.context.scene.sna_save_police_reminder else ((load_preview_icon(r'Z:\my-bucket-one\Dev\Personal\Save Police\Icons\Siren_blue_256x256.png') if bpy.context.preferences.addons['savepolice'].preferences.sna_call_the_save_police else load_preview_icon(r'Z:\my-bucket-one\Dev\Personal\Save Police\Icons\Siren_grey_256x256.png')) if bpy.data.is_dirty else load_preview_icon(r'Z:\my-bucket-one\Dev\Personal\Save Police\Icons\Siren_green_256x256.png'))))
        if (bpy.context.scene.sna_save_police_reminder and bpy.context.preferences.addons['savepolice'].preferences.sna_annoyance_only):
            layout.label(text='', icon_value=load_preview_icon(r'Z:\my-bucket-one\Dev\Personal\Save Police\Icons\Save Icons\S.png'))
            layout.label(text='', icon_value=load_preview_icon(r'Z:\my-bucket-one\Dev\Personal\Save Police\Icons\Save Icons\A.png'))
            layout.label(text='', icon_value=load_preview_icon(r'Z:\my-bucket-one\Dev\Personal\Save Police\Icons\Save Icons\V.png'))
            layout.label(text='', icon_value=load_preview_icon(r'Z:\my-bucket-one\Dev\Personal\Save Police\Icons\Save Icons\E.png'))


def sna_add_to_node_mt_editor_menus_34B94(self, context):
    if not ((not bpy.context.preferences.addons['savepolice'].preferences.sna_alert_node_editors)):
        layout = self.layout
        layout_function = layout
        sna_ui_fn_save_police_popover_9BE6E(layout_function, )
        layout_function = layout
        sna_ui_fn_animate_icons_E6878(layout_function, )


def sna_add_to_outliner_ht_header_EE18D(self, context):
    if not ((not bpy.context.preferences.addons['savepolice'].preferences.sna_alert_outliner)):
        layout = self.layout
        layout_function = layout
        sna_ui_fn_save_police_popover_9BE6E(layout_function, )
        layout_function = layout
        sna_ui_fn_animate_icons_E6878(layout_function, )


def sna_add_to_userpref_mt_editor_menus_2BEF4(self, context):
    if not ((not bpy.context.preferences.addons['savepolice'].preferences.sna_alert_preferences)):
        layout = self.layout
        layout_function = layout
        sna_ui_fn_save_police_popover_9BE6E(layout_function, )
        layout_function = layout
        sna_ui_fn_animate_icons_E6878(layout_function, )


def sna_add_to_properties_ht_header_F3B48(self, context):
    if not ((not bpy.context.preferences.addons['savepolice'].preferences.sna_alert_properties)):
        layout = self.layout
        layout_function = layout
        sna_ui_fn_save_police_popover_9BE6E(layout_function, )
        layout_function = layout
        sna_ui_fn_animate_icons_E6878(layout_function, )


def sna_ui_fn_save_police_popover_9BE6E(layout_function, ):
    layout_function.popover('SNA_PT_SAVE_POLICE_POPOVER_EB431', text=((((str(int(graph_scripts['sna_timer_freq'] - graph_scripts['sna_minutes'])) + ' sec' if (round(float(float(graph_scripts['sna_timer_freq'] - graph_scripts['sna_minutes']) / 60.0), abs(1)) < 1.0) else str(round(float(float(graph_scripts['sna_timer_freq'] - graph_scripts['sna_minutes']) / 60.0), abs(1))) + ' min ') if bpy.context.preferences.addons['savepolice'].preferences.sna_call_the_save_police else '') if (not bpy.context.scene.sna_save_police_reminder) else '') if bpy.data.is_dirty else ''), icon_value=((((((load_preview_icon(r'Z:\my-bucket-one\Dev\Personal\Save Police\Icons\Becon Composites 256 x 256\Siren_256x256_Render0023.png') if (graph_scripts['sna_animation_minutes'] > 4) else load_preview_icon(r'Z:\my-bucket-one\Dev\Personal\Save Police\Icons\Becon Composites 256 x 256\Siren_256x256_Render0019.png')) if (graph_scripts['sna_animation_minutes'] > 3) else load_preview_icon(r'Z:\my-bucket-one\Dev\Personal\Save Police\Icons\Becon Composites 256 x 256\Siren_256x256_Render0013.png')) if (graph_scripts['sna_animation_minutes'] > 2) else load_preview_icon(r'Z:\my-bucket-one\Dev\Personal\Save Police\Icons\Becon Composites 256 x 256\Siren_256x256_Render0007.png')) if (graph_scripts['sna_animation_minutes'] > 1) else load_preview_icon(r'Z:\my-bucket-one\Dev\Personal\Save Police\Icons\Becon Composites 256 x 256\Siren_256x256_Render0001.png')) if bpy.context.preferences.addons['savepolice'].preferences.sna_animate else load_preview_icon(r'Z:\my-bucket-one\Dev\Personal\Save Police\Icons\Becon Composites 256 x 256\Siren_256x256_Render0013.png')) if bpy.context.scene.sna_save_police_reminder else ((load_preview_icon(r'Z:\my-bucket-one\Dev\Personal\Save Police\Icons\Siren_blue_256x256.png') if bpy.context.preferences.addons['savepolice'].preferences.sna_call_the_save_police else load_preview_icon(r'Z:\my-bucket-one\Dev\Personal\Save Police\Icons\Siren_grey_256x256.png')) if bpy.data.is_dirty else load_preview_icon(r'Z:\my-bucket-one\Dev\Personal\Save Police\Icons\Siren_green_256x256.png'))))


def sna_ui_fn_save_police_B9591(layout_function, ):
    col_6ADD0 = layout_function.column(heading='', align=True)
    col_6ADD0.alert = False
    col_6ADD0.enabled = True
    col_6ADD0.active = True
    col_6ADD0.use_property_split = True
    col_6ADD0.use_property_decorate = False
    col_6ADD0.scale_x = 1.0
    col_6ADD0.scale_y = 1.0
    col_6ADD0.alignment = 'Expand'.upper()
    col_6ADD0.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
    col_6ADD0.label(text='General', icon_value=0)
    col_6ADD0.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_call_the_save_police', text='Activate', icon_value=0, emboss=True, toggle=True)
    col_E9CE3 = col_6ADD0.column(heading='', align=True)
    col_E9CE3.alert = False
    col_E9CE3.enabled = (not bpy.context.preferences.addons['savepolice'].preferences.sna_call_the_save_police)
    col_E9CE3.active = True
    col_E9CE3.use_property_split = True
    col_E9CE3.use_property_decorate = False
    col_E9CE3.scale_x = 1.0
    col_E9CE3.scale_y = 1.0
    col_E9CE3.alignment = 'Expand'.upper()
    col_E9CE3.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
    col_E9CE3.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_interval', text='Timer (min)', icon_value=0, emboss=True, toggle=True)
    col_6ADD0.separator(factor=2.0)
    col_6ADD0.label(text='Defaults (Worry-Free Save)', icon_value=0)
    col_6ADD0.label(text='Prefix_YYYY-MM-DD_HH_MM_SS', icon_value=0)
    col_1F900 = col_6ADD0.column(heading='', align=True)
    col_1F900.alert = False
    col_1F900.enabled = True
    col_1F900.active = (not bpy.context.preferences.addons['savepolice'].preferences.sna_annoyance_only)
    col_1F900.use_property_split = True
    col_1F900.use_property_decorate = False
    col_1F900.scale_x = 1.0
    col_1F900.scale_y = 1.0
    col_1F900.alignment = 'Expand'.upper()
    col_1F900.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
    col_1F900.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_save_default_file', text='Default Save', icon_value=_icons['Save Icon.png'].icon_id, emboss=True, toggle=True)
    col_6ADD0.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_save_on_load', text='Startup Save', icon_value=15, emboss=True, toggle=True)
    col_B91E4 = col_6ADD0.column(heading='', align=True)
    col_B91E4.alert = False
    col_B91E4.enabled = True
    col_B91E4.active = bpy.context.preferences.addons['savepolice'].preferences.sna_save_default_file
    col_B91E4.use_property_split = True
    col_B91E4.use_property_decorate = False
    col_B91E4.scale_x = 1.0
    col_B91E4.scale_y = 1.0
    col_B91E4.alignment = 'Expand'.upper()
    col_B91E4.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
    col_B91E4.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_default_folder', text='Default Folder', icon_value=0, emboss=True)
    col_B91E4.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_default_save_prefix', text='Prefix', icon_value=0, emboss=True)
    if (os.path.exists(bpy.path.abspath(bpy.context.preferences.addons['savepolice'].preferences.sna_default_folder)) and bpy.context.preferences.addons['savepolice'].preferences.sna_save_default_file):
        row_1400C = col_B91E4.row(heading='', align=False)
        row_1400C.alert = False
        row_1400C.enabled = True
        row_1400C.active = True
        row_1400C.use_property_split = True
        row_1400C.use_property_decorate = False
        row_1400C.scale_x = 1.0
        row_1400C.scale_y = 1.0
        row_1400C.alignment = 'Right'.upper()
        row_1400C.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_1400C.label(text=bpy.path.abspath(os.path.join(bpy.context.preferences.addons['savepolice'].preferences.sna_default_folder,bpy.context.preferences.addons['savepolice'].preferences.sna_default_save_prefix + '_' + str(datetime.now().date().year) + '-' + str(datetime.now().date().month) + '-' + str(datetime.now().date().day) + '_' + str(datetime.now().time().hour) + '-' + str(datetime.now().time().minute) + '-' + str(datetime.now().time().second) + '.blend')), icon_value=0)
    col_B91E4.separator(factor=2.0)
    col_6ADD0.label(text='Advanced', icon_value=0)
    col_6ADD0.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_incremental_saving', text='Increment Saves', icon_value=695, emboss=True, toggle=True)
    col_6ADD0.separator(factor=2.0)


def sna_ui_fn_save_police_alerts_props_C4E09(layout_function, ):
    col_ACFCB = layout_function.column(heading='', align=True)
    col_ACFCB.alert = False
    col_ACFCB.enabled = True
    col_ACFCB.active = True
    col_ACFCB.use_property_split = True
    col_ACFCB.use_property_decorate = False
    col_ACFCB.scale_x = 1.0
    col_ACFCB.scale_y = 1.0
    col_ACFCB.alignment = 'Expand'.upper()
    col_ACFCB.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
    col_ACFCB.label(text='Alerts Only (No Save)', icon_value=0)
    col_ACFCB.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_annoyance_only', text='Alert Instead', icon_value=((((((load_preview_icon(r'Z:\my-bucket-one\Dev\Personal\Save Police\Icons\Becon Composites 256 x 256\Siren_256x256_Render0023.png') if (graph_scripts['sna_animation_minutes'] > 4) else load_preview_icon(r'Z:\my-bucket-one\Dev\Personal\Save Police\Icons\Becon Composites 256 x 256\Siren_256x256_Render0019.png')) if (graph_scripts['sna_animation_minutes'] > 3) else load_preview_icon(r'Z:\my-bucket-one\Dev\Personal\Save Police\Icons\Becon Composites 256 x 256\Siren_256x256_Render0013.png')) if (graph_scripts['sna_animation_minutes'] > 2) else load_preview_icon(r'Z:\my-bucket-one\Dev\Personal\Save Police\Icons\Becon Composites 256 x 256\Siren_256x256_Render0007.png')) if (graph_scripts['sna_animation_minutes'] > 1) else load_preview_icon(r'Z:\my-bucket-one\Dev\Personal\Save Police\Icons\Becon Composites 256 x 256\Siren_256x256_Render0001.png')) if bpy.context.preferences.addons['savepolice'].preferences.sna_animate else load_preview_icon(r'Z:\my-bucket-one\Dev\Personal\Save Police\Icons\Becon Composites 256 x 256\Siren_256x256_Render0013.png')) if bpy.context.scene.sna_save_police_reminder else ((load_preview_icon(r'Z:\my-bucket-one\Dev\Personal\Save Police\Icons\Siren_blue_256x256.png') if bpy.context.preferences.addons['savepolice'].preferences.sna_call_the_save_police else load_preview_icon(r'Z:\my-bucket-one\Dev\Personal\Save Police\Icons\Siren_grey_256x256.png')) if bpy.data.is_dirty else load_preview_icon(r'Z:\my-bucket-one\Dev\Personal\Save Police\Icons\Siren_green_256x256.png'))), emboss=True, toggle=True)
    if bpy.context.preferences.addons['savepolice'].preferences.sna_annoyance_only:
        col_ACFCB.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_animate', text='Animate', icon_value=191, emboss=True)
        col_ACFCB.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_change_theme', text='Alert Theme', icon_value=54, emboss=True)
        col_ACFCB.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_save_police_annoy_color', text='Theme Color', icon_value=0, emboss=True)
        split_37453 = col_ACFCB.split(factor=0.5, align=True)
        split_37453.alert = False
        split_37453.enabled = True
        split_37453.active = True
        split_37453.use_property_split = False
        split_37453.use_property_decorate = False
        split_37453.scale_x = 1.0
        split_37453.scale_y = 1.0
        split_37453.alignment = 'Expand'.upper()
        if not True: split_37453.operator_context = "EXEC_DEFAULT"
        split_37453.label(text='', icon_value=0)
        op = split_37453.operator('sna.op_preview_theme_change_2ea4a', text='Preview Theme', icon_value=503, emboss=True, depress=False)


def sna_ui_fn_save_police_alert_image_78119(layout_function, ):
    col_17647 = layout_function.column(heading='', align=True)
    col_17647.alert = False
    col_17647.enabled = True
    col_17647.active = True
    col_17647.use_property_split = True
    col_17647.use_property_decorate = False
    col_17647.scale_x = 1.0
    col_17647.scale_y = 1.0
    col_17647.alignment = 'Expand'.upper()
    col_17647.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
    col_17647.separator(factor=2.0)
    col_17647.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_alert_use_image', text='Use Image', icon_value=764, emboss=True)
    col_17647.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_siren_image_sequence', text='Image Sequence', icon_value=697, emboss=True)
    if bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence:
        col_17647.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_siren_interval', text='Interval (sec)', icon_value=0, emboss=True)
    col_17647.separator(factor=2.0)
    col_17647.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_siren_custom', text=('Custom Sequence' if bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence else 'Custom Image'), icon_value=(111 if bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence else 696), emboss=True)
    if bpy.context.preferences.addons['savepolice'].preferences.sna_siren_custom:
        if bpy.context.preferences.addons['savepolice'].preferences.sna_siren_image_sequence:
            col_17647.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_siren_image_sequence_directory', text='Sequence Folder', icon_value=0, emboss=True)
        else:
            col_17647.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_siren_image_path', text='Image Path', icon_value=0, emboss=True)
    col_17647.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_siren_image_size', text='Image Size', icon_value=0, emboss=True)
    col_17647.separator(factor=1.0)
    col_17647.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_alert_image_location', text='Image Location', icon_value=0, emboss=True)
    col_17647.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_alert_message', text='Message', icon_value=0, emboss=True)
    col_17647.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_alert_font', text='Font', icon_value=0, emboss=True)
    col_17647.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_alert_color', text='Message Color', icon_value=0, emboss=True)
    col_17647.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_alert_message_size', text='Message Size', icon_value=0, emboss=True)
    col_17647.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_alert_message_location', text='Message Location', icon_value=0, emboss=True)
    col_17647.separator(factor=1.0)
    col_17647.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_alert_use_background', text='Use Background', icon_value=27, emboss=True, toggle=True)
    col_17647.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_alert_custom_background', text='Custom Background', icon_value=362, emboss=True, toggle=True)
    if bpy.context.preferences.addons['savepolice'].preferences.sna_alert_custom_background:
        col_17647.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_alert_background', text='Background', icon_value=0, emboss=True)
    else:
        col_17647.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_alert_background_color', text='Background Color', icon_value=0, emboss=True)
    col_17647.separator(factor=1.0)
    split_DC8D8 = col_17647.split(factor=0.5, align=True)
    split_DC8D8.alert = False
    split_DC8D8.enabled = True
    split_DC8D8.active = True
    split_DC8D8.use_property_split = False
    split_DC8D8.use_property_decorate = False
    split_DC8D8.scale_x = 1.0
    split_DC8D8.scale_y = 1.0
    split_DC8D8.alignment = 'Expand'.upper()
    if not True: split_DC8D8.operator_context = "EXEC_DEFAULT"
    split_DC8D8.label(text='', icon_value=0)
    if bpy.context.scene.sna_save_police_animation_active:
        op = split_DC8D8.operator('sna.save_police_end_alert_image_preview_7a41b', text='End Preview', icon_value=3, emboss=True, depress=False)
    else:
        op = split_DC8D8.operator('sna.save_police_preview_alert_image_558a3', text='Preview Alert Image', icon_value=503, emboss=True, depress=False)


def sna_ui_fn_save_police_alerts_menus_8BC5F(layout_function, alerts):
    if alerts:
        col_AFDCC = layout_function.column(heading='', align=True)
        col_AFDCC.alert = False
        col_AFDCC.enabled = True
        col_AFDCC.active = True
        col_AFDCC.use_property_split = True
        col_AFDCC.use_property_decorate = False
        col_AFDCC.scale_x = 1.0
        col_AFDCC.scale_y = 1.0
        col_AFDCC.alignment = 'Expand'.upper()
        col_AFDCC.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_AFDCC.label(text='Toggle UI Items', icon_value=0)
        col_AFDCC.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_alert_header', text='Header', icon_value=49, emboss=True)
        col_AFDCC.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_alert_footer', text='Footer', icon_value=50, emboss=True)
        col_AFDCC.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_alert_3d_viewport', text='3D Viewport', icon_value=104, emboss=True)
        col_AFDCC.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_alert_image_editor', text='Image Editor', icon_value=109, emboss=True)
        col_AFDCC.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_alert_node_editors', text='Node Editors', icon_value=24, emboss=True)
        col_AFDCC.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_alert_video_sequencer', text='VSE', icon_value=111, emboss=True)
        col_AFDCC.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_alert_movie_clip_editor', text='Movie Clip', icon_value=123, emboss=True)
        col_AFDCC.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_alert_dopesheet', text='Dope Sheet', icon_value=115, emboss=True)
        col_AFDCC.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_alert_timeline', text='Timeline', icon_value=118, emboss=True)
        col_AFDCC.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_alert_nla', text='NLA Editor', icon_value=116, emboss=True)
        col_AFDCC.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_alert_text_editor', text='Text Editor', icon_value=112, emboss=True)
        col_AFDCC.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_alert_console', text='Console', icon_value=121, emboss=True)
        col_AFDCC.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_alert_info_log', text='Info Log', icon_value=110, emboss=True)
        col_AFDCC.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_alert_outliner', text='Outliner', icon_value=106, emboss=True)
        col_AFDCC.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_alert_properties', text='Properties', icon_value=107, emboss=True)
        col_AFDCC.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_alert_file_browser', text='File Browser', icon_value=108, emboss=True)
        col_AFDCC.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_alert_asset_browser', text='Asset Browser', icon_value=124, emboss=True)
        col_AFDCC.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_alert_spreadhseet', text='Spreadsheet', icon_value=113, emboss=True)
        col_AFDCC.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_alert_preferences', text='Preferences', icon_value=117, emboss=True)


class SNA_PT_SAVE_POLICE_B6A8F(bpy.types.Panel):
    bl_label = 'Save Police'
    bl_idname = 'SNA_PT_SAVE_POLICE_B6A8F'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Tool'
    bl_order = 0
    bl_options = {'DEFAULT_CLOSED'}
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout
        layout.prop(bpy.context.preferences.addons['savepolice'].preferences, 'sna_call_the_save_police', text='', icon_value=((((((load_preview_icon(r'Z:\my-bucket-one\Dev\Personal\Save Police\Icons\Becon Composites 256 x 256\Siren_256x256_Render0023.png') if (graph_scripts['sna_animation_minutes'] > 4) else load_preview_icon(r'Z:\my-bucket-one\Dev\Personal\Save Police\Icons\Becon Composites 256 x 256\Siren_256x256_Render0019.png')) if (graph_scripts['sna_animation_minutes'] > 3) else load_preview_icon(r'Z:\my-bucket-one\Dev\Personal\Save Police\Icons\Becon Composites 256 x 256\Siren_256x256_Render0013.png')) if (graph_scripts['sna_animation_minutes'] > 2) else load_preview_icon(r'Z:\my-bucket-one\Dev\Personal\Save Police\Icons\Becon Composites 256 x 256\Siren_256x256_Render0007.png')) if (graph_scripts['sna_animation_minutes'] > 1) else load_preview_icon(r'Z:\my-bucket-one\Dev\Personal\Save Police\Icons\Becon Composites 256 x 256\Siren_256x256_Render0001.png')) if bpy.context.preferences.addons['savepolice'].preferences.sna_animate else load_preview_icon(r'Z:\my-bucket-one\Dev\Personal\Save Police\Icons\Becon Composites 256 x 256\Siren_256x256_Render0013.png')) if bpy.context.scene.sna_save_police_reminder else ((load_preview_icon(r'Z:\my-bucket-one\Dev\Personal\Save Police\Icons\Siren_blue_256x256.png') if bpy.context.preferences.addons['savepolice'].preferences.sna_call_the_save_police else load_preview_icon(r'Z:\my-bucket-one\Dev\Personal\Save Police\Icons\Siren_grey_256x256.png')) if bpy.data.is_dirty else load_preview_icon(r'Z:\my-bucket-one\Dev\Personal\Save Police\Icons\Siren_green_256x256.png'))), emboss=False)

    def draw(self, context):
        layout = self.layout
        layout_function = layout
        sna_ui_fn_save_police_B9591(layout_function, )


class SNA_PT_SAVE_POLICE_POPOVER_EB431(bpy.types.Panel):
    bl_label = 'Save Police Popover'
    bl_idname = 'SNA_PT_SAVE_POLICE_POPOVER_EB431'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'WINDOW'
    bl_context = ''
    bl_order = 0
    bl_options = {'HIDE_HEADER'}
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout_function = layout
        sna_ui_fn_save_police_B9591(layout_function, )
        layout_function = layout
        sna_ui_fn_save_police_alerts_props_C4E09(layout_function, )
        layout_function = layout
        sna_ui_fn_save_police_alert_image_78119(layout_function, )
        layout_function = layout
        sna_ui_fn_save_police_alerts_menus_8BC5F(layout_function, True)


def sna_add_to_dopesheet_mt_editor_menus_0B6E7(self, context):
    if not (False):
        layout = self.layout
        layout_function = layout
        sna_ui_fn_save_police_popover_9BE6E(layout_function, )
        layout_function = layout
        sna_ui_fn_animate_icons_E6878(layout_function, )


def sna_add_to_time_mt_editor_menus_5F6E0(self, context):
    if not (False):
        layout = self.layout
        layout_function = layout
        sna_ui_fn_save_police_popover_9BE6E(layout_function, )
        layout_function = layout
        sna_ui_fn_animate_icons_E6878(layout_function, )


def sna_add_to_graph_mt_editor_menus_E6FC0(self, context):
    if not (False):
        layout = self.layout
        layout_function = layout
        sna_ui_fn_save_police_popover_9BE6E(layout_function, )
        layout_function = layout
        sna_ui_fn_animate_icons_E6878(layout_function, )


def sna_add_to_nla_mt_editor_menus_D6C3A(self, context):
    if not (False):
        layout = self.layout
        layout_function = layout
        sna_ui_fn_save_police_popover_9BE6E(layout_function, )
        layout_function = layout
        sna_ui_fn_animate_icons_E6878(layout_function, )


def sna_add_to_image_mt_editor_menus_2A3C9(self, context):
    if not ((not bpy.context.preferences.addons['savepolice'].preferences.sna_alert_image_editor)):
        layout = self.layout
        layout_function = layout
        sna_ui_fn_save_police_popover_9BE6E(layout_function, )
        layout_function = layout
        sna_ui_fn_animate_icons_E6878(layout_function, )


def sna_add_to_sequencer_mt_editor_menus_30710(self, context):
    if not ((not bpy.context.preferences.addons['savepolice'].preferences.sna_alert_video_sequencer)):
        layout = self.layout
        layout_function = layout
        sna_ui_fn_save_police_popover_9BE6E(layout_function, )
        layout_function = layout
        sna_ui_fn_animate_icons_E6878(layout_function, )


def sna_add_to_clip_mt_tracking_editor_menus_35868(self, context):
    if not ((not bpy.context.preferences.addons['savepolice'].preferences.sna_alert_movie_clip_editor)):
        layout = self.layout
        layout_function = layout
        sna_ui_fn_save_police_popover_9BE6E(layout_function, )
        layout_function = layout
        sna_ui_fn_animate_icons_E6878(layout_function, )


class SNA_AddonPreferences_70C5B(bpy.types.AddonPreferences):
    bl_idname = 'savepolice'
    sna_call_the_save_police: bpy.props.BoolProperty(name='Call the Save Police', description='Let the police handle the saving from here on out', default=False, update=sna_update_sna_call_the_save_police_8EE76)
    sna_annoyance_only: bpy.props.BoolProperty(name='Annoyance Only', description='Alert only without actually saving', default=False, update=sna_update_sna_annoyance_only_1467F)
    sna_save_police_annoy_color: bpy.props.FloatVectorProperty(name='Save Police Annoy Color', description='The annoyance color', size=3, default=(1.0, 0.11900000274181366, 0.07000000029802322), subtype='COLOR', unit='NONE', min=0.0, max=1.0, step=3, precision=6)
    sna_interval: bpy.props.IntProperty(name='Interval', description='Set the number of minutes before the save police intervene', default=10, subtype='TIME', min=1, soft_max=1440, update=sna_update_sna_interval_CA391)
    sna_save_default_file: bpy.props.BoolProperty(name='Save Default File', description='Save a default file when no file save exists', default=False)
    sna_default_folder: bpy.props.StringProperty(name='Default Folder', description='If no save file exists then auto save file here. Leave blank to disable default saving', default='', subtype='DIR_PATH', maxlen=0)
    sna_default_save_prefix: bpy.props.StringProperty(name='Default Save Prefix', description='Enter a prefix for the default save', default='SavePolice', subtype='NONE', maxlen=0)
    sna_save_on_load: bpy.props.BoolProperty(name='Save On Load', description='Save on blender startup or when loading a file', default=False)
    sna_incremental_saving: bpy.props.BoolProperty(name='Incremental Saving', description='Use incremental saving', default=False)
    sna_alert_3d_viewport: bpy.props.BoolProperty(name='Alert 3D Viewport', description='Show Alert on #D Viewport', default=True)
    sna_alert_image_editor: bpy.props.BoolProperty(name='Alert Image Editor', description='Use the Image Editor', default=False)
    sna_alert_uv_editor: bpy.props.BoolProperty(name='Alert UV Editor', description='Use the UV Editor', default=False)
    sna_alert_node_editors: bpy.props.BoolProperty(name='Alert Node Editors', description='Use Node Editors', default=False)
    sna_alert_video_sequencer: bpy.props.BoolProperty(name='Alert Video Sequencer', description='Use the Video Sequencer', default=False)
    sna_alert_movie_clip_editor: bpy.props.BoolProperty(name='Alert Movie Clip Editor', description='USe Movie Clip Editor', default=False)
    sna_alert_dopesheet: bpy.props.BoolProperty(name='Alert Dopesheet', description='Use Dopesheet Editor', default=False)
    sna_alert_timeline: bpy.props.BoolProperty(name='Alert Timeline', description='Use Timeline', default=False)
    sna_alert_nla: bpy.props.BoolProperty(name='Alert NLA', description='USe NLA Editor', default=False)
    sna_alert_text_editor: bpy.props.BoolProperty(name='Alert Text Editor', description='Use Text Editor', default=False)
    sna_alert_console: bpy.props.BoolProperty(name='Alert Console', description='USe Console', default=False)
    sna_alert_info_log: bpy.props.BoolProperty(name='Alert Info Log', description='Use Info Log', default=False)
    sna_alert_outliner: bpy.props.BoolProperty(name='Alert Outliner', description='Use Outliner', default=False)
    sna_alert_properties: bpy.props.BoolProperty(name='Alert Properties', description='Use Properties', default=False)
    sna_alert_file_browser: bpy.props.BoolProperty(name='Alert File Browser', description='Use File Browser', default=False)
    sna_alert_asset_browser: bpy.props.BoolProperty(name='Alert Asset Browser', description='USe Asset Browser', default=False)
    sna_alert_spreadhseet: bpy.props.BoolProperty(name='Alert Spreadhseet', description='USe Spreadsheet', default=False)
    sna_alert_preferences: bpy.props.BoolProperty(name='Alert Preferences', description='Use Preferences', default=False)
    sna_change_theme: bpy.props.BoolProperty(name='Change Theme', description='Change Theme Colors on Alert', default=False, update=sna_update_sna_change_theme_993B2)
    sna_animate: bpy.props.BoolProperty(name='Animate', description='Animate the Alert', default=False)
    sna_alert_footer: bpy.props.BoolProperty(name='Alert Footer', description='Use Footer', default=False)
    sna_alert_header: bpy.props.BoolProperty(name='Alert Header', description='Use Header', default=False)
    sna_siren_image_active: bpy.props.BoolProperty(name='Siren Image Active', description='Siren Image Alert is Active', default=False)
    sna_siren_image_sequence: bpy.props.BoolProperty(name='Siren Image Sequence', description='Use Siren Image Sequence', default=False)
    sna_siren_image_sequence_directory: bpy.props.StringProperty(name='Siren Image Sequence Directory', description='Siren Image Directory', default='', subtype='DIR_PATH', maxlen=0)
    sna_siren_image_path: bpy.props.StringProperty(name='Siren Image Path', description='Siren Image Path', default='', subtype='FILE_PATH', maxlen=0)
    sna_siren_custom: bpy.props.BoolProperty(name='Siren Custom', description='Use Custom Image or Sequence', default=False)
    sna_siren_image_size: bpy.props.FloatVectorProperty(name='Siren Image Size', description='', size=2, default=(100.0, 100.0), subtype='XYZ', unit='NONE', min=10.0, soft_min=10.0, soft_max=1024.0, step=10, precision=0)
    sna_siren_interval: bpy.props.FloatProperty(name='Siren Interval', description='', default=0.25, subtype='TIME', unit='TIME', min=0.10000000149011612, max=60.0, soft_max=2.0, step=5, precision=2)
    sna_alert_message: bpy.props.StringProperty(name='Alert Message', description='Enter a custom message for your alert', default='Save', subtype='NONE', maxlen=0)
    sna_alert_font: bpy.props.StringProperty(name='Alert Font', description='Leave Blank for Default Font', default='', subtype='FILE_PATH', maxlen=0)
    sna_alert_color: bpy.props.FloatVectorProperty(name='Alert Color', description='Color of Alert Font', size=4, default=(0.7940999865531921, 0.7940999865531921, 0.7940999865531921, 1.0), subtype='COLOR', unit='NONE', min=0.0, max=1.0, step=1, precision=4)
    sna_alert_message_size: bpy.props.FloatProperty(name='Alert Message Size', description='Size of the Alert Text', default=32.0, subtype='NONE', unit='NONE', min=8.0, soft_max=100.0, step=1, precision=0)
    sna_alert_message_location: bpy.props.FloatVectorProperty(name='Alert Message Location', description='', size=2, default=(20.0, 20.0), subtype='XYZ', unit='NONE', min=1.0, step=1, precision=0)
    sna_alert_image_location: bpy.props.FloatVectorProperty(name='Alert Image Location', description='Location of the Image', size=2, default=(5.0, 50.0), subtype='XYZ', unit='NONE', min=1.0, step=10, precision=0)
    sna_alert_background: bpy.props.StringProperty(name='Alert Background', description='Backgorund Image', default='', subtype='FILE_PATH', maxlen=0)
    sna_alert_use_background: bpy.props.BoolProperty(name='Alert Use Background', description='Add A Background to Your Alert', default=False)
    sna_alert_custom_background: bpy.props.BoolProperty(name='Alert Custom Background', description='Use a Custom Background', default=False)
    sna_alert_background_color: bpy.props.FloatVectorProperty(name='Alert Background Color', description='Set the background color of the alert', size=4, default=(0.7491000294685364, 0.7491000294685364, 0.7491000294685364, 1.0), subtype='COLOR', unit='NONE', min=0.0, max=1.0, step=1, precision=4)
    sna_alert_use_image: bpy.props.BoolProperty(name='Alert Use Image', description='Use an Image for the Alert', default=False)

    def draw(self, context):
        if not (False):
            layout = self.layout 
            layout_function = layout
            sna_ui_fn_save_police_B9591(layout_function, )
            layout_function = layout
            sna_ui_fn_save_police_alerts_props_C4E09(layout_function, )
            layout_function = layout
            sna_ui_fn_save_police_alert_image_78119(layout_function, )
            layout_function = layout
            sna_ui_fn_save_police_alerts_menus_8BC5F(layout_function, True)


class SNA_PT_ALERTS_4DC17(bpy.types.Panel):
    bl_label = 'Alerts'
    bl_idname = 'SNA_PT_ALERTS_4DC17'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 0
    bl_parent_id = 'SNA_PT_SAVE_POLICE_B6A8F'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout_function = layout
        sna_ui_fn_save_police_alerts_props_C4E09(layout_function, )


class SNA_PT_ALERTS_UI_5B80A(bpy.types.Panel):
    bl_label = 'Alerts UI'
    bl_idname = 'SNA_PT_ALERTS_UI_5B80A'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 2
    bl_options = {'DEFAULT_CLOSED'}
    bl_parent_id = 'SNA_PT_ALERTS_4DC17'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout_function = layout
        sna_ui_fn_save_police_alerts_menus_8BC5F(layout_function, True)


class SNA_PT_ALERT_IMAGE_E7051(bpy.types.Panel):
    bl_label = 'Alert Image'
    bl_idname = 'SNA_PT_ALERT_IMAGE_E7051'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 1
    bl_options = {'DEFAULT_CLOSED'}
    bl_parent_id = 'SNA_PT_ALERTS_4DC17'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout_function = layout
        sna_ui_fn_save_police_alert_image_78119(layout_function, )


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.types.Scene.sna_save_police_animation_active = bpy.props.BoolProperty(name='Save Police Animation Active', description='The Image Animation is Active', default=False)
    bpy.types.Scene.sna_save_police_theme_active = bpy.props.BoolProperty(name='Save Police Theme Active', description='Theme color changing is active', default=False)
    bpy.types.Scene.sna_save_police_interval = bpy.props.IntProperty(name='Save Police Interval', description='Number of minutes for Save Police', default=10, subtype='NONE', min=1, max=1440, update=sna_update_sna_save_police_interval_8D7BA)
    bpy.types.Scene.sna_save_police_script_interval = bpy.props.IntProperty(name='Save Police Script Interval', description='', default=60, subtype='NONE', min=1, soft_min=1440)
    bpy.types.Scene.sna_save_police_timer_freq = bpy.props.IntProperty(name='Save Police Timer Freq', description='How many seconds per minute', default=60, subtype='NONE', min=1, soft_max=60)
    bpy.types.Scene.sna_save_police_reminder = bpy.props.BoolProperty(name='Save Police Reminder', description='Reminder after save police timer completes', default=False, update=sna_update_sna_save_police_reminder_9D6ED)
    bpy.types.Scene.sna_save_police_annoy_active = bpy.props.BoolProperty(name='Save Police Annoy Active', description='Annoyance is now active', default=False)
    bpy.types.Scene.sna_animation_timer = bpy.props.FloatProperty(name='Animation Timer', description='How fast do you want the animation to run in seconds', default=0.25, subtype='NONE', unit='NONE', min=0.009999999776482582, soft_max=1.0, step=3, precision=6)
    bpy.types.Scene.sna_animation_interval = bpy.props.IntProperty(name='Animation Interval', description='Number of animations', default=5, subtype='NONE', min=1, soft_max=23)
    bpy.types.Scene.sna_theme_color__menu = bpy.props.FloatVectorProperty(name='Theme Color - Menu', description='Change Menu text color', size=3, default=(0.749019980430603, 0.749019980430603, 0.749019980430603), subtype='COLOR', unit='NONE', min=0.0, max=1.0, step=3, precision=6)
    bpy.types.Scene.sna_theme_color__list_item = bpy.props.FloatVectorProperty(name='Theme Color - List Item', description='Change List Item text color (collection items)', size=3, default=(0.749019980430603, 0.749019980430603, 0.749019980430603), subtype='COLOR', unit='NONE', min=0.0, max=1.0, step=3, precision=6)
    bpy.types.Scene.sna_theme_color__list_item_sel = bpy.props.FloatVectorProperty(name='Theme Color - List Item Sel', description='Change List Item text color (collection items)', size=3, default=(0.749019980430603, 0.749019980430603, 0.749019980430603), subtype='COLOR', unit='NONE', min=0.0, max=1.0, step=3, precision=6)
    bpy.types.Scene.sna_theme_color__number = bpy.props.FloatVectorProperty(name='Theme Color - Number', description='Change Number color (all number props)', size=3, default=(0.749019980430603, 0.749019980430603, 0.749019980430603), subtype='COLOR', unit='NONE', min=0.0, max=1.0, step=3, precision=6)
    bpy.types.Scene.sna_theme_color__option = bpy.props.FloatVectorProperty(name='Theme Color - Option', description='Change Option color (checkbox)', size=3, default=(0.749019980430603, 0.749019980430603, 0.749019980430603), subtype='COLOR', unit='NONE', min=0.0, max=1.0, step=3, precision=6)
    bpy.types.Scene.sna_theme_color__pulldown = bpy.props.FloatVectorProperty(name='Theme Color - Pulldown', description='Change Pulldown color (Header Pulldowns, etc.)', size=3, default=(0.749019980430603, 0.749019980430603, 0.749019980430603), subtype='COLOR', unit='NONE', min=0.0, max=1.0, step=3, precision=6)
    bpy.types.Scene.sna_theme_color__regular = bpy.props.FloatVectorProperty(name='Theme Color - Regular', description='Change Regular color (blender icons)', size=3, default=(0.749019980430603, 0.749019980430603, 0.749019980430603), subtype='COLOR', unit='NONE', min=0.0, max=1.0, step=3, precision=6)
    bpy.types.Scene.sna_theme_color__tab = bpy.props.FloatVectorProperty(name='Theme Color - Tab', description='Change Tab color (Workspaces, etc.)', size=3, default=(0.749019980430603, 0.749019980430603, 0.749019980430603), subtype='COLOR', unit='NONE', min=0.0, max=1.0, step=3, precision=6)
    bpy.types.Scene.sna_theme_color__tab_sel = bpy.props.FloatVectorProperty(name='Theme Color - Tab Sel', description='Change Tab color (Workspaces, etc.)', size=3, default=(0.749019980430603, 0.749019980430603, 0.749019980430603), subtype='COLOR', unit='NONE', min=0.0, max=1.0, step=3, precision=6)
    bpy.types.Scene.sna_theme_color__radio_buttons = bpy.props.FloatVectorProperty(name='Theme Color - Radio Buttons', description='Change Radio Buttons color (buttons with text)', size=3, default=(0.749019980430603, 0.749019980430603, 0.749019980430603), subtype='COLOR', unit='NONE', min=0.0, max=1.0, step=3, precision=6)
    bpy.types.Scene.sna_theme_color__text = bpy.props.FloatVectorProperty(name='Theme Color - Text', description='Change Text color (string props, and search strings)', size=3, default=(0.749019980430603, 0.749019980430603, 0.749019980430603), subtype='COLOR', unit='NONE', min=0.0, max=1.0, step=3, precision=6)
    bpy.types.Scene.sna_theme_color__tool = bpy.props.FloatVectorProperty(name='Theme Color - Tool', description='Change Tool color (button text)', size=3, default=(0.749019980430603, 0.749019980430603, 0.749019980430603), subtype='COLOR', unit='NONE', min=0.0, max=1.0, step=3, precision=6)
    bpy.types.Scene.sna_theme_color__toolbar_item_selected = bpy.props.FloatVectorProperty(name='Theme Color - Toolbar Item Selected', description='Change Selected Toolbar Item color (selected items in the toolbar)', size=4, default=(0.749019980430603, 0.749019980430603, 0.749019980430603, 1.0), subtype='COLOR', unit='NONE', min=0.0, max=1.0, step=3, precision=6)
    bpy.types.Scene.sna_theme_color__value_slider = bpy.props.FloatVectorProperty(name='Theme Color - Value Slider', description='Change Value Slider color (float values, etc.)', size=3, default=(0.749019980430603, 0.749019980430603, 0.749019980430603), subtype='COLOR', unit='NONE', min=0.0, max=1.0, step=3, precision=6)
    bpy.types.Scene.sna_theme_color__toggle_text = bpy.props.FloatVectorProperty(name='Theme Color - Toggle Text', description='', size=3, default=(0.749019980430603, 0.749019980430603, 0.749019980430603), subtype='COLOR', unit='NONE', min=0.0, max=1.0, step=3, precision=6)
    bpy.types.Scene.sna_theme_color__toggle_text_sel = bpy.props.FloatVectorProperty(name='Theme Color - Toggle Text Sel', description='', size=3, default=(0.749019980430603, 0.749019980430603, 0.749019980430603), subtype='COLOR', unit='NONE', min=0.0, max=1.0, step=3, precision=6)
    bpy.types.Scene.sna_theme_color__scroll_bar_item = bpy.props.FloatVectorProperty(name='Theme Color - Scroll Bar Item', description='Change Scroll Bar Item Color', size=4, default=(0.749019980430603, 0.749019980430603, 0.749019980430603, 1.0), subtype='COLOR', unit='NONE', min=0.0, max=1.0, step=3, precision=6)
    bpy.types.Scene.sna_theme_color__regular_sel = bpy.props.FloatVectorProperty(name='Theme Color - Regular Sel', description='Change Regular Set color (button color)', size=3, default=(0.749019980430603, 0.749019980430603, 0.749019980430603), subtype='COLOR', unit='NONE', min=0.0, max=1.0, step=3, precision=6)
    bpy.types.Scene.sna_theme_color__radio_buttons_sel = bpy.props.FloatVectorProperty(name='Theme Color - Radio Buttons Sel', description='Change the Raidio Buttons Sel Color (pref tab)', size=3, default=(0.749019980430603, 0.749019980430603, 0.749019980430603), subtype='COLOR', unit='NONE', min=0.0, max=1.0, step=3, precision=6)
    bpy.types.Scene.sna_theme_color__option_text_sel = bpy.props.FloatVectorProperty(name='Theme Color - Option Text Sel', description='Change Option color (checkbox selected)', size=3, default=(0.749019980430603, 0.749019980430603, 0.749019980430603), subtype='NONE', unit='NONE', min=0.0, max=1.0, step=3, precision=6)
    bpy.utils.register_class(SNA_OT_Save_Police_Preview_Alert_Image_558A3)
    bpy.utils.register_class(SNA_OT_Save_Police_End_Alert_Image_Preview_7A41B)
    bpy.utils.register_class(SNA_OT_Op_Start_Drawing_E7A6D)
    bpy.utils.register_class(SNA_OT_Op_End_Drawing_3823D)
    bpy.types.FILEBROWSER_MT_editor_menus.append(sna_add_to_filebrowser_mt_editor_menus_65F56)
    bpy.types.ASSETBROWSER_MT_editor_menus.append(sna_add_to_assetbrowser_mt_editor_menus_09A7D)
    bpy.types.SPREADSHEET_HT_header.append(sna_add_to_spreadsheet_ht_header_A1142)
    atexit.register(before_exit_handler_8A0D1)
    bpy.app.handlers.load_post.append(load_post_handler_0B793)
    bpy.app.handlers.save_post.append(save_post_handler_70958)
    bpy.utils.register_class(SNA_OT_Op_Save_Police_Saving_148E8)
    bpy.utils.register_class(SNA_OT_Op_Annoy_Store_And_Swap_Theme_Colors_C1B7F)
    bpy.utils.register_class(SNA_OT_Op_Annoy_Restore_Theme_Colors_954Ce)
    bpy.utils.register_class(SNA_OT_Op_Preview_Theme_Change_2Ea4A)
    bpy.types.VIEW3D_MT_editor_menus.append(sna_add_to_view3d_mt_editor_menus_AA738)
    bpy.types.CONSOLE_MT_editor_menus.append(sna_add_to_console_mt_editor_menus_C1336)
    bpy.types.INFO_MT_editor_menus.append(sna_add_to_info_mt_editor_menus_E1CA9)
    bpy.types.TEXT_MT_editor_menus.append(sna_add_to_text_mt_editor_menus_E4C6F)
    bpy.types.TOPBAR_MT_editor_menus.append(sna_add_to_topbar_mt_editor_menus_AEEC7)
    bpy.types.STATUSBAR_HT_header.append(sna_add_to_statusbar_ht_header_1E57C)
    bpy.types.NODE_MT_editor_menus.append(sna_add_to_node_mt_editor_menus_34B94)
    bpy.types.OUTLINER_HT_header.append(sna_add_to_outliner_ht_header_EE18D)
    bpy.types.USERPREF_MT_editor_menus.append(sna_add_to_userpref_mt_editor_menus_2BEF4)
    bpy.types.PROPERTIES_HT_header.append(sna_add_to_properties_ht_header_F3B48)
    if not 'Save Icon.png' in _icons: _icons.load('Save Icon.png', os.path.join(os.path.dirname(__file__), 'icons', 'Save Icon.png'), "IMAGE")
    bpy.utils.register_class(SNA_PT_SAVE_POLICE_B6A8F)
    bpy.utils.register_class(SNA_PT_SAVE_POLICE_POPOVER_EB431)
    bpy.types.DOPESHEET_MT_editor_menus.append(sna_add_to_dopesheet_mt_editor_menus_0B6E7)
    bpy.types.TIME_MT_editor_menus.append(sna_add_to_time_mt_editor_menus_5F6E0)
    bpy.types.GRAPH_MT_editor_menus.append(sna_add_to_graph_mt_editor_menus_E6FC0)
    bpy.types.NLA_MT_editor_menus.append(sna_add_to_nla_mt_editor_menus_D6C3A)
    bpy.types.IMAGE_MT_editor_menus.append(sna_add_to_image_mt_editor_menus_2A3C9)
    bpy.types.SEQUENCER_MT_editor_menus.append(sna_add_to_sequencer_mt_editor_menus_30710)
    bpy.types.CLIP_MT_tracking_editor_menus.append(sna_add_to_clip_mt_tracking_editor_menus_35868)
    bpy.utils.register_class(SNA_AddonPreferences_70C5B)
    bpy.utils.register_class(SNA_PT_ALERTS_4DC17)
    bpy.utils.register_class(SNA_PT_ALERTS_UI_5B80A)
    bpy.utils.register_class(SNA_PT_ALERT_IMAGE_E7051)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    del bpy.types.Scene.sna_theme_color__option_text_sel
    del bpy.types.Scene.sna_theme_color__radio_buttons_sel
    del bpy.types.Scene.sna_theme_color__regular_sel
    del bpy.types.Scene.sna_theme_color__scroll_bar_item
    del bpy.types.Scene.sna_theme_color__toggle_text_sel
    del bpy.types.Scene.sna_theme_color__toggle_text
    del bpy.types.Scene.sna_theme_color__value_slider
    del bpy.types.Scene.sna_theme_color__toolbar_item_selected
    del bpy.types.Scene.sna_theme_color__tool
    del bpy.types.Scene.sna_theme_color__text
    del bpy.types.Scene.sna_theme_color__radio_buttons
    del bpy.types.Scene.sna_theme_color__tab_sel
    del bpy.types.Scene.sna_theme_color__tab
    del bpy.types.Scene.sna_theme_color__regular
    del bpy.types.Scene.sna_theme_color__pulldown
    del bpy.types.Scene.sna_theme_color__option
    del bpy.types.Scene.sna_theme_color__number
    del bpy.types.Scene.sna_theme_color__list_item_sel
    del bpy.types.Scene.sna_theme_color__list_item
    del bpy.types.Scene.sna_theme_color__menu
    del bpy.types.Scene.sna_animation_interval
    del bpy.types.Scene.sna_animation_timer
    del bpy.types.Scene.sna_save_police_annoy_active
    del bpy.types.Scene.sna_save_police_reminder
    del bpy.types.Scene.sna_save_police_timer_freq
    del bpy.types.Scene.sna_save_police_script_interval
    del bpy.types.Scene.sna_save_police_interval
    del bpy.types.Scene.sna_save_police_theme_active
    del bpy.types.Scene.sna_save_police_animation_active
    if handler_5FE5D:
        bpy.types.SpaceView3D.draw_handler_remove(handler_5FE5D[0], 'WINDOW')
        handler_5FE5D.pop(0)
    if handler_D8705:
        bpy.types.SpaceImageEditor.draw_handler_remove(handler_D8705[0], 'WINDOW')
        handler_D8705.pop(0)
    if handler_AAAFB:
        bpy.types.SpaceNodeEditor.draw_handler_remove(handler_AAAFB[0], 'WINDOW')
        handler_AAAFB.pop(0)
    bpy.utils.unregister_class(SNA_OT_Save_Police_Preview_Alert_Image_558A3)
    bpy.utils.unregister_class(SNA_OT_Save_Police_End_Alert_Image_Preview_7A41B)
    if handler_CB41D:
        bpy.types.SpaceSequenceEditor.draw_handler_remove(handler_CB41D[0], 'WINDOW')
        handler_CB41D.pop(0)
    bpy.utils.unregister_class(SNA_OT_Op_Start_Drawing_E7A6D)
    if handler_64666:
        bpy.types.SpaceNodeEditor.draw_handler_remove(handler_64666[0], 'WINDOW')
        handler_64666.pop(0)
    bpy.utils.unregister_class(SNA_OT_Op_End_Drawing_3823D)
    bpy.types.FILEBROWSER_MT_editor_menus.remove(sna_add_to_filebrowser_mt_editor_menus_65F56)
    bpy.types.ASSETBROWSER_MT_editor_menus.remove(sna_add_to_assetbrowser_mt_editor_menus_09A7D)
    bpy.types.SPREADSHEET_HT_header.remove(sna_add_to_spreadsheet_ht_header_A1142)
    atexit.unregister(before_exit_handler_8A0D1)
    bpy.app.handlers.load_post.remove(load_post_handler_0B793)
    bpy.app.handlers.save_post.remove(save_post_handler_70958)
    bpy.utils.unregister_class(SNA_OT_Op_Save_Police_Saving_148E8)
    bpy.utils.unregister_class(SNA_OT_Op_Annoy_Store_And_Swap_Theme_Colors_C1B7F)
    bpy.utils.unregister_class(SNA_OT_Op_Annoy_Restore_Theme_Colors_954Ce)
    bpy.utils.unregister_class(SNA_OT_Op_Preview_Theme_Change_2Ea4A)
    bpy.types.VIEW3D_MT_editor_menus.remove(sna_add_to_view3d_mt_editor_menus_AA738)
    bpy.types.CONSOLE_MT_editor_menus.remove(sna_add_to_console_mt_editor_menus_C1336)
    bpy.types.INFO_MT_editor_menus.remove(sna_add_to_info_mt_editor_menus_E1CA9)
    bpy.types.TEXT_MT_editor_menus.remove(sna_add_to_text_mt_editor_menus_E4C6F)
    bpy.types.TOPBAR_MT_editor_menus.remove(sna_add_to_topbar_mt_editor_menus_AEEC7)
    bpy.types.STATUSBAR_HT_header.remove(sna_add_to_statusbar_ht_header_1E57C)
    bpy.types.NODE_MT_editor_menus.remove(sna_add_to_node_mt_editor_menus_34B94)
    bpy.types.OUTLINER_HT_header.remove(sna_add_to_outliner_ht_header_EE18D)
    bpy.types.USERPREF_MT_editor_menus.remove(sna_add_to_userpref_mt_editor_menus_2BEF4)
    bpy.types.PROPERTIES_HT_header.remove(sna_add_to_properties_ht_header_F3B48)
    bpy.utils.unregister_class(SNA_PT_SAVE_POLICE_B6A8F)
    bpy.utils.unregister_class(SNA_PT_SAVE_POLICE_POPOVER_EB431)
    bpy.types.DOPESHEET_MT_editor_menus.remove(sna_add_to_dopesheet_mt_editor_menus_0B6E7)
    bpy.types.TIME_MT_editor_menus.remove(sna_add_to_time_mt_editor_menus_5F6E0)
    bpy.types.GRAPH_MT_editor_menus.remove(sna_add_to_graph_mt_editor_menus_E6FC0)
    bpy.types.NLA_MT_editor_menus.remove(sna_add_to_nla_mt_editor_menus_D6C3A)
    bpy.types.IMAGE_MT_editor_menus.remove(sna_add_to_image_mt_editor_menus_2A3C9)
    bpy.types.SEQUENCER_MT_editor_menus.remove(sna_add_to_sequencer_mt_editor_menus_30710)
    bpy.types.CLIP_MT_tracking_editor_menus.remove(sna_add_to_clip_mt_tracking_editor_menus_35868)
    bpy.utils.unregister_class(SNA_AddonPreferences_70C5B)
    bpy.utils.unregister_class(SNA_PT_ALERTS_4DC17)
    bpy.utils.unregister_class(SNA_PT_ALERTS_UI_5B80A)
    bpy.utils.unregister_class(SNA_PT_ALERT_IMAGE_E7051)
